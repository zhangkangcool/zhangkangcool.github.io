



# 以下是pip3安装方式

最好先弄个虚拟环境

```
pip install jax -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host https://pypi.tuna.tsinghua.edu.cn

pip install jaxlib -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host https://pypi.tuna.tsinghua.edu.cn
```





# 以下是源码安装方式

https://jax.readthedocs.io/en/latest/developer.html#building-from-source



```shell
python3 build/build.py --bazel_options=--override_repository=org_tensorflow=/home/ken/workspace/tensorflow/tensorflow
这样不用编译时下载tensorflow

Bazel binary path: /usr/local/bin/bazel
Bazel version: 5.1.1
Python binary path: /usr/bin/python3
Python version: 3.7
NumPy version: 1.21.6
MKL-DNN enabled: yes
Target CPU: x86_64
Target CPU features: release
CUDA enabled: no
TPU enabled: no
Remote TPU enabled: no
ROCm enabled: no
```







```
https://storage.googleapis.com/mirror.tensorflow.org/github.com/llvm/llvm-project/archive/0538e5431afdb1fa05bdcedf70ee502ccfcd112a.tar.gz
```

