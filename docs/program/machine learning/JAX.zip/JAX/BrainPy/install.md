

### github brainpy

https://github.com/PKU-NIP-Lab/BrainPy

安装方式

https://brainpy.readthedocs.io/en/latest/quickstart/installation.html#installation-from-source



https://jax.readthedocs.io/en/latest/developer.html#building-from-source



### github jax

https://github.com/google/jax#installation





Brainpy需要jax>= 0.3。

```



pip install jax
pip install jaxlib
pip install brainpy



```



