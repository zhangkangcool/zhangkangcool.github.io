#loc0 = loc(unknown)
module @jit_prim_fun {
  func.func public @main(%arg0: tensor<1x2xui32> loc(unknown)) -> tensor<2xui32> {
    %0 = mhlo.reshape %arg0 : (tensor<1x2xui32>) -> tensor<2xui32> loc(#loc1)
    return %0 : tensor<2xui32> loc(#loc0)
  } loc(#loc0)
} loc(#loc0)
#loc1 = loc("jit(squeeze)/jit(main)/squeeze[dimensions=(0,)]"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/random.py":428:1))
