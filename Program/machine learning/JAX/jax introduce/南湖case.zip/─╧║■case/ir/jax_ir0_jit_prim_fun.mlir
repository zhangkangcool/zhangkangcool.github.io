#loc0 = loc(unknown)
module @jit_prim_fun {
  func.func public @main(%arg0: tensor<f32> loc(unknown)) -> tensor<10000xf32> {
    %0 = "mhlo.broadcast_in_dim"(%arg0) {broadcast_dimensions = dense<> : tensor<0xi64>} : (tensor<f32>) -> tensor<10000xf32> loc(#loc1)
    return %0 : tensor<10000xf32> loc(#loc0)
  } loc(#loc0)
} loc(#loc0)
#loc1 = loc("jit(broadcast_in_dim)/jit(main)/broadcast_in_dim[shape=(10000,) broadcast_dimensions=()]"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/numpy_ops.py":1744:1))
