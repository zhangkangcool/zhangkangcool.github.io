#loc0 = loc(unknown)
module @jit_prim_fun {
  func.func public @main(%arg0: tensor<10000xf32> loc(unknown), %arg1: tensor<0xi32> loc(unknown), %arg2: tensor<10000xf32> loc(unknown)) -> tensor<10000xf32> {
    %0 = "mhlo.scatter"(%arg0, %arg1, %arg2) ({
    ^bb0(%arg3: tensor<f32> loc(unknown), %arg4: tensor<f32> loc(unknown)):
      mhlo.return %arg4 : tensor<f32> loc(#loc1)
    }) {indices_are_sorted = true, scatter_dimension_numbers = #mhlo.scatter<update_window_dims = [0]>, unique_indices = true} : (tensor<10000xf32>, tensor<0xi32>, tensor<10000xf32>) -> tensor<10000xf32> loc(#loc1)
    return %0 : tensor<10000xf32> loc(#loc0)
  } loc(#loc0)
} loc(#loc0)
#loc1 = loc("jit(scatter)/jit(main)/scatter[update_consts=() dimension_numbers=ScatterDimensionNumbers(update_window_dims=(0,), inserted_window_dims=(), scatter_dims_to_operand_dims=()) indices_are_sorted=True unique_indices=True mode=GatherScatterMode.FILL_OR_DROP]"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/jaxarray.py":971:1))
