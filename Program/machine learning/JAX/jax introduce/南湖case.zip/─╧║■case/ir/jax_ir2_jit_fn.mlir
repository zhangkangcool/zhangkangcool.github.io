#loc0 = loc(unknown)
module @jit_fn {
  func.func public @main(%arg0: tensor<10000xf32> loc(unknown), %arg1: tensor<f32> loc(unknown)) -> tensor<10000xf32> {
    %0 = mhlo.convert %arg1 : tensor<f32> loc(#loc1)
    %1 = "mhlo.broadcast_in_dim"(%0) {broadcast_dimensions = dense<> : tensor<0xi64>} : (tensor<f32>) -> tensor<10000xf32> loc(#loc2)
    %2 = mhlo.multiply %arg0, %1 : tensor<10000xf32> loc(#loc2)
    return %2 : tensor<10000xf32> loc(#loc0)
  } loc(#loc0)
} loc(#loc0)
#loc1 = loc("jit(fn)/jit(main)/convert_element_type[new_dtype=float32 weak_type=False]"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/jaxarray.py":268:1))
#loc2 = loc("jit(fn)/jit(main)/mul"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/jaxarray.py":268:1))
