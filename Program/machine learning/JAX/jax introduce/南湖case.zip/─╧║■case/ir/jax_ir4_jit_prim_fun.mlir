#loc0 = loc(unknown)
module @jit_prim_fun {
  func.func public @main(%arg0: tensor<2x2xui32> loc(unknown)) -> tensor<1x2xui32> {
    %0 = "mhlo.slice"(%arg0) {limit_indices = dense<[1, 2]> : tensor<2xi64>, start_indices = dense<0> : tensor<2xi64>, strides = dense<1> : tensor<2xi64>} : (tensor<2x2xui32>) -> tensor<1x2xui32> loc(#loc1)
    return %0 : tensor<1x2xui32> loc(#loc0)
  } loc(#loc0)
} loc(#loc0)
#loc1 = loc("jit(slice)/jit(main)/slice[start_indices=(0, 0) limit_indices=(1, 2) strides=(1, 1)]"("/home/ken/virtualEnv/jaxEnv/lib/python3.7/site-packages/brainpy/math/random.py":428:1))
