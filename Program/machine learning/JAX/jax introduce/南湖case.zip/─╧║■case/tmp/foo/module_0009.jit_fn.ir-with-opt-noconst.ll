; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind uwtable
define void @main.6(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds ptr, ptr %buffer_table, i64 2
  %Arg_1.2 = load ptr, ptr %1, align 8, !invariant.load !0, !dereferenceable !3, !align !3
  %fusion = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %2 = load i32, ptr %Arg_1.2, align 4, !invariant.load !0, !noalias !4
  %3 = sitofp i32 %2 to float
  %broadcast.splatinsert = insertelement <8 x float> poison, float %3, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert5 = insertelement <8 x float> poison, float %3, i64 0
  %broadcast.splat6 = shufflevector <8 x float> %broadcast.splatinsert5, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert7 = insertelement <8 x float> poison, float %3, i64 0
  %broadcast.splat8 = shufflevector <8 x float> %broadcast.splatinsert7, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert9 = insertelement <8 x float> poison, float %3, i64 0
  %broadcast.splat10 = shufflevector <8 x float> %broadcast.splatinsert9, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next.2, %vector.body ]
  %4 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index
  %wide.load = load <8 x float>, ptr %4, align 16, !invariant.load !0, !noalias !4
  %5 = getelementptr inbounds float, ptr %4, i64 8
  %wide.load2 = load <8 x float>, ptr %5, align 16, !invariant.load !0, !noalias !4
  %6 = getelementptr inbounds float, ptr %4, i64 16
  %wide.load3 = load <8 x float>, ptr %6, align 16, !invariant.load !0, !noalias !4
  %7 = getelementptr inbounds float, ptr %4, i64 24
  %wide.load4 = load <8 x float>, ptr %7, align 16, !invariant.load !0, !noalias !4
  %8 = fmul <8 x float> %wide.load, %broadcast.splat
  %9 = fmul <8 x float> %wide.load2, %broadcast.splat6
  %10 = fmul <8 x float> %wide.load3, %broadcast.splat8
  %11 = fmul <8 x float> %wide.load4, %broadcast.splat10
  %12 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index
  store <8 x float> %8, ptr %12, align 16, !alias.scope !4
  %13 = getelementptr inbounds float, ptr %12, i64 8
  store <8 x float> %9, ptr %13, align 16, !alias.scope !4
  %14 = getelementptr inbounds float, ptr %12, i64 16
  store <8 x float> %10, ptr %14, align 16, !alias.scope !4
  %15 = getelementptr inbounds float, ptr %12, i64 24
  store <8 x float> %11, ptr %15, align 16, !alias.scope !4
  %index.next = add nuw nsw i64 %index, 32
  %16 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %16, align 16, !invariant.load !0, !noalias !4
  %17 = getelementptr inbounds float, ptr %16, i64 8
  %wide.load2.1 = load <8 x float>, ptr %17, align 16, !invariant.load !0, !noalias !4
  %18 = getelementptr inbounds float, ptr %16, i64 16
  %wide.load3.1 = load <8 x float>, ptr %18, align 16, !invariant.load !0, !noalias !4
  %19 = getelementptr inbounds float, ptr %16, i64 24
  %wide.load4.1 = load <8 x float>, ptr %19, align 16, !invariant.load !0, !noalias !4
  %20 = fmul <8 x float> %wide.load.1, %broadcast.splat
  %21 = fmul <8 x float> %wide.load2.1, %broadcast.splat6
  %22 = fmul <8 x float> %wide.load3.1, %broadcast.splat8
  %23 = fmul <8 x float> %wide.load4.1, %broadcast.splat10
  %24 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index.next
  store <8 x float> %20, ptr %24, align 16, !alias.scope !4
  %25 = getelementptr inbounds float, ptr %24, i64 8
  store <8 x float> %21, ptr %25, align 16, !alias.scope !4
  %26 = getelementptr inbounds float, ptr %24, i64 16
  store <8 x float> %22, ptr %26, align 16, !alias.scope !4
  %27 = getelementptr inbounds float, ptr %24, i64 24
  store <8 x float> %23, ptr %27, align 16, !alias.scope !4
  %index.next.1 = add nuw nsw i64 %index, 64
  %28 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index.next.1
  %wide.load.2 = load <8 x float>, ptr %28, align 16, !invariant.load !0, !noalias !4
  %29 = getelementptr inbounds float, ptr %28, i64 8
  %wide.load2.2 = load <8 x float>, ptr %29, align 16, !invariant.load !0, !noalias !4
  %30 = getelementptr inbounds float, ptr %28, i64 16
  %wide.load3.2 = load <8 x float>, ptr %30, align 16, !invariant.load !0, !noalias !4
  %31 = getelementptr inbounds float, ptr %28, i64 24
  %wide.load4.2 = load <8 x float>, ptr %31, align 16, !invariant.load !0, !noalias !4
  %32 = fmul <8 x float> %wide.load.2, %broadcast.splat
  %33 = fmul <8 x float> %wide.load2.2, %broadcast.splat6
  %34 = fmul <8 x float> %wide.load3.2, %broadcast.splat8
  %35 = fmul <8 x float> %wide.load4.2, %broadcast.splat10
  %36 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index.next.1
  store <8 x float> %32, ptr %36, align 16, !alias.scope !4
  %37 = getelementptr inbounds float, ptr %36, i64 8
  store <8 x float> %33, ptr %37, align 16, !alias.scope !4
  %38 = getelementptr inbounds float, ptr %36, i64 16
  store <8 x float> %34, ptr %38, align 16, !alias.scope !4
  %39 = getelementptr inbounds float, ptr %36, i64 24
  store <8 x float> %35, ptr %39, align 16, !alias.scope !4
  %index.next.2 = add nuw nsw i64 %index, 96
  %40 = icmp eq i64 %index.next.2, 9984
  br i1 %40, label %fusion.loop_body.dim.0, label %vector.body, !llvm.loop !7

fusion.loop_body.dim.0:                           ; preds = %vector.body
  %41 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9984
  %42 = load float, ptr %41, align 16, !invariant.load !0, !noalias !4
  %multiply.0 = fmul float %42, %3
  %43 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9984
  store float %multiply.0, ptr %43, align 16, !alias.scope !4
  %44 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9985
  %45 = load float, ptr %44, align 4, !invariant.load !0, !noalias !4
  %multiply.0.1 = fmul float %45, %3
  %46 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9985
  store float %multiply.0.1, ptr %46, align 4, !alias.scope !4
  %47 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9986
  %48 = load float, ptr %47, align 8, !invariant.load !0, !noalias !4
  %multiply.0.2 = fmul float %48, %3
  %49 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9986
  store float %multiply.0.2, ptr %49, align 8, !alias.scope !4
  %50 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9987
  %51 = load float, ptr %50, align 4, !invariant.load !0, !noalias !4
  %multiply.0.3 = fmul float %51, %3
  %52 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9987
  store float %multiply.0.3, ptr %52, align 4, !alias.scope !4
  %53 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9988
  %54 = load float, ptr %53, align 16, !invariant.load !0, !noalias !4
  %multiply.0.4 = fmul float %54, %3
  %55 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9988
  store float %multiply.0.4, ptr %55, align 16, !alias.scope !4
  %56 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9989
  %57 = load float, ptr %56, align 4, !invariant.load !0, !noalias !4
  %multiply.0.5 = fmul float %57, %3
  %58 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9989
  store float %multiply.0.5, ptr %58, align 4, !alias.scope !4
  %59 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9990
  %60 = load float, ptr %59, align 8, !invariant.load !0, !noalias !4
  %multiply.0.6 = fmul float %60, %3
  %61 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9990
  store float %multiply.0.6, ptr %61, align 8, !alias.scope !4
  %62 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9991
  %63 = load float, ptr %62, align 4, !invariant.load !0, !noalias !4
  %multiply.0.7 = fmul float %63, %3
  %64 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9991
  store float %multiply.0.7, ptr %64, align 4, !alias.scope !4
  %65 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9992
  %66 = load float, ptr %65, align 16, !invariant.load !0, !noalias !4
  %multiply.0.8 = fmul float %66, %3
  %67 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9992
  store float %multiply.0.8, ptr %67, align 16, !alias.scope !4
  %68 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9993
  %69 = load float, ptr %68, align 4, !invariant.load !0, !noalias !4
  %multiply.0.9 = fmul float %69, %3
  %70 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9993
  store float %multiply.0.9, ptr %70, align 4, !alias.scope !4
  %71 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9994
  %72 = load float, ptr %71, align 8, !invariant.load !0, !noalias !4
  %multiply.0.10 = fmul float %72, %3
  %73 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9994
  store float %multiply.0.10, ptr %73, align 8, !alias.scope !4
  %74 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9995
  %75 = load float, ptr %74, align 4, !invariant.load !0, !noalias !4
  %multiply.0.11 = fmul float %75, %3
  %76 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9995
  store float %multiply.0.11, ptr %76, align 4, !alias.scope !4
  %77 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9996
  %78 = load float, ptr %77, align 16, !invariant.load !0, !noalias !4
  %multiply.0.12 = fmul float %78, %3
  %79 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9996
  store float %multiply.0.12, ptr %79, align 16, !alias.scope !4
  %80 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9997
  %81 = load float, ptr %80, align 4, !invariant.load !0, !noalias !4
  %multiply.0.13 = fmul float %81, %3
  %82 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9997
  store float %multiply.0.13, ptr %82, align 4, !alias.scope !4
  %83 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9998
  %84 = load float, ptr %83, align 8, !invariant.load !0, !noalias !4
  %multiply.0.14 = fmul float %84, %3
  %85 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9998
  store float %multiply.0.14, ptr %85, align 8, !alias.scope !4
  %86 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9999
  %87 = load float, ptr %86, align 4, !invariant.load !0, !noalias !4
  %multiply.0.15 = fmul float %87, %3
  %88 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9999
  store float %multiply.0.15, ptr %88, align 4, !alias.scope !4
  ret void
}

attributes #0 = { nofree norecurse nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }

!0 = !{}
!1 = !{i64 40000}
!2 = !{i64 16}
!3 = !{i64 4}
!4 = !{!5}
!5 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!6 = !{!"XLA global AA domain"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.isvectorized", i32 1}
