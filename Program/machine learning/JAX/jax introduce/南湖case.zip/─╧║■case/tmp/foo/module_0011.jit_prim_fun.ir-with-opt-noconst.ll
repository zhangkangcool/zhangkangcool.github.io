; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: mustprogress nofree nosync nounwind willreturn uwtable
define void @main.8(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 2
  %Arg_2.3 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(40000) %copy, ptr noundef nonnull align 16 dereferenceable(40000) %Arg_2.3, i64 40000, i1 false)
  ret void
}

; Function Attrs: inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #1

attributes #0 = { mustprogress nofree nosync nounwind willreturn uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #1 = { inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn }

!0 = !{}
!1 = !{i64 40000}
!2 = !{i64 16}
