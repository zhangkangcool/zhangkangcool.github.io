; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind uwtable
define void @main.3(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1
  %broadcast.2 = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !2, !align !3
  %1 = load i8, ptr %Arg_0.1, align 1, !invariant.load !0, !noalias !4
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(10000) %broadcast.2, i8 %1, i64 10000, i1 false), !alias.scope !4
  ret void
}

; Function Attrs: argmemonly nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #1

attributes #0 = { nofree norecurse nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #1 = { argmemonly nocallback nofree nounwind willreturn writeonly }

!0 = !{}
!1 = !{i64 1}
!2 = !{i64 10000}
!3 = !{i64 16}
!4 = !{!5}
!5 = !{!"buffer: {index:0, offset:0, size:10000}", !6}
!6 = !{!"XLA global AA domain"}
