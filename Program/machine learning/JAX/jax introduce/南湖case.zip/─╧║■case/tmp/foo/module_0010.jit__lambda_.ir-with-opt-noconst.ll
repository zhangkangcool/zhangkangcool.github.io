; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind uwtable
define void @main.5(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds ptr, ptr %buffer_table, i64 2
  %Arg_1.2 = load ptr, ptr %1, align 8, !invariant.load !0, !dereferenceable !3, !align !3
  %fusion = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %2 = load float, ptr %Arg_1.2, align 4, !invariant.load !0, !noalias !4
  %broadcast.splatinsert = insertelement <8 x float> poison, float %2, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert5 = insertelement <8 x float> poison, float %2, i64 0
  %broadcast.splat6 = shufflevector <8 x float> %broadcast.splatinsert5, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert7 = insertelement <8 x float> poison, float %2, i64 0
  %broadcast.splat8 = shufflevector <8 x float> %broadcast.splatinsert7, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert9 = insertelement <8 x float> poison, float %2, i64 0
  %broadcast.splat10 = shufflevector <8 x float> %broadcast.splatinsert9, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next.2, %vector.body ]
  %3 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index
  %wide.load = load <8 x float>, ptr %3, align 16, !invariant.load !0, !noalias !4
  %4 = getelementptr inbounds float, ptr %3, i64 8
  %wide.load2 = load <8 x float>, ptr %4, align 16, !invariant.load !0, !noalias !4
  %5 = getelementptr inbounds float, ptr %3, i64 16
  %wide.load3 = load <8 x float>, ptr %5, align 16, !invariant.load !0, !noalias !4
  %6 = getelementptr inbounds float, ptr %3, i64 24
  %wide.load4 = load <8 x float>, ptr %6, align 16, !invariant.load !0, !noalias !4
  %7 = fsub <8 x float> %wide.load, %broadcast.splat
  %8 = fsub <8 x float> %wide.load2, %broadcast.splat6
  %9 = fsub <8 x float> %wide.load3, %broadcast.splat8
  %10 = fsub <8 x float> %wide.load4, %broadcast.splat10
  %11 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index
  store <8 x float> %7, ptr %11, align 16, !alias.scope !4
  %12 = getelementptr inbounds float, ptr %11, i64 8
  store <8 x float> %8, ptr %12, align 16, !alias.scope !4
  %13 = getelementptr inbounds float, ptr %11, i64 16
  store <8 x float> %9, ptr %13, align 16, !alias.scope !4
  %14 = getelementptr inbounds float, ptr %11, i64 24
  store <8 x float> %10, ptr %14, align 16, !alias.scope !4
  %index.next = add nuw nsw i64 %index, 32
  %15 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %15, align 16, !invariant.load !0, !noalias !4
  %16 = getelementptr inbounds float, ptr %15, i64 8
  %wide.load2.1 = load <8 x float>, ptr %16, align 16, !invariant.load !0, !noalias !4
  %17 = getelementptr inbounds float, ptr %15, i64 16
  %wide.load3.1 = load <8 x float>, ptr %17, align 16, !invariant.load !0, !noalias !4
  %18 = getelementptr inbounds float, ptr %15, i64 24
  %wide.load4.1 = load <8 x float>, ptr %18, align 16, !invariant.load !0, !noalias !4
  %19 = fsub <8 x float> %wide.load.1, %broadcast.splat
  %20 = fsub <8 x float> %wide.load2.1, %broadcast.splat6
  %21 = fsub <8 x float> %wide.load3.1, %broadcast.splat8
  %22 = fsub <8 x float> %wide.load4.1, %broadcast.splat10
  %23 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index.next
  store <8 x float> %19, ptr %23, align 16, !alias.scope !4
  %24 = getelementptr inbounds float, ptr %23, i64 8
  store <8 x float> %20, ptr %24, align 16, !alias.scope !4
  %25 = getelementptr inbounds float, ptr %23, i64 16
  store <8 x float> %21, ptr %25, align 16, !alias.scope !4
  %26 = getelementptr inbounds float, ptr %23, i64 24
  store <8 x float> %22, ptr %26, align 16, !alias.scope !4
  %index.next.1 = add nuw nsw i64 %index, 64
  %27 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %index.next.1
  %wide.load.2 = load <8 x float>, ptr %27, align 16, !invariant.load !0, !noalias !4
  %28 = getelementptr inbounds float, ptr %27, i64 8
  %wide.load2.2 = load <8 x float>, ptr %28, align 16, !invariant.load !0, !noalias !4
  %29 = getelementptr inbounds float, ptr %27, i64 16
  %wide.load3.2 = load <8 x float>, ptr %29, align 16, !invariant.load !0, !noalias !4
  %30 = getelementptr inbounds float, ptr %27, i64 24
  %wide.load4.2 = load <8 x float>, ptr %30, align 16, !invariant.load !0, !noalias !4
  %31 = fsub <8 x float> %wide.load.2, %broadcast.splat
  %32 = fsub <8 x float> %wide.load2.2, %broadcast.splat6
  %33 = fsub <8 x float> %wide.load3.2, %broadcast.splat8
  %34 = fsub <8 x float> %wide.load4.2, %broadcast.splat10
  %35 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %index.next.1
  store <8 x float> %31, ptr %35, align 16, !alias.scope !4
  %36 = getelementptr inbounds float, ptr %35, i64 8
  store <8 x float> %32, ptr %36, align 16, !alias.scope !4
  %37 = getelementptr inbounds float, ptr %35, i64 16
  store <8 x float> %33, ptr %37, align 16, !alias.scope !4
  %38 = getelementptr inbounds float, ptr %35, i64 24
  store <8 x float> %34, ptr %38, align 16, !alias.scope !4
  %index.next.2 = add nuw nsw i64 %index, 96
  %39 = icmp eq i64 %index.next.2, 9984
  br i1 %39, label %fusion.loop_body.dim.0, label %vector.body, !llvm.loop !7

fusion.loop_body.dim.0:                           ; preds = %vector.body
  %40 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9984
  %41 = load float, ptr %40, align 16, !invariant.load !0, !noalias !4
  %subtract.0 = fsub float %41, %2
  %42 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9984
  store float %subtract.0, ptr %42, align 16, !alias.scope !4
  %43 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9985
  %44 = load float, ptr %43, align 4, !invariant.load !0, !noalias !4
  %subtract.0.1 = fsub float %44, %2
  %45 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9985
  store float %subtract.0.1, ptr %45, align 4, !alias.scope !4
  %46 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9986
  %47 = load float, ptr %46, align 8, !invariant.load !0, !noalias !4
  %subtract.0.2 = fsub float %47, %2
  %48 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9986
  store float %subtract.0.2, ptr %48, align 8, !alias.scope !4
  %49 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9987
  %50 = load float, ptr %49, align 4, !invariant.load !0, !noalias !4
  %subtract.0.3 = fsub float %50, %2
  %51 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9987
  store float %subtract.0.3, ptr %51, align 4, !alias.scope !4
  %52 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9988
  %53 = load float, ptr %52, align 16, !invariant.load !0, !noalias !4
  %subtract.0.4 = fsub float %53, %2
  %54 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9988
  store float %subtract.0.4, ptr %54, align 16, !alias.scope !4
  %55 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9989
  %56 = load float, ptr %55, align 4, !invariant.load !0, !noalias !4
  %subtract.0.5 = fsub float %56, %2
  %57 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9989
  store float %subtract.0.5, ptr %57, align 4, !alias.scope !4
  %58 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9990
  %59 = load float, ptr %58, align 8, !invariant.load !0, !noalias !4
  %subtract.0.6 = fsub float %59, %2
  %60 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9990
  store float %subtract.0.6, ptr %60, align 8, !alias.scope !4
  %61 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9991
  %62 = load float, ptr %61, align 4, !invariant.load !0, !noalias !4
  %subtract.0.7 = fsub float %62, %2
  %63 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9991
  store float %subtract.0.7, ptr %63, align 4, !alias.scope !4
  %64 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9992
  %65 = load float, ptr %64, align 16, !invariant.load !0, !noalias !4
  %subtract.0.8 = fsub float %65, %2
  %66 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9992
  store float %subtract.0.8, ptr %66, align 16, !alias.scope !4
  %67 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9993
  %68 = load float, ptr %67, align 4, !invariant.load !0, !noalias !4
  %subtract.0.9 = fsub float %68, %2
  %69 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9993
  store float %subtract.0.9, ptr %69, align 4, !alias.scope !4
  %70 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9994
  %71 = load float, ptr %70, align 8, !invariant.load !0, !noalias !4
  %subtract.0.10 = fsub float %71, %2
  %72 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9994
  store float %subtract.0.10, ptr %72, align 8, !alias.scope !4
  %73 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9995
  %74 = load float, ptr %73, align 4, !invariant.load !0, !noalias !4
  %subtract.0.11 = fsub float %74, %2
  %75 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9995
  store float %subtract.0.11, ptr %75, align 4, !alias.scope !4
  %76 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9996
  %77 = load float, ptr %76, align 16, !invariant.load !0, !noalias !4
  %subtract.0.12 = fsub float %77, %2
  %78 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9996
  store float %subtract.0.12, ptr %78, align 16, !alias.scope !4
  %79 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9997
  %80 = load float, ptr %79, align 4, !invariant.load !0, !noalias !4
  %subtract.0.13 = fsub float %80, %2
  %81 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9997
  store float %subtract.0.13, ptr %81, align 4, !alias.scope !4
  %82 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9998
  %83 = load float, ptr %82, align 8, !invariant.load !0, !noalias !4
  %subtract.0.14 = fsub float %83, %2
  %84 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9998
  store float %subtract.0.14, ptr %84, align 8, !alias.scope !4
  %85 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 9999
  %86 = load float, ptr %85, align 4, !invariant.load !0, !noalias !4
  %subtract.0.15 = fsub float %86, %2
  %87 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 9999
  store float %subtract.0.15, ptr %87, align 4, !alias.scope !4
  ret void
}

attributes #0 = { nofree norecurse nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }

!0 = !{}
!1 = !{i64 40000}
!2 = !{i64 16}
!3 = !{i64 4}
!4 = !{!5}
!5 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!6 = !{!"XLA global AA domain"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.isvectorized", i32 1}
