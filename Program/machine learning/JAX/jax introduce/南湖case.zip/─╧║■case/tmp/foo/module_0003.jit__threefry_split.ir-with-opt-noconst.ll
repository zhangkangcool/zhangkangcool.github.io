; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@constant.5 = external dso_local unnamed_addr constant [16 x i8], align 16
@constant.4 = external dso_local unnamed_addr constant [16 x i8], align 16

; Function Attrs: inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #0

; Function Attrs: nofree nosync nounwind uwtable
define void @main.109(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #1 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.25 = getelementptr inbounds i8, ptr %1, i64 80
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.25, ptr noundef nonnull align 16 dereferenceable(16) @constant.4, i64 16, i1 false)
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %copy.26 = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !2, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.26, ptr noundef nonnull align 16 dereferenceable(16) @constant.5, i64 16, i1 false)
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 4
  %Arg_0.1 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !3, !align !3
  %fusion.2 = getelementptr inbounds i8, ptr %1, i64 128
  %4 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %5 = load i32, ptr %4, align 4, !invariant.load !0, !noalias !4
  %6 = add i32 %5, 2
  store i32 %6, ptr %fusion.2, align 16, !alias.scope !11, !noalias !12
  %7 = add i32 %5, 3
  %8 = getelementptr inbounds i8, ptr %1, i64 132
  store i32 %7, ptr %8, align 4, !alias.scope !11, !noalias !12
  %fusion.4 = getelementptr inbounds i8, ptr %1, i64 112
  %9 = load i32, ptr %Arg_0.1, align 8, !invariant.load !0, !noalias !4
  store i32 %9, ptr %fusion.4, align 16, !alias.scope !17, !noalias !18
  %10 = add i32 %9, 1
  %11 = getelementptr inbounds i8, ptr %1, i64 116
  store i32 %10, ptr %11, align 4, !alias.scope !17, !noalias !18
  %copy.24 = getelementptr inbounds i8, ptr %1, i64 176
  store i32 0, ptr %copy.24, align 16
  %fusion.1 = getelementptr inbounds i8, ptr %1, i64 160
  %12 = xor i32 %9, %5
  %13 = xor i32 %12, 466688986
  store i32 %13, ptr %fusion.1, align 16, !alias.scope !19, !noalias !20
  %fusion.3 = getelementptr inbounds i8, ptr %1, i64 192
  store i32 %5, ptr %fusion.3, align 16, !alias.scope !21, !noalias !22
  %fusion.5 = getelementptr inbounds i8, ptr %1, i64 208
  store i32 %9, ptr %fusion.5, align 16, !alias.scope !23, !noalias !24
  store ptr %copy.24, ptr %1, align 16, !alias.scope !25, !noalias !26
  %14 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 1
  store ptr %fusion.4, ptr %14, align 8, !alias.scope !25, !noalias !26
  %15 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 2
  store ptr %fusion.2, ptr %15, align 16, !alias.scope !25, !noalias !26
  %16 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 3
  store ptr %fusion.3, ptr %16, align 8, !alias.scope !25, !noalias !26
  %17 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 4
  store ptr %fusion.1, ptr %17, align 16, !alias.scope !25, !noalias !26
  %18 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 5
  store ptr %fusion.5, ptr %18, align 8, !alias.scope !25, !noalias !26
  %19 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 6
  store ptr %copy.26, ptr %19, align 16, !alias.scope !25, !noalias !26
  %20 = getelementptr inbounds [8 x ptr], ptr %1, i64 0, i64 7
  %compare.1.i = getelementptr inbounds i8, ptr %1, i64 64
  store ptr %copy.25, ptr %20, align 8, !alias.scope !25, !noalias !26
  store i8 1, ptr %compare.1.i, align 16, !alias.scope !27, !noalias !29
  %copy.9.i = getelementptr inbounds i8, ptr %1, i64 96
  %copy.12.i = getelementptr inbounds i8, ptr %1, i64 144
  %copy.8.i = getelementptr inbounds i8, ptr %1, i64 224
  %21 = getelementptr inbounds i8, ptr %1, i64 68
  %22 = getelementptr inbounds i8, ptr %1, i64 72
  %23 = getelementptr inbounds i8, ptr %1, i64 76
  %24 = getelementptr inbounds i8, ptr %1, i64 100
  %25 = getelementptr inbounds [2 x i32], ptr %copy.26, i64 0, i64 1
  %26 = getelementptr inbounds i8, ptr %1, i64 132
  %27 = getelementptr inbounds i8, ptr %1, i64 100
  %28 = getelementptr inbounds [2 x i32], ptr %copy.26, i64 0, i64 1
  %29 = getelementptr inbounds i8, ptr %1, i64 116
  br label %while.1.body

while.1.body:                                     ; preds = %while.1.body, %entry
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %compare.1.i, ptr noundef nonnull align 16 dereferenceable(16) %copy.26, i64 16, i1 false), !noalias !33
  %30 = load i64, ptr %fusion.2, align 16, !noalias !33
  store i64 %30, ptr %copy.26, align 16, !noalias !33
  %31 = load ptr, ptr %14, align 8, !noalias !33, !dereferenceable !3, !align !3
  %32 = load i64, ptr %31, align 8, !noalias !33
  store i64 %32, ptr %copy.9.i, align 16, !noalias !33
  %33 = load ptr, ptr %17, align 16, !noalias !33, !dereferenceable !36, !align !36
  %34 = load i32, ptr %33, align 4, !noalias !33
  store i32 %34, ptr %copy.12.i, align 16, !noalias !33
  %35 = load ptr, ptr %1, align 16, !noalias !33, !dereferenceable !36, !align !36
  %36 = load i32, ptr %35, align 4, !noalias !33
  store i32 %36, ptr %copy.8.i, align 16, !noalias !33
  %37 = load i32, ptr %compare.1.i, align 16, !alias.scope !37, !noalias !39
  %shft.chk.i = icmp ult i32 %37, 32
  %38 = sub i32 32, %37
  %shft.chk1.i = icmp ult i32 %38, 32
  %39 = load i32, ptr %21, align 4, !alias.scope !37, !noalias !39
  %shft.chk2.i = icmp ult i32 %39, 32
  %40 = sub i32 32, %39
  %shft.chk4.i = icmp ult i32 %40, 32
  %41 = load i32, ptr %22, align 8, !alias.scope !37, !noalias !39
  %shft.chk5.i = icmp ult i32 %41, 32
  %42 = sub i32 32, %41
  %shft.chk7.i = icmp ult i32 %42, 32
  %43 = add i32 %34, 1
  %44 = add i32 %43, %36
  %45 = load i32, ptr %23, align 4, !alias.scope !37, !noalias !39
  %46 = sub i32 32, %45
  %shft.chk10.i = icmp ult i32 %46, 32
  %shft.chk8.i = icmp ult i32 %45, 32
  %47 = load i32, ptr %copy.9.i, align 16, !alias.scope !44, !noalias !45
  %48 = load i32, ptr %copy.26, align 16, !alias.scope !46, !noalias !47
  %49 = add i32 %48, %47
  %50 = shl i32 %48, %37
  %51 = select i1 %shft.chk.i, i32 %50, i32 0
  %52 = lshr i32 %48, %38
  %53 = select i1 %shft.chk1.i, i32 %52, i32 0
  %54 = or i32 %53, %51
  %55 = xor i32 %54, %49
  %56 = add i32 %55, %49
  %57 = shl i32 %55, %39
  %58 = select i1 %shft.chk2.i, i32 %57, i32 0
  %59 = lshr i32 %55, %40
  %60 = select i1 %shft.chk4.i, i32 %59, i32 0
  %61 = or i32 %58, %60
  %62 = xor i32 %61, %56
  %63 = add i32 %62, %56
  %64 = shl i32 %62, %41
  %65 = select i1 %shft.chk5.i, i32 %64, i32 0
  %66 = lshr i32 %62, %42
  %67 = select i1 %shft.chk7.i, i32 %66, i32 0
  %68 = or i32 %65, %67
  %69 = xor i32 %68, %63
  %70 = add i32 %69, %63
  %71 = shl i32 %69, %45
  %72 = select i1 %shft.chk8.i, i32 %71, i32 0
  %73 = lshr i32 %69, %46
  %74 = select i1 %shft.chk10.i, i32 %73, i32 0
  %75 = or i32 %72, %74
  %76 = xor i32 %75, %70
  %77 = add i32 %44, %76
  store i32 %77, ptr %fusion.2, align 16, !alias.scope !11, !noalias !48
  %78 = load i32, ptr %24, align 4, !alias.scope !44, !noalias !45
  %79 = load i32, ptr %25, align 4, !alias.scope !46, !noalias !47
  %80 = add i32 %79, %78
  %81 = shl i32 %79, %37
  %82 = select i1 %shft.chk.i, i32 %81, i32 0
  %83 = lshr i32 %79, %38
  %84 = select i1 %shft.chk1.i, i32 %83, i32 0
  %85 = or i32 %84, %82
  %86 = xor i32 %85, %80
  %87 = add i32 %86, %80
  %88 = shl i32 %86, %39
  %89 = select i1 %shft.chk2.i, i32 %88, i32 0
  %90 = lshr i32 %86, %40
  %91 = select i1 %shft.chk4.i, i32 %90, i32 0
  %92 = or i32 %89, %91
  %93 = xor i32 %92, %87
  %94 = add i32 %93, %87
  %95 = shl i32 %93, %41
  %96 = select i1 %shft.chk5.i, i32 %95, i32 0
  %97 = lshr i32 %93, %42
  %98 = select i1 %shft.chk7.i, i32 %97, i32 0
  %99 = or i32 %96, %98
  %100 = xor i32 %99, %94
  %101 = add i32 %100, %94
  %102 = shl i32 %100, %45
  %103 = select i1 %shft.chk8.i, i32 %102, i32 0
  %104 = lshr i32 %100, %46
  %105 = select i1 %shft.chk10.i, i32 %104, i32 0
  %106 = or i32 %103, %105
  %107 = xor i32 %106, %101
  %108 = add i32 %44, %107
  store i32 %108, ptr %26, align 4, !alias.scope !11, !noalias !48
  %109 = load ptr, ptr %16, align 8, !noalias !33, !dereferenceable !36, !align !36
  %110 = load i32, ptr %109, align 4, !noalias !33
  store i32 %110, ptr %fusion.1, align 16, !noalias !33
  %111 = load i32, ptr %copy.9.i, align 16, !alias.scope !44, !noalias !45
  %112 = load i32, ptr %copy.26, align 16, !alias.scope !46, !noalias !47
  %113 = add i32 %112, %111
  %114 = shl i32 %112, %37
  %115 = select i1 %shft.chk.i, i32 %114, i32 0
  %116 = lshr i32 %112, %38
  %117 = select i1 %shft.chk1.i, i32 %116, i32 0
  %118 = or i32 %117, %115
  %119 = xor i32 %118, %113
  %120 = add i32 %119, %113
  %121 = shl i32 %119, %39
  %122 = select i1 %shft.chk2.i, i32 %121, i32 0
  %123 = lshr i32 %119, %40
  %124 = select i1 %shft.chk4.i, i32 %123, i32 0
  %125 = or i32 %122, %124
  %126 = xor i32 %125, %120
  %127 = add i32 %126, %120
  %128 = shl i32 %126, %41
  %129 = select i1 %shft.chk5.i, i32 %128, i32 0
  %130 = lshr i32 %126, %42
  %131 = select i1 %shft.chk7.i, i32 %130, i32 0
  %132 = or i32 %129, %131
  %133 = xor i32 %132, %127
  %134 = add i32 %127, %110
  %135 = add i32 %134, %133
  store i32 %135, ptr %fusion.4, align 16, !alias.scope !17, !noalias !49
  %136 = load i32, ptr %27, align 4, !alias.scope !44, !noalias !45
  %137 = load i32, ptr %28, align 4, !alias.scope !46, !noalias !47
  %138 = add i32 %137, %136
  %139 = shl i32 %137, %37
  %140 = select i1 %shft.chk.i, i32 %139, i32 0
  %141 = lshr i32 %137, %38
  %142 = select i1 %shft.chk1.i, i32 %141, i32 0
  %143 = or i32 %142, %140
  %144 = xor i32 %143, %138
  %145 = add i32 %144, %138
  %146 = shl i32 %144, %39
  %147 = select i1 %shft.chk2.i, i32 %146, i32 0
  %148 = lshr i32 %144, %40
  %149 = select i1 %shft.chk4.i, i32 %148, i32 0
  %150 = or i32 %147, %149
  %151 = xor i32 %150, %145
  %152 = add i32 %151, %145
  %153 = shl i32 %151, %41
  %154 = select i1 %shft.chk5.i, i32 %153, i32 0
  %155 = lshr i32 %151, %42
  %156 = select i1 %shft.chk7.i, i32 %155, i32 0
  %157 = or i32 %154, %156
  %158 = xor i32 %157, %152
  %159 = add i32 %152, %110
  %160 = add i32 %159, %158
  store i32 %160, ptr %29, align 4, !alias.scope !17, !noalias !49
  %161 = load ptr, ptr %20, align 8, !noalias !33, !dereferenceable !2, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.9.i, ptr noundef nonnull align 16 dereferenceable(16) %161, i64 16, i1 false), !noalias !33
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.25, ptr noundef nonnull align 16 dereferenceable(16) %compare.1.i, i64 16, i1 false), !noalias !33
  %162 = add i32 %36, 1
  store i32 %162, ptr %copy.24, align 16, !alias.scope !50, !noalias !51
  store i32 %34, ptr %fusion.3, align 16, !noalias !33
  %163 = load ptr, ptr %18, align 8, !noalias !33, !dereferenceable !36, !align !36
  %164 = load i32, ptr %163, align 4, !noalias !33
  store i32 %164, ptr %compare.1.i, align 16, !noalias !33
  store i32 %110, ptr %fusion.5, align 16, !noalias !33
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.26, ptr noundef nonnull align 16 dereferenceable(16) %copy.9.i, i64 16, i1 false), !noalias !33
  %165 = load i32, ptr %compare.1.i, align 16, !noalias !33
  store i32 %165, ptr %fusion.1, align 16, !noalias !33
  store ptr %copy.24, ptr %1, align 16, !alias.scope !25, !noalias !53
  store ptr %fusion.4, ptr %14, align 8, !alias.scope !25, !noalias !53
  store ptr %fusion.2, ptr %15, align 16, !alias.scope !25, !noalias !53
  store ptr %fusion.3, ptr %16, align 8, !alias.scope !25, !noalias !53
  store ptr %fusion.1, ptr %17, align 16, !alias.scope !25, !noalias !53
  store ptr %fusion.5, ptr %18, align 8, !alias.scope !25, !noalias !53
  store ptr %copy.26, ptr %19, align 16, !alias.scope !25, !noalias !53
  store ptr %copy.25, ptr %20, align 8, !alias.scope !25, !noalias !26
  %166 = load i32, ptr %copy.24, align 16, !alias.scope !50, !noalias !54
  %167 = icmp slt i32 %166, 5
  %168 = zext i1 %167 to i8
  store i8 %168, ptr %compare.1.i, align 16, !alias.scope !27, !noalias !29
  br i1 %167, label %while.1.body, label %fusion.loop_header.dim.1.preheader

fusion.loop_header.dim.1.preheader:               ; preds = %while.1.body
  %169 = load i32, ptr %fusion.4, align 16, !alias.scope !55, !noalias !56
  store i32 %169, ptr %copy.26, align 16, !alias.scope !57, !noalias !55
  %170 = getelementptr inbounds i8, ptr %1, i64 116
  %171 = load i32, ptr %170, align 4, !alias.scope !55, !noalias !56
  %172 = getelementptr inbounds [2 x [2 x i32]], ptr %copy.26, i64 0, i64 0, i64 1
  store i32 %171, ptr %172, align 4, !alias.scope !57, !noalias !55
  %173 = load i32, ptr %fusion.2, align 16, !alias.scope !55, !noalias !56
  %174 = getelementptr inbounds [2 x [2 x i32]], ptr %copy.26, i64 0, i64 1, i64 0
  store i32 %173, ptr %174, align 8, !alias.scope !57, !noalias !55
  %175 = getelementptr inbounds i8, ptr %1, i64 132
  %176 = load i32, ptr %175, align 4, !alias.scope !55, !noalias !56
  %177 = getelementptr inbounds [2 x [2 x i32]], ptr %copy.26, i64 0, i64 1, i64 1
  store i32 %176, ptr %177, align 4, !alias.scope !57, !noalias !55
  ret void
}

attributes #0 = { inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #1 = { nofree nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }

!0 = !{}
!1 = !{i64 228}
!2 = !{i64 16}
!3 = !{i64 8}
!4 = !{!5, !7, !8, !9, !10}
!5 = !{!"buffer: {index:7, offset:112, size:8}", !6}
!6 = !{!"XLA global AA domain"}
!7 = !{!"buffer: {index:7, offset:128, size:8}", !6}
!8 = !{!"buffer: {index:7, offset:160, size:4}", !6}
!9 = !{!"buffer: {index:7, offset:192, size:4}", !6}
!10 = !{!"buffer: {index:7, offset:208, size:4}", !6}
!11 = !{!7}
!12 = !{!13, !14, !15, !5, !8, !16, !9, !10}
!13 = !{!"buffer: {index:1, offset:0, size:16}", !6}
!14 = !{!"buffer: {index:7, offset:0, size:64}", !6}
!15 = !{!"buffer: {index:7, offset:80, size:16}", !6}
!16 = !{!"buffer: {index:7, offset:176, size:4}", !6}
!17 = !{!5}
!18 = !{!13, !14, !15, !7, !8, !16, !9, !10}
!19 = !{!8}
!20 = !{!13, !14, !15, !5, !7, !16, !9, !10}
!21 = !{!9}
!22 = !{!13, !14, !15, !5, !7, !8, !16, !10}
!23 = !{!10}
!24 = !{!13, !14, !15, !5, !7, !8, !16, !9}
!25 = !{!14}
!26 = !{!13, !15, !5, !7, !8, !16, !9, !10}
!27 = !{!28}
!28 = !{!"buffer: {index:7, offset:64, size:1}", !6}
!29 = !{!30, !16, !31}
!30 = !{!"buffer: {index:6, offset:0, size:4}", !6}
!31 = distinct !{!31, !32, !"region_1.84.clone.clone: %buffer_table"}
!32 = distinct !{!32, !"region_1.84.clone.clone"}
!33 = !{!34}
!34 = distinct !{!34, !35, !"region_0.20.clone.clone.clone: %buffer_table"}
!35 = distinct !{!35, !"region_0.20.clone.clone.clone"}
!36 = !{i64 4}
!37 = !{!38}
!38 = !{!"buffer: {index:7, offset:64, size:16}", !6}
!39 = !{!40, !13, !15, !41, !5, !7, !42, !8, !43, !34}
!40 = !{!"buffer: {index:1, offset:0, size:8}", !6}
!41 = !{!"buffer: {index:7, offset:96, size:8}", !6}
!42 = !{!"buffer: {index:7, offset:144, size:4}", !6}
!43 = !{!"buffer: {index:7, offset:224, size:4}", !6}
!44 = !{!41}
!45 = !{!40, !38, !5, !7, !42, !8, !43, !34}
!46 = !{!40}
!47 = !{!38, !41, !5, !7, !42, !8, !43, !34}
!48 = !{!40, !13, !14, !38, !15, !41, !5, !42, !8, !16, !9, !10, !43, !34}
!49 = !{!40, !13, !14, !38, !15, !41, !7, !8, !16, !9, !10, !34}
!50 = !{!16}
!51 = !{!52, !13, !14, !15, !5, !7, !8, !9, !10, !43, !34}
!52 = !{!"buffer: {index:0, offset:0, size:4}", !6}
!53 = !{!13, !15, !5, !7, !8, !16, !9, !10, !34}
!54 = !{!30, !28, !31}
!55 = !{!5, !7}
!56 = !{!13, !14, !15, !8, !16, !9, !10}
!57 = !{!13}
