; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind uwtable
define void @main.3(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readnone %prof_counters) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !1
  %broadcast.2 = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !2, !align !3
  %1 = load float, ptr %Arg_0.1, align 4, !invariant.load !0, !noalias !4
  %broadcast.splatinsert = insertelement <8 x float> poison, float %1, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert2 = insertelement <8 x float> poison, float %1, i64 0
  %broadcast.splat3 = shufflevector <8 x float> %broadcast.splatinsert2, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert4 = insertelement <8 x float> poison, float %1, i64 0
  %broadcast.splat5 = shufflevector <8 x float> %broadcast.splatinsert4, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert6 = insertelement <8 x float> poison, float %1, i64 0
  %broadcast.splat7 = shufflevector <8 x float> %broadcast.splatinsert6, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next.7, %vector.body ]
  %2 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index
  store <8 x float> %broadcast.splat, ptr %2, align 16, !alias.scope !4
  %3 = getelementptr inbounds float, ptr %2, i64 8
  store <8 x float> %broadcast.splat3, ptr %3, align 16, !alias.scope !4
  %4 = getelementptr inbounds float, ptr %2, i64 16
  store <8 x float> %broadcast.splat5, ptr %4, align 16, !alias.scope !4
  %5 = getelementptr inbounds float, ptr %2, i64 24
  store <8 x float> %broadcast.splat7, ptr %5, align 16, !alias.scope !4
  %index.next = or i64 %index, 32
  %6 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next
  store <8 x float> %broadcast.splat, ptr %6, align 16, !alias.scope !4
  %7 = getelementptr inbounds float, ptr %6, i64 8
  store <8 x float> %broadcast.splat3, ptr %7, align 16, !alias.scope !4
  %8 = getelementptr inbounds float, ptr %6, i64 16
  store <8 x float> %broadcast.splat5, ptr %8, align 16, !alias.scope !4
  %9 = getelementptr inbounds float, ptr %6, i64 24
  store <8 x float> %broadcast.splat7, ptr %9, align 16, !alias.scope !4
  %index.next.1 = or i64 %index, 64
  %10 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.1
  store <8 x float> %broadcast.splat, ptr %10, align 16, !alias.scope !4
  %11 = getelementptr inbounds float, ptr %10, i64 8
  store <8 x float> %broadcast.splat3, ptr %11, align 16, !alias.scope !4
  %12 = getelementptr inbounds float, ptr %10, i64 16
  store <8 x float> %broadcast.splat5, ptr %12, align 16, !alias.scope !4
  %13 = getelementptr inbounds float, ptr %10, i64 24
  store <8 x float> %broadcast.splat7, ptr %13, align 16, !alias.scope !4
  %index.next.2 = or i64 %index, 96
  %14 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.2
  store <8 x float> %broadcast.splat, ptr %14, align 16, !alias.scope !4
  %15 = getelementptr inbounds float, ptr %14, i64 8
  store <8 x float> %broadcast.splat3, ptr %15, align 16, !alias.scope !4
  %16 = getelementptr inbounds float, ptr %14, i64 16
  store <8 x float> %broadcast.splat5, ptr %16, align 16, !alias.scope !4
  %17 = getelementptr inbounds float, ptr %14, i64 24
  store <8 x float> %broadcast.splat7, ptr %17, align 16, !alias.scope !4
  %index.next.3 = or i64 %index, 128
  %18 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.3
  store <8 x float> %broadcast.splat, ptr %18, align 16, !alias.scope !4
  %19 = getelementptr inbounds float, ptr %18, i64 8
  store <8 x float> %broadcast.splat3, ptr %19, align 16, !alias.scope !4
  %20 = getelementptr inbounds float, ptr %18, i64 16
  store <8 x float> %broadcast.splat5, ptr %20, align 16, !alias.scope !4
  %21 = getelementptr inbounds float, ptr %18, i64 24
  store <8 x float> %broadcast.splat7, ptr %21, align 16, !alias.scope !4
  %index.next.4 = or i64 %index, 160
  %22 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.4
  store <8 x float> %broadcast.splat, ptr %22, align 16, !alias.scope !4
  %23 = getelementptr inbounds float, ptr %22, i64 8
  store <8 x float> %broadcast.splat3, ptr %23, align 16, !alias.scope !4
  %24 = getelementptr inbounds float, ptr %22, i64 16
  store <8 x float> %broadcast.splat5, ptr %24, align 16, !alias.scope !4
  %25 = getelementptr inbounds float, ptr %22, i64 24
  store <8 x float> %broadcast.splat7, ptr %25, align 16, !alias.scope !4
  %index.next.5 = or i64 %index, 192
  %26 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.5
  store <8 x float> %broadcast.splat, ptr %26, align 16, !alias.scope !4
  %27 = getelementptr inbounds float, ptr %26, i64 8
  store <8 x float> %broadcast.splat3, ptr %27, align 16, !alias.scope !4
  %28 = getelementptr inbounds float, ptr %26, i64 16
  store <8 x float> %broadcast.splat5, ptr %28, align 16, !alias.scope !4
  %29 = getelementptr inbounds float, ptr %26, i64 24
  store <8 x float> %broadcast.splat7, ptr %29, align 16, !alias.scope !4
  %index.next.6 = or i64 %index, 224
  %30 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 %index.next.6
  store <8 x float> %broadcast.splat, ptr %30, align 16, !alias.scope !4
  %31 = getelementptr inbounds float, ptr %30, i64 8
  store <8 x float> %broadcast.splat3, ptr %31, align 16, !alias.scope !4
  %32 = getelementptr inbounds float, ptr %30, i64 16
  store <8 x float> %broadcast.splat5, ptr %32, align 16, !alias.scope !4
  %33 = getelementptr inbounds float, ptr %30, i64 24
  store <8 x float> %broadcast.splat7, ptr %33, align 16, !alias.scope !4
  %index.next.7 = add nuw nsw i64 %index, 256
  %34 = icmp eq i64 %index.next.7, 9984
  br i1 %34, label %broadcast.2.loop_body.dim.0, label %vector.body, !llvm.loop !7

broadcast.2.loop_body.dim.0:                      ; preds = %vector.body
  %35 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9984
  store float %1, ptr %35, align 16, !alias.scope !4
  %36 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9985
  store float %1, ptr %36, align 4, !alias.scope !4
  %37 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9986
  store float %1, ptr %37, align 8, !alias.scope !4
  %38 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9987
  store float %1, ptr %38, align 4, !alias.scope !4
  %39 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9988
  store float %1, ptr %39, align 16, !alias.scope !4
  %40 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9989
  store float %1, ptr %40, align 4, !alias.scope !4
  %41 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9990
  store float %1, ptr %41, align 8, !alias.scope !4
  %42 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9991
  store float %1, ptr %42, align 4, !alias.scope !4
  %43 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9992
  store float %1, ptr %43, align 16, !alias.scope !4
  %44 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9993
  store float %1, ptr %44, align 4, !alias.scope !4
  %45 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9994
  store float %1, ptr %45, align 8, !alias.scope !4
  %46 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9995
  store float %1, ptr %46, align 4, !alias.scope !4
  %47 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9996
  store float %1, ptr %47, align 16, !alias.scope !4
  %48 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9997
  store float %1, ptr %48, align 4, !alias.scope !4
  %49 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9998
  store float %1, ptr %49, align 8, !alias.scope !4
  %50 = getelementptr inbounds [10000 x float], ptr %broadcast.2, i64 0, i64 9999
  store float %1, ptr %50, align 4, !alias.scope !4
  ret void
}

attributes #0 = { nofree norecurse nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }

!0 = !{}
!1 = !{i64 4}
!2 = !{i64 40000}
!3 = !{i64 16}
!4 = !{!5}
!5 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!6 = !{!"XLA global AA domain"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.isvectorized", i32 1}
