; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: uwtable
define void @main.5(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %fusion.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds ptr, ptr %buffer_table, i64 2
  %Arg_1.2 = load ptr, ptr %1, align 8, !invariant.load !0, !dereferenceable !3, !align !3
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %fusion = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  store i64 0, ptr %fusion.invar_address.dim.0, align 8
  br label %fusion.loop_header.dim.0

return:                                           ; preds = %fusion.loop_exit.dim.0
  ret void

fusion.loop_header.dim.0:                         ; preds = %fusion.loop_body.dim.0, %entry
  %fusion.indvar.dim.0 = load i64, ptr %fusion.invar_address.dim.0, align 8
  %3 = icmp uge i64 %fusion.indvar.dim.0, 10000
  br i1 %3, label %fusion.loop_exit.dim.0, label %fusion.loop_body.dim.0

fusion.loop_body.dim.0:                           ; preds = %fusion.loop_header.dim.0
  %4 = getelementptr inbounds [10000 x float], ptr %Arg_0.1, i64 0, i64 %fusion.indvar.dim.0
  %5 = load float, ptr %4, align 4, !invariant.load !0, !noalias !4
  %6 = load float, ptr %Arg_1.2, align 4, !invariant.load !0, !noalias !4
  %subtract.0 = fsub float %5, %6
  %7 = getelementptr inbounds [10000 x float], ptr %fusion, i64 0, i64 %fusion.indvar.dim.0
  store float %subtract.0, ptr %7, align 4, !alias.scope !4
  %invar.inc = add nuw nsw i64 %fusion.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.invar_address.dim.0, align 8
  br label %fusion.loop_header.dim.0

fusion.loop_exit.dim.0:                           ; preds = %fusion.loop_header.dim.0
  br label %return
}

attributes #0 = { uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }

!0 = !{}
!1 = !{i64 40000}
!2 = !{i64 16}
!3 = !{i64 4}
!4 = !{!5}
!5 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!6 = !{!"XLA global AA domain"}
