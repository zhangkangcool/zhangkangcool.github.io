; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@constant.67 = external dso_local unnamed_addr constant [4 x i8], align 4
@constant.17 = external dso_local unnamed_addr constant [16 x i8], align 16
@constant.16 = external dso_local unnamed_addr constant [16 x i8], align 16
@constant.14 = external dso_local unnamed_addr constant [4 x i8], align 4
@constant.68 = external dso_local unnamed_addr constant [4 x i8], align 4
@0 = external dso_local unnamed_addr constant [4 x i8]
@1 = external dso_local unnamed_addr constant [4 x i8]
@2 = external dso_local unnamed_addr constant [4 x i8]
@3 = external dso_local unnamed_addr constant [4 x i8]
@4 = external dso_local unnamed_addr constant [4 x i8]
@5 = external dso_local unnamed_addr constant [4 x i8]
@6 = external dso_local unnamed_addr constant [4 x i8]
@7 = external dso_local unnamed_addr constant [4 x i8]
@8 = external dso_local unnamed_addr constant [4 x i8]
@9 = external dso_local unnamed_addr constant [4 x i8]
@10 = external dso_local unnamed_addr constant [4 x i8]
@11 = external dso_local unnamed_addr constant [4 x i8]
@12 = external dso_local unnamed_addr constant [4 x i8]
@13 = external dso_local unnamed_addr constant [4 x i8]
@14 = external dso_local unnamed_addr constant [4 x i8]
@15 = external dso_local unnamed_addr constant [4 x i8]
@16 = external dso_local unnamed_addr constant [4 x i8]
@17 = external dso_local unnamed_addr constant [4 x i8]
@18 = external dso_local unnamed_addr constant [4 x i8]
@19 = external dso_local unnamed_addr constant [4 x i8]
@20 = external dso_local unnamed_addr constant [4 x i8]
@21 = external dso_local unnamed_addr constant [4 x i8]
@22 = external dso_local unnamed_addr constant [4 x i8]
@23 = external dso_local unnamed_addr constant [4 x i8]
@24 = external dso_local unnamed_addr constant [4 x i8]
@25 = external dso_local unnamed_addr constant [4 x i8]
@26 = external dso_local unnamed_addr constant [4 x i8]
@27 = external dso_local unnamed_addr constant [4 x i8]
@28 = external dso_local unnamed_addr constant [4 x i8]
@29 = external dso_local unnamed_addr constant [4 x i8]
@30 = external dso_local unnamed_addr constant [4 x i8]
@31 = external dso_local unnamed_addr constant [4 x i8]
@parallel_fusion_parallel_dimension_partitions = external dso_local constant [14 x i64]
@parallel_fusion.1_parallel_dimension_partitions = external dso_local constant [12 x i64]
@32 = external dso_local unnamed_addr constant [4 x i8]
@parallel_fusion.2_parallel_dimension_partitions = external dso_local constant [16 x i64]

; Function Attrs: uwtable
define internal void @parallel_fusion.2(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %dynamic_loop_bounds, ptr noalias %prof_counters) #0 {
entry:
  %fusion.2.clone.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.10 = getelementptr inbounds i8, ptr %1, i64 20064
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %3 = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.9 = getelementptr inbounds i8, ptr %3, i64 64
  %4 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %fusion.2.clone = load ptr, ptr %4, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %5 = getelementptr i64, ptr %dynamic_loop_bounds, i64 0
  %dynamic_loop_bound_0 = load i64, ptr %5, align 8
  %6 = getelementptr i64, ptr %dynamic_loop_bounds, i64 1
  %dynamic_loop_bound_1 = load i64, ptr %6, align 8
  store i64 %dynamic_loop_bound_0, ptr %fusion.2.clone.invar_address.dim.0, align 8
  br label %fusion.2.clone.loop_header.dim.0

return:                                           ; preds = %fusion.2.clone.loop_exit.dim.0
  ret void

fusion.2.clone.loop_header.dim.0:                 ; preds = %concatenate.1.merge, %entry
  %fusion.2.clone.indvar.dim.0 = load i64, ptr %fusion.2.clone.invar_address.dim.0, align 8
  %7 = icmp uge i64 %fusion.2.clone.indvar.dim.0, %dynamic_loop_bound_1
  br i1 %7, label %fusion.2.clone.loop_exit.dim.0, label %fusion.2.clone.loop_body.dim.0

fusion.2.clone.loop_body.dim.0:                   ; preds = %fusion.2.clone.loop_header.dim.0
  br label %concatenate.pivot.5000.

concat_index_from_operand_id0:                    ; preds = %concatenate.pivot.0.
  %8 = phi i64 [ 0, %concatenate.pivot.0. ]
  %9 = sub nsw i64 %fusion.2.clone.indvar.dim.0, %8
  %10 = getelementptr inbounds [5000 x i32], ptr %p.9, i64 0, i64 %9
  %11 = load i32, ptr %10, align 4, !alias.scope !4, !noalias !7
  br label %concatenate.1.merge

concat_index_from_operand_id1:                    ; preds = %concatenate.pivot.5000.1
  %12 = phi i64 [ 5000, %concatenate.pivot.5000.1 ]
  %13 = sub nsw i64 %fusion.2.clone.indvar.dim.0, %12
  %14 = getelementptr inbounds [5000 x i32], ptr %p.10, i64 0, i64 %13
  %15 = load i32, ptr %14, align 4, !alias.scope !9, !noalias !7
  br label %concatenate.1.merge

concatenate.pivot.5000.:                          ; preds = %fusion.2.clone.loop_body.dim.0
  %16 = icmp ult i64 %fusion.2.clone.indvar.dim.0, 5000
  br i1 %16, label %concatenate.pivot.0., label %concatenate.pivot.5000.1

concatenate.pivot.0.:                             ; preds = %concatenate.pivot.5000.
  br label %concat_index_from_operand_id0

concatenate.pivot.5000.1:                         ; preds = %concatenate.pivot.5000.
  br label %concat_index_from_operand_id1

concatenate.1.merge:                              ; preds = %concat_index_from_operand_id1, %concat_index_from_operand_id0
  %17 = phi i32 [ %11, %concat_index_from_operand_id0 ], [ %15, %concat_index_from_operand_id1 ]
  %constant.140 = load i32, ptr @5, align 4
  %18 = lshr i32 %17, %constant.140
  %shft.chk = icmp ult i32 %constant.140, 32
  %19 = select i1 %shft.chk, i32 %18, i32 0
  %constant.138 = load i32, ptr @4, align 4
  %20 = or i32 %19, %constant.138
  %21 = bitcast i32 %20 to float
  %constant.136 = load float, ptr @3, align 4
  %add.114 = fadd float %21, %constant.136
  %constant.134 = load float, ptr @2, align 4
  %multiply.51 = fmul float %add.114, %constant.134
  %constant.132 = load float, ptr @1, align 4
  %add.113 = fadd float %multiply.51, %constant.132
  %22 = fcmp oge float %add.113, %constant.132
  %23 = fcmp une float %add.113, %add.113
  %24 = or i1 %22, %23
  %maximum.1 = select i1 %24, float %add.113, float %constant.132
  %25 = call float @llvm.fabs.f32(float %maximum.1)
  %constant.130 = load float, ptr @28, align 4
  %compare.9 = fcmp oeq float %25, %constant.130
  %26 = zext i1 %compare.9 to i8
  %constant.128 = load float, ptr @27, align 4
  %multiply.50 = fmul float %maximum.1, %constant.128
  %27 = fneg float %maximum.1
  %multiply.49 = fmul float %27, %maximum.1
  %28 = fadd float %multiply.49, 1.000000e+00
  %29 = call float @llvm.log.f32(float %28)
  %30 = fmul float %multiply.49, %multiply.49
  %31 = fmul float 0.000000e+00, %multiply.49
  %32 = fadd float %31, 1.000000e+00
  %33 = fmul float %32, %multiply.49
  %34 = fadd float %33, 0x402E2035A0000000
  %35 = fmul float %34, %multiply.49
  %36 = fadd float %35, 0x4054C30B60000000
  %37 = fmul float %36, %multiply.49
  %38 = fadd float %37, 0x406BB865A0000000
  %39 = fmul float %38, %multiply.49
  %40 = fadd float %39, 0x4073519460000000
  %41 = fmul float %40, %multiply.49
  %42 = fadd float %41, 0x406B0DB140000000
  %43 = fmul float %42, %multiply.49
  %44 = fadd float %43, 0x404E0F3040000000
  %45 = fmul float 0.000000e+00, %multiply.49
  %46 = fadd float %45, 0x3F07BC0960000000
  %47 = fmul float %46, %multiply.49
  %48 = fadd float %47, 0x3FDFE818A0000000
  %49 = fmul float %48, %multiply.49
  %50 = fadd float %49, 0x401A509F40000000
  %51 = fmul float %50, %multiply.49
  %52 = fadd float %51, 0x403DE97380000000
  %53 = fmul float %52, %multiply.49
  %54 = fadd float %53, 0x404E798EC0000000
  %55 = fmul float %54, %multiply.49
  %56 = fadd float %55, 0x404C8E75A0000000
  %57 = fmul float %56, %multiply.49
  %58 = fadd float %57, 0x40340A2020000000
  %59 = fdiv float %58, %44
  %60 = fmul float %multiply.49, %30
  %61 = fmul float %60, %59
  %62 = fmul float -5.000000e-01, %30
  %63 = fadd float %62, %61
  %64 = fadd float %multiply.49, %63
  %65 = call float @llvm.fabs.f32(float %multiply.49)
  %66 = fcmp olt float %65, 0x3FDA8279A0000000
  %67 = select i1 %66, float %64, float %29
  %68 = fneg float %67
  %constant.127 = load float, ptr @8, align 4
  %compare.8 = fcmp olt float %68, %constant.127
  %69 = zext i1 %compare.8 to i8
  %constant.126 = load float, ptr @26, align 4
  %constant.125 = load float, ptr @25, align 4
  %70 = trunc i8 %69 to i1
  %71 = select i1 %70, float %constant.126, float %constant.125
  %constant.124 = load float, ptr @24, align 4
  %constant.123 = load float, ptr @23, align 4
  %72 = trunc i8 %69 to i1
  %73 = select i1 %72, float %constant.124, float %constant.123
  %constant.122 = load float, ptr @22, align 4
  %constant.121 = load float, ptr @21, align 4
  %74 = trunc i8 %69 to i1
  %75 = select i1 %74, float %constant.122, float %constant.121
  %constant.120 = load float, ptr @20, align 4
  %constant.119 = load float, ptr @19, align 4
  %76 = trunc i8 %69 to i1
  %77 = select i1 %76, float %constant.120, float %constant.119
  %constant.118 = load float, ptr @18, align 4
  %constant.117 = load float, ptr @17, align 4
  %78 = trunc i8 %69 to i1
  %79 = select i1 %78, float %constant.118, float %constant.117
  %constant.116 = load float, ptr @16, align 4
  %constant.115 = load float, ptr @15, align 4
  %80 = trunc i8 %69 to i1
  %81 = select i1 %80, float %constant.116, float %constant.115
  %constant.114 = load float, ptr @14, align 4
  %constant.113 = load float, ptr @13, align 4
  %82 = trunc i8 %69 to i1
  %83 = select i1 %82, float %constant.114, float %constant.113
  %constant.112 = load float, ptr @12, align 4
  %constant.111 = load float, ptr @11, align 4
  %84 = trunc i8 %69 to i1
  %85 = select i1 %84, float %constant.112, float %constant.111
  %constant.110 = load float, ptr @10, align 4
  %constant.109 = load float, ptr @9, align 4
  %86 = trunc i8 %69 to i1
  %87 = select i1 %86, float %constant.110, float %constant.109
  %constant.108 = load float, ptr @7, align 4
  %add.112 = fadd float %68, %constant.108
  %88 = call float @llvm.sqrt.f32(float %68)
  %constant.106 = load float, ptr @6, align 4
  %add.111 = fadd float %88, %constant.106
  %89 = trunc i8 %69 to i1
  %90 = select i1 %89, float %add.112, float %add.111
  %multiply.48 = fmul float %87, %90
  %add.110 = fadd float %85, %multiply.48
  %multiply.47 = fmul float %add.110, %90
  %add.109 = fadd float %83, %multiply.47
  %multiply.46 = fmul float %add.109, %90
  %add.108 = fadd float %81, %multiply.46
  %multiply.45 = fmul float %add.108, %90
  %add.107 = fadd float %79, %multiply.45
  %multiply.44 = fmul float %add.107, %90
  %add.106 = fadd float %77, %multiply.44
  %multiply.43 = fmul float %add.106, %90
  %add.105 = fadd float %75, %multiply.43
  %multiply.42 = fmul float %add.105, %90
  %add.104 = fadd float %73, %multiply.42
  %multiply.41 = fmul float %add.104, %90
  %add.103 = fadd float %71, %multiply.41
  %multiply.40 = fmul float %add.103, %maximum.1
  %91 = trunc i8 %26 to i1
  %92 = select i1 %91, float %multiply.50, float %multiply.40
  %constant.105 = load float, ptr @0, align 4
  %multiply.39 = fmul float %92, %constant.105
  %93 = getelementptr inbounds [10000 x float], ptr %fusion.2.clone, i64 0, i64 %fusion.2.clone.indvar.dim.0
  store float %multiply.39, ptr %93, align 4, !alias.scope !7
  %invar.inc = add nuw nsw i64 %fusion.2.clone.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.2.clone.invar_address.dim.0, align 8
  br label %fusion.2.clone.loop_header.dim.0

fusion.2.clone.loop_exit.dim.0:                   ; preds = %fusion.2.clone.loop_header.dim.0
  br label %return
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #1

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.log.f32(float) #1

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.sqrt.f32(float) #1

; Function Attrs: uwtable
define internal void @parallel_fusion.1(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %dynamic_loop_bounds, ptr noalias %prof_counters) #0 {
entry:
  %fusion.1.clone.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.5 = getelementptr inbounds i8, ptr %1, i64 60112
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %3 = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.6 = getelementptr inbounds i8, ptr %3, i64 60064
  %4 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %p.7 = load ptr, ptr %4, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %5 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %6 = load ptr, ptr %5, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.8 = getelementptr inbounds i8, ptr %6, i64 40064
  %7 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %8 = load ptr, ptr %7, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.1.clone = getelementptr inbounds i8, ptr %8, i64 64
  %9 = getelementptr i64, ptr %dynamic_loop_bounds, i64 0
  %dynamic_loop_bound_0 = load i64, ptr %9, align 8
  %10 = getelementptr i64, ptr %dynamic_loop_bounds, i64 1
  %dynamic_loop_bound_1 = load i64, ptr %10, align 8
  store i64 %dynamic_loop_bound_0, ptr %fusion.1.clone.invar_address.dim.0, align 8
  br label %fusion.1.clone.loop_header.dim.0

return:                                           ; preds = %fusion.1.clone.loop_exit.dim.0
  ret void

fusion.1.clone.loop_header.dim.0:                 ; preds = %fusion.1.clone.loop_body.dim.0, %entry
  %fusion.1.clone.indvar.dim.0 = load i64, ptr %fusion.1.clone.invar_address.dim.0, align 8
  %11 = icmp uge i64 %fusion.1.clone.indvar.dim.0, %dynamic_loop_bound_1
  br i1 %11, label %fusion.1.clone.loop_exit.dim.0, label %fusion.1.clone.loop_body.dim.0

fusion.1.clone.loop_body.dim.0:                   ; preds = %fusion.1.clone.loop_header.dim.0
  %12 = getelementptr inbounds [5000 x i32], ptr %p.8, i64 0, i64 %fusion.1.clone.indvar.dim.0
  %13 = load i32, ptr %12, align 4, !alias.scope !11, !noalias !4
  %14 = getelementptr inbounds [5000 x i32], ptr %p.7, i64 0, i64 %fusion.1.clone.indvar.dim.0
  %15 = load i32, ptr %14, align 4, !alias.scope !13, !noalias !4
  %16 = add i32 %13, %15
  %17 = getelementptr inbounds [5000 x i32], ptr %p.7, i64 0, i64 %fusion.1.clone.indvar.dim.0
  %18 = load i32, ptr %17, align 4, !alias.scope !13, !noalias !4
  %19 = getelementptr inbounds [4 x i32], ptr %p.6, i64 0, i64 0
  %20 = load i32, ptr %19, align 4, !alias.scope !15, !noalias !4
  %21 = shl i32 %18, %20
  %shft.chk = icmp ult i32 %20, 32
  %22 = select i1 %shft.chk, i32 %21, i32 0
  %23 = getelementptr inbounds [5000 x i32], ptr %p.7, i64 0, i64 %fusion.1.clone.indvar.dim.0
  %24 = load i32, ptr %23, align 4, !alias.scope !13, !noalias !4
  %constant.104 = load i32, ptr @29, align 4
  %25 = sub i32 %constant.104, %20
  %26 = lshr i32 %24, %25
  %shft.chk1 = icmp ult i32 %25, 32
  %27 = select i1 %shft.chk1, i32 %26, i32 0
  %28 = or i32 %22, %27
  %29 = xor i32 %16, %28
  %30 = add i32 %16, %29
  %31 = getelementptr inbounds [4 x i32], ptr %p.6, i64 0, i64 1
  %32 = load i32, ptr %31, align 4, !alias.scope !15, !noalias !4
  %33 = shl i32 %29, %32
  %shft.chk2 = icmp ult i32 %32, 32
  %34 = select i1 %shft.chk2, i32 %33, i32 0
  %constant.1043 = load i32, ptr @29, align 4
  %35 = sub i32 %constant.1043, %32
  %36 = lshr i32 %29, %35
  %shft.chk4 = icmp ult i32 %35, 32
  %37 = select i1 %shft.chk4, i32 %36, i32 0
  %38 = or i32 %34, %37
  %39 = xor i32 %30, %38
  %40 = add i32 %30, %39
  %41 = getelementptr inbounds [4 x i32], ptr %p.6, i64 0, i64 2
  %42 = load i32, ptr %41, align 4, !alias.scope !15, !noalias !4
  %43 = shl i32 %39, %42
  %shft.chk5 = icmp ult i32 %42, 32
  %44 = select i1 %shft.chk5, i32 %43, i32 0
  %constant.1046 = load i32, ptr @29, align 4
  %45 = sub i32 %constant.1046, %42
  %46 = lshr i32 %39, %45
  %shft.chk7 = icmp ult i32 %45, 32
  %47 = select i1 %shft.chk7, i32 %46, i32 0
  %48 = or i32 %44, %47
  %49 = xor i32 %40, %48
  %50 = add i32 %40, %49
  %51 = load i32, ptr %p.5, align 4, !alias.scope !17, !noalias !4
  %52 = add i32 %50, %51
  %53 = getelementptr inbounds [5000 x i32], ptr %fusion.1.clone, i64 0, i64 %fusion.1.clone.indvar.dim.0
  store i32 %52, ptr %53, align 4, !alias.scope !4
  %invar.inc = add nuw nsw i64 %fusion.1.clone.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.1.clone.invar_address.dim.0, align 8
  br label %fusion.1.clone.loop_header.dim.0

fusion.1.clone.loop_exit.dim.0:                   ; preds = %fusion.1.clone.loop_header.dim.0
  br label %return
}

; Function Attrs: uwtable
define internal void @parallel_fusion(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %dynamic_loop_bounds, ptr noalias %prof_counters) #0 {
entry:
  %fusion.clone.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p = getelementptr inbounds i8, ptr %1, i64 60096
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %3 = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.1 = getelementptr inbounds i8, ptr %3, i64 60064
  %4 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %p.2 = load ptr, ptr %4, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %5 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %6 = load ptr, ptr %5, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.3 = getelementptr inbounds i8, ptr %6, i64 40064
  %7 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %8 = load ptr, ptr %7, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.4 = getelementptr inbounds i8, ptr %8, i64 60176
  %9 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %10 = load ptr, ptr %9, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.clone = getelementptr inbounds i8, ptr %10, i64 20064
  %11 = getelementptr i64, ptr %dynamic_loop_bounds, i64 0
  %dynamic_loop_bound_0 = load i64, ptr %11, align 8
  %12 = getelementptr i64, ptr %dynamic_loop_bounds, i64 1
  %dynamic_loop_bound_1 = load i64, ptr %12, align 8
  store i64 %dynamic_loop_bound_0, ptr %fusion.clone.invar_address.dim.0, align 8
  br label %fusion.clone.loop_header.dim.0

return:                                           ; preds = %fusion.clone.loop_exit.dim.0
  ret void

fusion.clone.loop_header.dim.0:                   ; preds = %fusion.clone.loop_body.dim.0, %entry
  %fusion.clone.indvar.dim.0 = load i64, ptr %fusion.clone.invar_address.dim.0, align 8
  %13 = icmp uge i64 %fusion.clone.indvar.dim.0, %dynamic_loop_bound_1
  br i1 %13, label %fusion.clone.loop_exit.dim.0, label %fusion.clone.loop_body.dim.0

fusion.clone.loop_body.dim.0:                     ; preds = %fusion.clone.loop_header.dim.0
  %14 = getelementptr inbounds [5000 x i32], ptr %p.3, i64 0, i64 %fusion.clone.indvar.dim.0
  %15 = load i32, ptr %14, align 4, !alias.scope !11, !noalias !9
  %16 = getelementptr inbounds [5000 x i32], ptr %p.2, i64 0, i64 %fusion.clone.indvar.dim.0
  %17 = load i32, ptr %16, align 4, !alias.scope !13, !noalias !9
  %18 = add i32 %15, %17
  %19 = getelementptr inbounds [5000 x i32], ptr %p.2, i64 0, i64 %fusion.clone.indvar.dim.0
  %20 = load i32, ptr %19, align 4, !alias.scope !13, !noalias !9
  %21 = getelementptr inbounds [4 x i32], ptr %p.1, i64 0, i64 0
  %22 = load i32, ptr %21, align 4, !alias.scope !15, !noalias !9
  %23 = shl i32 %20, %22
  %shft.chk = icmp ult i32 %22, 32
  %24 = select i1 %shft.chk, i32 %23, i32 0
  %25 = getelementptr inbounds [5000 x i32], ptr %p.2, i64 0, i64 %fusion.clone.indvar.dim.0
  %26 = load i32, ptr %25, align 4, !alias.scope !13, !noalias !9
  %constant.102 = load i32, ptr @31, align 4
  %27 = sub i32 %constant.102, %22
  %28 = lshr i32 %26, %27
  %shft.chk1 = icmp ult i32 %27, 32
  %29 = select i1 %shft.chk1, i32 %28, i32 0
  %30 = or i32 %24, %29
  %31 = xor i32 %18, %30
  %32 = add i32 %18, %31
  %33 = getelementptr inbounds [4 x i32], ptr %p.1, i64 0, i64 1
  %34 = load i32, ptr %33, align 4, !alias.scope !15, !noalias !9
  %35 = shl i32 %31, %34
  %shft.chk2 = icmp ult i32 %34, 32
  %36 = select i1 %shft.chk2, i32 %35, i32 0
  %constant.1023 = load i32, ptr @31, align 4
  %37 = sub i32 %constant.1023, %34
  %38 = lshr i32 %31, %37
  %shft.chk4 = icmp ult i32 %37, 32
  %39 = select i1 %shft.chk4, i32 %38, i32 0
  %40 = or i32 %36, %39
  %41 = xor i32 %32, %40
  %42 = add i32 %32, %41
  %43 = getelementptr inbounds [4 x i32], ptr %p.1, i64 0, i64 2
  %44 = load i32, ptr %43, align 4, !alias.scope !15, !noalias !9
  %45 = shl i32 %41, %44
  %shft.chk5 = icmp ult i32 %44, 32
  %46 = select i1 %shft.chk5, i32 %45, i32 0
  %constant.1026 = load i32, ptr @31, align 4
  %47 = sub i32 %constant.1026, %44
  %48 = lshr i32 %41, %47
  %shft.chk7 = icmp ult i32 %47, 32
  %49 = select i1 %shft.chk7, i32 %48, i32 0
  %50 = or i32 %46, %49
  %51 = xor i32 %42, %50
  %52 = add i32 %42, %51
  %53 = getelementptr inbounds [4 x i32], ptr %p.1, i64 0, i64 3
  %54 = load i32, ptr %53, align 4, !alias.scope !15, !noalias !9
  %55 = shl i32 %51, %54
  %shft.chk8 = icmp ult i32 %54, 32
  %56 = select i1 %shft.chk8, i32 %55, i32 0
  %constant.1029 = load i32, ptr @31, align 4
  %57 = sub i32 %constant.1029, %54
  %58 = lshr i32 %51, %57
  %shft.chk10 = icmp ult i32 %57, 32
  %59 = select i1 %shft.chk10, i32 %58, i32 0
  %60 = or i32 %56, %59
  %61 = xor i32 %52, %60
  %62 = load i32, ptr %p, align 4, !alias.scope !19, !noalias !9
  %63 = add i32 %61, %62
  %64 = load i32, ptr %p.4, align 4, !alias.scope !21, !noalias !9
  %constant.103 = load i32, ptr @30, align 4
  %65 = add i32 %64, %constant.103
  %66 = add i32 %63, %65
  %67 = getelementptr inbounds [5000 x i32], ptr %fusion.clone, i64 0, i64 %fusion.clone.indvar.dim.0
  store i32 %66, ptr %67, align 4, !alias.scope !9
  %invar.inc = add nuw nsw i64 %fusion.clone.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.clone.invar_address.dim.0, align 8
  br label %fusion.clone.loop_header.dim.0

fusion.clone.loop_exit.dim.0:                     ; preds = %fusion.clone.loop_header.dim.0
  br label %return
}

; Function Attrs: uwtable
define internal void @region_0.32.clone.clone.clone(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %arg_tuple.3 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 6
  %2 = load ptr, ptr %1, align 8, !dereferenceable !2, !align !2
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %4 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.14 = getelementptr inbounds i8, ptr %4, i64 60064
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.14, ptr align 1 %2, i64 16, i1 false)
  %5 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 2
  %6 = load ptr, ptr %5, align 8, !dereferenceable !23, !align !2
  %7 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %copy.10 = load ptr, ptr %7, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.10, ptr align 1 %6, i64 20000, i1 false)
  %8 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 1
  %9 = load ptr, ptr %8, align 8, !dereferenceable !23, !align !2
  %10 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %11 = load ptr, ptr %10, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.9 = getelementptr inbounds i8, ptr %11, i64 40064
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.9, ptr align 1 %9, i64 20000, i1 false)
  %12 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 4
  %13 = load ptr, ptr %12, align 8, !dereferenceable !24, !align !24
  %14 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %15 = load ptr, ptr %14, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.12 = getelementptr inbounds i8, ptr %15, i64 60096
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.12, ptr align 1 %13, i64 4, i1 false)
  %16 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 0
  %17 = load ptr, ptr %16, align 8, !dereferenceable !24, !align !24
  %18 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %19 = load ptr, ptr %18, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.8 = getelementptr inbounds i8, ptr %19, i64 60176
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.8, ptr align 1 %17, i64 4, i1 false)
  %20 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %21 = load ptr, ptr %20, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %call = getelementptr inbounds i8, ptr %21, i64 20064
  call void @__xla_cpu_runtime_ParallelForkJoin(ptr %call, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters, i32 7, ptr @parallel_fusion_parallel_dimension_partitions, i32 1, ptr @parallel_fusion)
  %22 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 3
  %23 = load ptr, ptr %22, align 8, !dereferenceable !24, !align !24
  %24 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %25 = load ptr, ptr %24, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.11 = getelementptr inbounds i8, ptr %25, i64 60112
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.11, ptr align 1 %23, i64 4, i1 false)
  %26 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %27 = load ptr, ptr %26, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %call.1 = getelementptr inbounds i8, ptr %27, i64 64
  call void @__xla_cpu_runtime_ParallelForkJoin(ptr %call.1, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters, i32 6, ptr @parallel_fusion.1_parallel_dimension_partitions, i32 1, ptr @parallel_fusion.1)
  %28 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 7
  %29 = load ptr, ptr %28, align 8, !dereferenceable !2, !align !2
  %30 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %31 = load ptr, ptr %30, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.15 = getelementptr inbounds i8, ptr %31, i64 40064
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.15, ptr align 1 %29, i64 16, i1 false)
  %32 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %33 = load ptr, ptr %32, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.23 = getelementptr inbounds i8, ptr %33, i64 60080
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.23, ptr align 1 %copy.14, i64 16, i1 false)
  %34 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %35 = load ptr, ptr %34, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %add.55 = getelementptr inbounds i8, ptr %35, i64 60128
  %36 = load i32, ptr %copy.8, align 4, !alias.scope !21, !noalias !25
  %37 = load i32, ptr @constant.67, align 4, !alias.scope !28, !noalias !29
  %38 = add i32 %36, %37
  store i32 %38, ptr %add.55, align 4, !alias.scope !30, !noalias !31
  %39 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %40 = load ptr, ptr %39, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.19 = getelementptr inbounds i8, ptr %40, i64 60144
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.19, ptr align 1 %copy.12, i64 4, i1 false)
  %41 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 5
  %42 = load ptr, ptr %41, align 8, !dereferenceable !24, !align !24
  %43 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %44 = load ptr, ptr %43, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.13 = getelementptr inbounds i8, ptr %44, i64 60096
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.13, ptr align 1 %42, i64 4, i1 false)
  %45 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %46 = load ptr, ptr %45, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.21 = getelementptr inbounds i8, ptr %46, i64 60160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.21, ptr align 1 %copy.11, i64 4, i1 false)
  %47 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %copy.22 = load ptr, ptr %47, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.22, ptr align 1 %copy.15, i64 16, i1 false)
  %48 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %49 = load ptr, ptr %48, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.20 = getelementptr inbounds i8, ptr %49, i64 60112
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.20, ptr align 1 %copy.13, i64 4, i1 false)
  %50 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %tuple.11 = load ptr, ptr %50, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %51 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 0
  store ptr %add.55, ptr %51, align 8, !alias.scope !37, !noalias !38
  %52 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 1
  store ptr %call.1, ptr %52, align 8, !alias.scope !37, !noalias !38
  %53 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 2
  store ptr %call, ptr %53, align 8, !alias.scope !37, !noalias !38
  %54 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 3
  store ptr %copy.19, ptr %54, align 8, !alias.scope !37, !noalias !38
  %55 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 4
  store ptr %copy.20, ptr %55, align 8, !alias.scope !37, !noalias !38
  %56 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 5
  store ptr %copy.21, ptr %56, align 8, !alias.scope !37, !noalias !38
  %57 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 6
  store ptr %copy.22, ptr %57, align 8, !alias.scope !37, !noalias !38
  %58 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 7
  store ptr %copy.23, ptr %58, align 8, !alias.scope !37, !noalias !38
  br label %return

return:                                           ; preds = %entry
  ret void
}

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: nounwind
declare void @__xla_cpu_runtime_ParallelForkJoin(ptr, ptr, ptr, ptr, ptr, ptr, i32, ptr, i32, ptr) #3

; Function Attrs: uwtable
define internal void @region_1.96.clone.clone(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %arg_tuple.4 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.4, i64 0, i64 0
  %2 = load ptr, ptr %1, align 8, !dereferenceable !24, !align !24
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %4 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %compare.5 = getelementptr inbounds i8, ptr %4, i64 60096
  %5 = load i32, ptr %2, align 4, !alias.scope !30, !noalias !39
  %6 = load i32, ptr @constant.68, align 4, !alias.scope !42, !noalias !43
  %7 = icmp slt i32 %5, %6
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %compare.5, align 1, !alias.scope !44, !noalias !45
  br label %return

return:                                           ; preds = %entry
  ret void
}

; Function Attrs: uwtable
define void @main.219(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %fusion.6.invar_address.dim.0 = alloca i64, align 8
  %fusion.4.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 4
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !46, !align !46
  %1 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %2 = load ptr, ptr %1, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.4 = getelementptr inbounds i8, ptr %2, i64 20064
  store i64 0, ptr %fusion.4.invar_address.dim.0, align 8
  br label %fusion.4.loop_header.dim.0

return:                                           ; preds = %while.1.exit
  ret void

fusion.4.loop_header.dim.0:                       ; preds = %fusion.4.loop_body.dim.0, %entry
  %fusion.4.indvar.dim.0 = load i64, ptr %fusion.4.invar_address.dim.0, align 8
  %3 = icmp uge i64 %fusion.4.indvar.dim.0, 5000
  br i1 %3, label %fusion.4.loop_exit.dim.0, label %fusion.4.loop_body.dim.0

fusion.4.loop_body.dim.0:                         ; preds = %fusion.4.loop_header.dim.0
  %4 = add i64 %fusion.4.indvar.dim.0, 5000
  %5 = mul nuw nsw i64 %4, 1
  %6 = add nuw nsw i64 0, %5
  %7 = trunc i64 %6 to i32
  %8 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %9 = load i32, ptr %8, align 4, !invariant.load !0, !noalias !47
  %10 = add i32 %7, %9
  %11 = getelementptr inbounds [5000 x i32], ptr %fusion.4, i64 0, i64 %fusion.4.indvar.dim.0
  store i32 %10, ptr %11, align 4, !alias.scope !9, !noalias !48
  %invar.inc = add nuw nsw i64 %fusion.4.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.4.invar_address.dim.0, align 8
  br label %fusion.4.loop_header.dim.0

fusion.4.loop_exit.dim.0:                         ; preds = %fusion.4.loop_header.dim.0
  %12 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %13 = load ptr, ptr %12, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.6 = getelementptr inbounds i8, ptr %13, i64 64
  store i64 0, ptr %fusion.6.invar_address.dim.0, align 8
  br label %fusion.6.loop_header.dim.0

fusion.6.loop_header.dim.0:                       ; preds = %fusion.6.loop_body.dim.0, %fusion.4.loop_exit.dim.0
  %fusion.6.indvar.dim.0 = load i64, ptr %fusion.6.invar_address.dim.0, align 8
  %14 = icmp uge i64 %fusion.6.indvar.dim.0, 5000
  br i1 %14, label %fusion.6.loop_exit.dim.0, label %fusion.6.loop_body.dim.0

fusion.6.loop_body.dim.0:                         ; preds = %fusion.6.loop_header.dim.0
  %15 = add i64 %fusion.6.indvar.dim.0, 0
  %16 = mul nuw nsw i64 %15, 1
  %17 = add nuw nsw i64 0, %16
  %18 = trunc i64 %17 to i32
  %19 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %20 = load i32, ptr %19, align 4, !invariant.load !0, !noalias !47
  %21 = add i32 %18, %20
  %22 = getelementptr inbounds [5000 x i32], ptr %fusion.6, i64 0, i64 %fusion.6.indvar.dim.0
  store i32 %21, ptr %22, align 4, !alias.scope !4, !noalias !49
  %invar.inc1 = add nuw nsw i64 %fusion.6.indvar.dim.0, 1
  store i64 %invar.inc1, ptr %fusion.6.invar_address.dim.0, align 8
  br label %fusion.6.loop_header.dim.0

fusion.6.loop_exit.dim.0:                         ; preds = %fusion.6.loop_header.dim.0
  %23 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %24 = load ptr, ptr %23, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.25 = getelementptr inbounds i8, ptr %24, i64 60080
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.25, ptr align 1 @constant.16, i64 16, i1 false)
  %25 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %copy.26 = load ptr, ptr %25, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.26, ptr align 1 @constant.17, i64 16, i1 false)
  %26 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %27 = load ptr, ptr %26, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.24 = getelementptr inbounds i8, ptr %27, i64 60128
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.24, ptr align 1 @constant.14, i64 4, i1 false)
  %28 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %29 = load ptr, ptr %28, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.3 = getelementptr inbounds i8, ptr %29, i64 60112
  %30 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %31 = load i32, ptr %30, align 4, !invariant.load !0, !noalias !47
  %32 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %33 = load i32, ptr %32, align 4, !invariant.load !0, !noalias !47
  %34 = xor i32 %31, %33
  %constant.101 = load i32, ptr @32, align 4
  %35 = xor i32 %34, %constant.101
  store i32 %35, ptr %fusion.3, align 4, !alias.scope !17, !noalias !50
  %36 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %37 = load ptr, ptr %36, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.5 = getelementptr inbounds i8, ptr %37, i64 60144
  %38 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %39 = load i32, ptr %38, align 4, !invariant.load !0, !noalias !47
  store i32 %39, ptr %fusion.5, align 4, !alias.scope !51, !noalias !52
  %40 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %41 = load ptr, ptr %40, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.7 = getelementptr inbounds i8, ptr %41, i64 60160
  %42 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %43 = load i32, ptr %42, align 4, !invariant.load !0, !noalias !47
  store i32 %43, ptr %fusion.7, align 4, !alias.scope !53, !noalias !54
  %44 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %tuple.9 = load ptr, ptr %44, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %45 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 0
  store ptr %copy.24, ptr %45, align 8, !alias.scope !37, !noalias !38
  %46 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 1
  store ptr %fusion.6, ptr %46, align 8, !alias.scope !37, !noalias !38
  %47 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 2
  store ptr %fusion.4, ptr %47, align 8, !alias.scope !37, !noalias !38
  %48 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 3
  store ptr %fusion.5, ptr %48, align 8, !alias.scope !37, !noalias !38
  %49 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 4
  store ptr %fusion.3, ptr %49, align 8, !alias.scope !37, !noalias !38
  %50 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 5
  store ptr %fusion.7, ptr %50, align 8, !alias.scope !37, !noalias !38
  %51 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 6
  store ptr %copy.26, ptr %51, align 8, !alias.scope !37, !noalias !38
  %52 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 7
  store ptr %copy.25, ptr %52, align 8, !alias.scope !37, !noalias !38
  br label %while.1.header

while.1.header:                                   ; preds = %while.1.body, %fusion.6.loop_exit.dim.0
  call void @region_1.96.clone.clone(ptr null, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters)
  %53 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %54 = load ptr, ptr %53, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %55 = getelementptr inbounds i8, ptr %54, i64 60096
  %56 = load i8, ptr %55, align 1
  %57 = icmp ne i8 %56, 0
  br i1 %57, label %while.1.body, label %while.1.exit

while.1.body:                                     ; preds = %while.1.header
  call void @region_0.32.clone.clone.clone(ptr null, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters)
  br label %while.1.header

while.1.exit:                                     ; preds = %while.1.header
  %58 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 1
  %59 = load ptr, ptr %58, align 8, !dereferenceable !23, !align !2
  %60 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 2
  %61 = load ptr, ptr %60, align 8, !dereferenceable !23, !align !2
  %62 = getelementptr inbounds ptr, ptr %buffer_table, i64 0
  %call.2 = load ptr, ptr %62, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  call void @__xla_cpu_runtime_ParallelForkJoin(ptr %call.2, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters, i32 8, ptr @parallel_fusion.2_parallel_dimension_partitions, i32 1, ptr @parallel_fusion.2)
  br label %return
}

attributes #0 = { uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #1 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nocallback nofree nounwind willreturn }
attributes #3 = { nounwind }

!0 = !{}
!1 = !{i64 60180}
!2 = !{i64 16}
!3 = !{i64 40000}
!4 = !{!5}
!5 = !{!"buffer: {index:7, offset:64, size:20000}", !6}
!6 = !{!"XLA global AA domain"}
!7 = !{!8}
!8 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!9 = !{!10}
!10 = !{!"buffer: {index:7, offset:20064, size:20000}", !6}
!11 = !{!12}
!12 = !{!"buffer: {index:7, offset:40064, size:20000}", !6}
!13 = !{!14}
!14 = !{!"buffer: {index:0, offset:0, size:20000}", !6}
!15 = !{!16}
!16 = !{!"buffer: {index:7, offset:60064, size:16}", !6}
!17 = !{!18}
!18 = !{!"buffer: {index:7, offset:60112, size:4}", !6}
!19 = !{!20}
!20 = !{!"buffer: {index:7, offset:60096, size:4}", !6}
!21 = !{!22}
!22 = !{!"buffer: {index:7, offset:60176, size:4}", !6}
!23 = !{i64 20000}
!24 = !{i64 4}
!25 = !{!14, !26, !10, !12, !16, !20, !27}
!26 = !{!"buffer: {index:1, offset:0, size:4}", !6}
!27 = !{!"buffer: {index:7, offset:60128, size:4}", !6}
!28 = !{!26}
!29 = !{!27, !22}
!30 = !{!27}
!31 = !{!32, !26, !33, !5, !10, !34, !18, !35, !36, !22}
!32 = !{!"buffer: {index:0, offset:0, size:16}", !6}
!33 = !{!"buffer: {index:7, offset:0, size:64}", !6}
!34 = !{!"buffer: {index:7, offset:60080, size:16}", !6}
!35 = !{!"buffer: {index:7, offset:60144, size:4}", !6}
!36 = !{!"buffer: {index:7, offset:60160, size:4}", !6}
!37 = !{!33}
!38 = !{!32, !5, !10, !34, !18, !27, !35, !36}
!39 = !{!40, !41}
!40 = !{!"buffer: {index:6, offset:0, size:4}", !6}
!41 = !{!"buffer: {index:7, offset:60096, size:1}", !6}
!42 = !{!40}
!43 = !{!41, !27}
!44 = !{!41}
!45 = !{!40, !27}
!46 = !{i64 8}
!47 = !{!5, !10, !18, !35, !36}
!48 = !{!32, !33, !5, !34, !18, !27, !35, !36}
!49 = !{!32, !33, !10, !34, !18, !27, !35, !36}
!50 = !{!32, !33, !5, !10, !34, !27, !35, !36}
!51 = !{!35}
!52 = !{!32, !33, !5, !10, !34, !18, !27, !36}
!53 = !{!36}
!54 = !{!32, !33, !5, !10, !34, !18, !27, !35}
