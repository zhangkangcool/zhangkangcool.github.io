; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@constant.10 = private unnamed_addr constant [4 x i8] c"\01\00\00\00", align 4
@constant.5 = private unnamed_addr constant [16 x i8] c"\0D\00\00\00\0F\00\00\00\1A\00\00\00\06\00\00\00", align 16
@constant.4 = private unnamed_addr constant [16 x i8] c"\11\00\00\00\1D\00\00\00\10\00\00\00\18\00\00\00", align 16
@constant.2 = private unnamed_addr constant [4 x i8] zeroinitializer, align 4
@constant.11 = private unnamed_addr constant [4 x i8] c"\05\00\00\00", align 4
@0 = private unnamed_addr constant [4 x i8] c"\01\00\00\00"
@1 = private unnamed_addr constant [4 x i8] c" \00\00\00"
@2 = private unnamed_addr constant [4 x i8] c" \00\00\00"
@3 = private unnamed_addr constant [4 x i8] c"\DA\1B\D1\1B"

; Function Attrs: uwtable
define internal void @region_0.20.clone.clone.clone(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %fusion.7.invar_address.dim.0 = alloca i64, align 8
  %fusion.6.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %arg_tuple.3 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 6
  %2 = load ptr, ptr %1, align 8, !dereferenceable !2, !align !2
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %4 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.14 = getelementptr inbounds i8, ptr %4, i64 64
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.14, ptr align 1 %2, i64 16, i1 false)
  %5 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 2
  %6 = load ptr, ptr %5, align 8, !dereferenceable !3, !align !3
  %7 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %copy.10 = load ptr, ptr %7, align 8, !invariant.load !0, !dereferenceable !2, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.10, ptr align 1 %6, i64 8, i1 false)
  %8 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 1
  %9 = load ptr, ptr %8, align 8, !dereferenceable !3, !align !3
  %10 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %11 = load ptr, ptr %10, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.9 = getelementptr inbounds i8, ptr %11, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.9, ptr align 1 %9, i64 8, i1 false)
  %12 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 4
  %13 = load ptr, ptr %12, align 8, !dereferenceable !4, !align !4
  %14 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %15 = load ptr, ptr %14, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.12 = getelementptr inbounds i8, ptr %15, i64 144
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.12, ptr align 1 %13, i64 4, i1 false)
  %16 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 0
  %17 = load ptr, ptr %16, align 8, !dereferenceable !4, !align !4
  %18 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %19 = load ptr, ptr %18, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.8 = getelementptr inbounds i8, ptr %19, i64 224
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.8, ptr align 1 %17, i64 4, i1 false)
  %20 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %21 = load ptr, ptr %20, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.6 = getelementptr inbounds i8, ptr %21, i64 128
  store i64 0, ptr %fusion.6.invar_address.dim.0, align 8
  br label %fusion.6.loop_header.dim.0

return:                                           ; preds = %fusion.7.loop_exit.dim.0
  ret void

fusion.6.loop_header.dim.0:                       ; preds = %fusion.6.loop_body.dim.0, %entry
  %fusion.6.indvar.dim.0 = load i64, ptr %fusion.6.invar_address.dim.0, align 8
  %22 = icmp uge i64 %fusion.6.indvar.dim.0, 2
  br i1 %22, label %fusion.6.loop_exit.dim.0, label %fusion.6.loop_body.dim.0

fusion.6.loop_body.dim.0:                         ; preds = %fusion.6.loop_header.dim.0
  %23 = getelementptr inbounds [2 x i32], ptr %copy.9, i64 0, i64 %fusion.6.indvar.dim.0
  %24 = load i32, ptr %23, align 4, !alias.scope !5, !noalias !8
  %25 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.6.indvar.dim.0
  %26 = load i32, ptr %25, align 4, !alias.scope !16, !noalias !17
  %27 = add i32 %24, %26
  %28 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.6.indvar.dim.0
  %29 = load i32, ptr %28, align 4, !alias.scope !16, !noalias !17
  %30 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 0
  %31 = load i32, ptr %30, align 4, !alias.scope !18, !noalias !19
  %32 = shl i32 %29, %31
  %shft.chk = icmp ult i32 %31, 32
  %33 = select i1 %shft.chk, i32 %32, i32 0
  %34 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.6.indvar.dim.0
  %35 = load i32, ptr %34, align 4, !alias.scope !16, !noalias !17
  %constant.13 = load i32, ptr @1, align 4
  %36 = sub i32 %constant.13, %31
  %37 = lshr i32 %35, %36
  %shft.chk1 = icmp ult i32 %36, 32
  %38 = select i1 %shft.chk1, i32 %37, i32 0
  %39 = or i32 %33, %38
  %40 = xor i32 %27, %39
  %41 = add i32 %27, %40
  %42 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 1
  %43 = load i32, ptr %42, align 4, !alias.scope !18, !noalias !19
  %44 = shl i32 %40, %43
  %shft.chk2 = icmp ult i32 %43, 32
  %45 = select i1 %shft.chk2, i32 %44, i32 0
  %constant.133 = load i32, ptr @1, align 4
  %46 = sub i32 %constant.133, %43
  %47 = lshr i32 %40, %46
  %shft.chk4 = icmp ult i32 %46, 32
  %48 = select i1 %shft.chk4, i32 %47, i32 0
  %49 = or i32 %45, %48
  %50 = xor i32 %41, %49
  %51 = add i32 %41, %50
  %52 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 2
  %53 = load i32, ptr %52, align 4, !alias.scope !18, !noalias !19
  %54 = shl i32 %50, %53
  %shft.chk5 = icmp ult i32 %53, 32
  %55 = select i1 %shft.chk5, i32 %54, i32 0
  %constant.136 = load i32, ptr @1, align 4
  %56 = sub i32 %constant.136, %53
  %57 = lshr i32 %50, %56
  %shft.chk7 = icmp ult i32 %56, 32
  %58 = select i1 %shft.chk7, i32 %57, i32 0
  %59 = or i32 %55, %58
  %60 = xor i32 %51, %59
  %61 = add i32 %51, %60
  %62 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 3
  %63 = load i32, ptr %62, align 4, !alias.scope !18, !noalias !19
  %64 = shl i32 %60, %63
  %shft.chk8 = icmp ult i32 %63, 32
  %65 = select i1 %shft.chk8, i32 %64, i32 0
  %constant.139 = load i32, ptr @1, align 4
  %66 = sub i32 %constant.139, %63
  %67 = lshr i32 %60, %66
  %shft.chk10 = icmp ult i32 %66, 32
  %68 = select i1 %shft.chk10, i32 %67, i32 0
  %69 = or i32 %65, %68
  %70 = xor i32 %61, %69
  %71 = load i32, ptr %copy.12, align 4, !alias.scope !22, !noalias !23
  %72 = add i32 %70, %71
  %73 = load i32, ptr %copy.8, align 4, !alias.scope !25, !noalias !26
  %constant.14 = load i32, ptr @0, align 4
  %74 = add i32 %73, %constant.14
  %75 = add i32 %72, %74
  %76 = getelementptr inbounds [2 x i32], ptr %fusion.6, i64 0, i64 %fusion.6.indvar.dim.0
  store i32 %75, ptr %76, align 4, !alias.scope !29, !noalias !30
  %invar.inc = add nuw nsw i64 %fusion.6.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.6.invar_address.dim.0, align 8
  br label %fusion.6.loop_header.dim.0

fusion.6.loop_exit.dim.0:                         ; preds = %fusion.6.loop_header.dim.0
  %77 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 3
  %78 = load ptr, ptr %77, align 8, !dereferenceable !4, !align !4
  %79 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %80 = load ptr, ptr %79, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.11 = getelementptr inbounds i8, ptr %80, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.11, ptr align 1 %78, i64 4, i1 false)
  %81 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %82 = load ptr, ptr %81, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.7 = getelementptr inbounds i8, ptr %82, i64 112
  store i64 0, ptr %fusion.7.invar_address.dim.0, align 8
  br label %fusion.7.loop_header.dim.0

fusion.7.loop_header.dim.0:                       ; preds = %fusion.7.loop_body.dim.0, %fusion.6.loop_exit.dim.0
  %fusion.7.indvar.dim.0 = load i64, ptr %fusion.7.invar_address.dim.0, align 8
  %83 = icmp uge i64 %fusion.7.indvar.dim.0, 2
  br i1 %83, label %fusion.7.loop_exit.dim.0, label %fusion.7.loop_body.dim.0

fusion.7.loop_body.dim.0:                         ; preds = %fusion.7.loop_header.dim.0
  %84 = getelementptr inbounds [2 x i32], ptr %copy.9, i64 0, i64 %fusion.7.indvar.dim.0
  %85 = load i32, ptr %84, align 4, !alias.scope !5, !noalias !8
  %86 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.7.indvar.dim.0
  %87 = load i32, ptr %86, align 4, !alias.scope !16, !noalias !17
  %88 = add i32 %85, %87
  %89 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.7.indvar.dim.0
  %90 = load i32, ptr %89, align 4, !alias.scope !16, !noalias !17
  %91 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 0
  %92 = load i32, ptr %91, align 4, !alias.scope !18, !noalias !19
  %93 = shl i32 %90, %92
  %shft.chk12 = icmp ult i32 %92, 32
  %94 = select i1 %shft.chk12, i32 %93, i32 0
  %95 = getelementptr inbounds [2 x i32], ptr %copy.10, i64 0, i64 %fusion.7.indvar.dim.0
  %96 = load i32, ptr %95, align 4, !alias.scope !16, !noalias !17
  %constant.15 = load i32, ptr @2, align 4
  %97 = sub i32 %constant.15, %92
  %98 = lshr i32 %96, %97
  %shft.chk13 = icmp ult i32 %97, 32
  %99 = select i1 %shft.chk13, i32 %98, i32 0
  %100 = or i32 %94, %99
  %101 = xor i32 %88, %100
  %102 = add i32 %88, %101
  %103 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 1
  %104 = load i32, ptr %103, align 4, !alias.scope !18, !noalias !19
  %105 = shl i32 %101, %104
  %shft.chk14 = icmp ult i32 %104, 32
  %106 = select i1 %shft.chk14, i32 %105, i32 0
  %constant.1515 = load i32, ptr @2, align 4
  %107 = sub i32 %constant.1515, %104
  %108 = lshr i32 %101, %107
  %shft.chk16 = icmp ult i32 %107, 32
  %109 = select i1 %shft.chk16, i32 %108, i32 0
  %110 = or i32 %106, %109
  %111 = xor i32 %102, %110
  %112 = add i32 %102, %111
  %113 = getelementptr inbounds [4 x i32], ptr %copy.14, i64 0, i64 2
  %114 = load i32, ptr %113, align 4, !alias.scope !18, !noalias !19
  %115 = shl i32 %111, %114
  %shft.chk17 = icmp ult i32 %114, 32
  %116 = select i1 %shft.chk17, i32 %115, i32 0
  %constant.1518 = load i32, ptr @2, align 4
  %117 = sub i32 %constant.1518, %114
  %118 = lshr i32 %111, %117
  %shft.chk19 = icmp ult i32 %117, 32
  %119 = select i1 %shft.chk19, i32 %118, i32 0
  %120 = or i32 %116, %119
  %121 = xor i32 %112, %120
  %122 = add i32 %112, %121
  %123 = load i32, ptr %copy.11, align 4, !alias.scope !33, !noalias !34
  %124 = add i32 %122, %123
  %125 = getelementptr inbounds [2 x i32], ptr %fusion.7, i64 0, i64 %fusion.7.indvar.dim.0
  store i32 %124, ptr %125, align 4, !alias.scope !35, !noalias !36
  %invar.inc11 = add nuw nsw i64 %fusion.7.indvar.dim.0, 1
  store i64 %invar.inc11, ptr %fusion.7.invar_address.dim.0, align 8
  br label %fusion.7.loop_header.dim.0

fusion.7.loop_exit.dim.0:                         ; preds = %fusion.7.loop_header.dim.0
  %126 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 7
  %127 = load ptr, ptr %126, align 8, !dereferenceable !2, !align !2
  %128 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %129 = load ptr, ptr %128, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.15 = getelementptr inbounds i8, ptr %129, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.15, ptr align 1 %127, i64 16, i1 false)
  %130 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %131 = load ptr, ptr %130, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.23 = getelementptr inbounds i8, ptr %131, i64 80
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.23, ptr align 1 %copy.14, i64 16, i1 false)
  %132 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %133 = load ptr, ptr %132, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %add.35 = getelementptr inbounds i8, ptr %133, i64 176
  %134 = load i32, ptr %copy.8, align 4, !alias.scope !25, !noalias !26
  %135 = load i32, ptr @constant.10, align 4, !alias.scope !37, !noalias !38
  %136 = add i32 %134, %135
  store i32 %136, ptr %add.35, align 4, !alias.scope !39, !noalias !40
  %137 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %138 = load ptr, ptr %137, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.19 = getelementptr inbounds i8, ptr %138, i64 192
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.19, ptr align 1 %copy.12, i64 4, i1 false)
  %139 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.3, i64 0, i64 5
  %140 = load ptr, ptr %139, align 8, !dereferenceable !4, !align !4
  %141 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %142 = load ptr, ptr %141, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.13 = getelementptr inbounds i8, ptr %142, i64 64
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.13, ptr align 1 %140, i64 4, i1 false)
  %143 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %144 = load ptr, ptr %143, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.21 = getelementptr inbounds i8, ptr %144, i64 208
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.21, ptr align 1 %copy.11, i64 4, i1 false)
  %145 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %copy.22 = load ptr, ptr %145, align 8, !invariant.load !0, !dereferenceable !2, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.22, ptr align 1 %copy.15, i64 16, i1 false)
  %146 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %147 = load ptr, ptr %146, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.20 = getelementptr inbounds i8, ptr %147, i64 160
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.20, ptr align 1 %copy.13, i64 4, i1 false)
  %148 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %tuple.11 = load ptr, ptr %148, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %149 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 0
  store ptr %add.35, ptr %149, align 8, !alias.scope !41, !noalias !42
  %150 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 1
  store ptr %fusion.7, ptr %150, align 8, !alias.scope !41, !noalias !42
  %151 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 2
  store ptr %fusion.6, ptr %151, align 8, !alias.scope !41, !noalias !42
  %152 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 3
  store ptr %copy.19, ptr %152, align 8, !alias.scope !41, !noalias !42
  %153 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 4
  store ptr %copy.20, ptr %153, align 8, !alias.scope !41, !noalias !42
  %154 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 5
  store ptr %copy.21, ptr %154, align 8, !alias.scope !41, !noalias !42
  %155 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 6
  store ptr %copy.22, ptr %155, align 8, !alias.scope !41, !noalias !42
  %156 = getelementptr inbounds [8 x ptr], ptr %tuple.11, i64 0, i64 7
  store ptr %copy.23, ptr %156, align 8, !alias.scope !41, !noalias !42
  br label %return
}

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #1

; Function Attrs: uwtable
define internal void @region_1.84.clone.clone(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %arg_tuple.4 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %1 = getelementptr inbounds [8 x ptr], ptr %arg_tuple.4, i64 0, i64 0
  %2 = load ptr, ptr %1, align 8, !dereferenceable !4, !align !4
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %4 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %compare.1 = getelementptr inbounds i8, ptr %4, i64 64
  %5 = load i32, ptr %2, align 4, !alias.scope !39, !noalias !43
  %6 = load i32, ptr @constant.11, align 4, !alias.scope !46, !noalias !47
  %7 = icmp slt i32 %5, %6
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %compare.1, align 1, !alias.scope !48, !noalias !49
  br label %return

return:                                           ; preds = %entry
  ret void
}

; Function Attrs: uwtable
define void @main.109(ptr %retval, ptr noalias %run_options, ptr noalias %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) #0 {
entry:
  %fusion.invar_address.dim.1 = alloca i64, align 8
  %fusion.invar_address.dim.0 = alloca i64, align 8
  %fusion.4.invar_address.dim.0 = alloca i64, align 8
  %fusion.2.invar_address.dim.0 = alloca i64, align 8
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.25 = getelementptr inbounds i8, ptr %1, i64 80
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.25, ptr align 1 @constant.4, i64 16, i1 false)
  %2 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %copy.26 = load ptr, ptr %2, align 8, !invariant.load !0, !dereferenceable !2, !align !2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.26, ptr align 1 @constant.5, i64 16, i1 false)
  %3 = getelementptr inbounds ptr, ptr %buffer_table, i64 4
  %Arg_0.1 = load ptr, ptr %3, align 8, !invariant.load !0, !dereferenceable !3, !align !3
  %4 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %5 = load ptr, ptr %4, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.2 = getelementptr inbounds i8, ptr %5, i64 128
  store i64 0, ptr %fusion.2.invar_address.dim.0, align 8
  br label %fusion.2.loop_header.dim.0

return:                                           ; preds = %fusion.loop_exit.dim.0
  ret void

fusion.2.loop_header.dim.0:                       ; preds = %fusion.2.loop_body.dim.0, %entry
  %fusion.2.indvar.dim.0 = load i64, ptr %fusion.2.invar_address.dim.0, align 8
  %6 = icmp uge i64 %fusion.2.indvar.dim.0, 2
  br i1 %6, label %fusion.2.loop_exit.dim.0, label %fusion.2.loop_body.dim.0

fusion.2.loop_body.dim.0:                         ; preds = %fusion.2.loop_header.dim.0
  %7 = add i64 %fusion.2.indvar.dim.0, 2
  %8 = mul nuw nsw i64 %7, 1
  %9 = add nuw nsw i64 0, %8
  %10 = trunc i64 %9 to i32
  %11 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %12 = load i32, ptr %11, align 4, !invariant.load !0, !noalias !50
  %13 = add i32 %10, %12
  %14 = getelementptr inbounds [2 x i32], ptr %fusion.2, i64 0, i64 %fusion.2.indvar.dim.0
  store i32 %13, ptr %14, align 4, !alias.scope !29, !noalias !51
  %invar.inc = add nuw nsw i64 %fusion.2.indvar.dim.0, 1
  store i64 %invar.inc, ptr %fusion.2.invar_address.dim.0, align 8
  br label %fusion.2.loop_header.dim.0

fusion.2.loop_exit.dim.0:                         ; preds = %fusion.2.loop_header.dim.0
  %15 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %16 = load ptr, ptr %15, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.4 = getelementptr inbounds i8, ptr %16, i64 112
  store i64 0, ptr %fusion.4.invar_address.dim.0, align 8
  br label %fusion.4.loop_header.dim.0

fusion.4.loop_header.dim.0:                       ; preds = %fusion.4.loop_body.dim.0, %fusion.2.loop_exit.dim.0
  %fusion.4.indvar.dim.0 = load i64, ptr %fusion.4.invar_address.dim.0, align 8
  %17 = icmp uge i64 %fusion.4.indvar.dim.0, 2
  br i1 %17, label %fusion.4.loop_exit.dim.0, label %fusion.4.loop_body.dim.0

fusion.4.loop_body.dim.0:                         ; preds = %fusion.4.loop_header.dim.0
  %18 = add i64 %fusion.4.indvar.dim.0, 0
  %19 = mul nuw nsw i64 %18, 1
  %20 = add nuw nsw i64 0, %19
  %21 = trunc i64 %20 to i32
  %22 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %23 = load i32, ptr %22, align 4, !invariant.load !0, !noalias !50
  %24 = add i32 %21, %23
  %25 = getelementptr inbounds [2 x i32], ptr %fusion.4, i64 0, i64 %fusion.4.indvar.dim.0
  store i32 %24, ptr %25, align 4, !alias.scope !35, !noalias !52
  %invar.inc1 = add nuw nsw i64 %fusion.4.indvar.dim.0, 1
  store i64 %invar.inc1, ptr %fusion.4.invar_address.dim.0, align 8
  br label %fusion.4.loop_header.dim.0

fusion.4.loop_exit.dim.0:                         ; preds = %fusion.4.loop_header.dim.0
  %26 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %27 = load ptr, ptr %26, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %copy.24 = getelementptr inbounds i8, ptr %27, i64 176
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %copy.24, ptr align 1 @constant.2, i64 4, i1 false)
  %28 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %29 = load ptr, ptr %28, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.1 = getelementptr inbounds i8, ptr %29, i64 160
  %30 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %31 = load i32, ptr %30, align 4, !invariant.load !0, !noalias !50
  %32 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %33 = load i32, ptr %32, align 4, !invariant.load !0, !noalias !50
  %34 = xor i32 %31, %33
  %constant.12 = load i32, ptr @3, align 4
  %35 = xor i32 %34, %constant.12
  store i32 %35, ptr %fusion.1, align 4, !alias.scope !33, !noalias !53
  %36 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %37 = load ptr, ptr %36, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.3 = getelementptr inbounds i8, ptr %37, i64 192
  %38 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %39 = load i32, ptr %38, align 4, !invariant.load !0, !noalias !50
  store i32 %39, ptr %fusion.3, align 4, !alias.scope !54, !noalias !55
  %40 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %41 = load ptr, ptr %40, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.5 = getelementptr inbounds i8, ptr %41, i64 208
  %42 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 0
  %43 = load i32, ptr %42, align 4, !invariant.load !0, !noalias !50
  store i32 %43, ptr %fusion.5, align 4, !alias.scope !56, !noalias !57
  %44 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %tuple.9 = load ptr, ptr %44, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %45 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 0
  store ptr %copy.24, ptr %45, align 8, !alias.scope !41, !noalias !42
  %46 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 1
  store ptr %fusion.4, ptr %46, align 8, !alias.scope !41, !noalias !42
  %47 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 2
  store ptr %fusion.2, ptr %47, align 8, !alias.scope !41, !noalias !42
  %48 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 3
  store ptr %fusion.3, ptr %48, align 8, !alias.scope !41, !noalias !42
  %49 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 4
  store ptr %fusion.1, ptr %49, align 8, !alias.scope !41, !noalias !42
  %50 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 5
  store ptr %fusion.5, ptr %50, align 8, !alias.scope !41, !noalias !42
  %51 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 6
  store ptr %copy.26, ptr %51, align 8, !alias.scope !41, !noalias !42
  %52 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 7
  store ptr %copy.25, ptr %52, align 8, !alias.scope !41, !noalias !42
  br label %while.1.header

while.1.header:                                   ; preds = %while.1.body, %fusion.4.loop_exit.dim.0
  call void @region_1.84.clone.clone(ptr null, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters)
  %53 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %54 = load ptr, ptr %53, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %55 = getelementptr inbounds i8, ptr %54, i64 64
  %56 = load i8, ptr %55, align 1
  %57 = icmp ne i8 %56, 0
  br i1 %57, label %while.1.body, label %while.1.exit

while.1.body:                                     ; preds = %while.1.header
  call void @region_0.20.clone.clone.clone(ptr null, ptr %run_options, ptr null, ptr %buffer_table, ptr %status, ptr %prof_counters)
  br label %while.1.header

while.1.exit:                                     ; preds = %while.1.header
  %58 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 1
  %59 = load ptr, ptr %58, align 8, !dereferenceable !3, !align !3
  %60 = getelementptr inbounds [8 x ptr], ptr %tuple.9, i64 0, i64 2
  %61 = load ptr, ptr %60, align 8, !dereferenceable !3, !align !3
  %62 = getelementptr inbounds ptr, ptr %buffer_table, i64 1
  %fusion = load ptr, ptr %62, align 8, !invariant.load !0, !dereferenceable !2, !align !2
  store i64 0, ptr %fusion.invar_address.dim.0, align 8
  br label %fusion.loop_header.dim.0

fusion.loop_header.dim.0:                         ; preds = %fusion.loop_exit.dim.1, %while.1.exit
  %fusion.indvar.dim.0 = load i64, ptr %fusion.invar_address.dim.0, align 8
  %63 = icmp uge i64 %fusion.indvar.dim.0, 2
  br i1 %63, label %fusion.loop_exit.dim.0, label %fusion.loop_body.dim.0

fusion.loop_body.dim.0:                           ; preds = %fusion.loop_header.dim.0
  store i64 0, ptr %fusion.invar_address.dim.1, align 8
  br label %fusion.loop_header.dim.1

fusion.loop_header.dim.1:                         ; preds = %concatenate.0.merge, %fusion.loop_body.dim.0
  %fusion.indvar.dim.1 = load i64, ptr %fusion.invar_address.dim.1, align 8
  %64 = icmp uge i64 %fusion.indvar.dim.1, 2
  br i1 %64, label %fusion.loop_exit.dim.1, label %fusion.loop_body.dim.1

fusion.loop_body.dim.1:                           ; preds = %fusion.loop_header.dim.1
  %65 = mul nuw nsw i64 %fusion.indvar.dim.1, 1
  %66 = add nuw nsw i64 0, %65
  %67 = mul nuw nsw i64 %fusion.indvar.dim.0, 2
  %68 = add nuw nsw i64 %66, %67
  %69 = udiv i64 %68, 4
  br label %concatenate.pivot.2.

concat_index_from_operand_id0:                    ; preds = %concatenate.pivot.0.
  %70 = phi i64 [ 0, %concatenate.pivot.0. ]
  %71 = sub nsw i64 %68, %70
  %72 = getelementptr inbounds [2 x i32], ptr %59, i64 0, i64 %71
  %73 = load i32, ptr %72, align 4, !alias.scope !35, !noalias !52
  br label %concatenate.0.merge

concat_index_from_operand_id1:                    ; preds = %concatenate.pivot.2.4
  %74 = phi i64 [ 2, %concatenate.pivot.2.4 ]
  %75 = sub nsw i64 %68, %74
  %76 = getelementptr inbounds [2 x i32], ptr %61, i64 0, i64 %75
  %77 = load i32, ptr %76, align 4, !alias.scope !29, !noalias !51
  br label %concatenate.0.merge

concatenate.pivot.2.:                             ; preds = %fusion.loop_body.dim.1
  %78 = icmp ult i64 %68, 2
  br i1 %78, label %concatenate.pivot.0., label %concatenate.pivot.2.4

concatenate.pivot.0.:                             ; preds = %concatenate.pivot.2.
  br label %concat_index_from_operand_id0

concatenate.pivot.2.4:                            ; preds = %concatenate.pivot.2.
  br label %concat_index_from_operand_id1

concatenate.0.merge:                              ; preds = %concat_index_from_operand_id1, %concat_index_from_operand_id0
  %79 = phi i32 [ %73, %concat_index_from_operand_id0 ], [ %77, %concat_index_from_operand_id1 ]
  %80 = getelementptr inbounds [2 x [2 x i32]], ptr %fusion, i64 0, i64 %fusion.indvar.dim.0, i64 %fusion.indvar.dim.1
  store i32 %79, ptr %80, align 4, !alias.scope !58, !noalias !59
  %invar.inc3 = add nuw nsw i64 %fusion.indvar.dim.1, 1
  store i64 %invar.inc3, ptr %fusion.invar_address.dim.1, align 8
  br label %fusion.loop_header.dim.1

fusion.loop_exit.dim.1:                           ; preds = %fusion.loop_header.dim.1
  %invar.inc2 = add nuw nsw i64 %fusion.indvar.dim.0, 1
  store i64 %invar.inc2, ptr %fusion.invar_address.dim.0, align 8
  br label %fusion.loop_header.dim.0

fusion.loop_exit.dim.0:                           ; preds = %fusion.loop_header.dim.0
  br label %return
}

attributes #0 = { uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #1 = { argmemonly nocallback nofree nounwind willreturn }

!0 = !{}
!1 = !{i64 228}
!2 = !{i64 16}
!3 = !{i64 8}
!4 = !{i64 4}
!5 = !{!6}
!6 = !{!"buffer: {index:7, offset:96, size:8}", !7}
!7 = !{!"XLA global AA domain"}
!8 = !{!9, !10, !11, !12, !13, !14, !15}
!9 = !{!"buffer: {index:1, offset:0, size:8}", !7}
!10 = !{!"buffer: {index:7, offset:64, size:16}", !7}
!11 = !{!"buffer: {index:7, offset:112, size:8}", !7}
!12 = !{!"buffer: {index:7, offset:128, size:8}", !7}
!13 = !{!"buffer: {index:7, offset:144, size:4}", !7}
!14 = !{!"buffer: {index:7, offset:160, size:4}", !7}
!15 = !{!"buffer: {index:7, offset:224, size:4}", !7}
!16 = !{!9}
!17 = !{!10, !6, !11, !12, !13, !14, !15}
!18 = !{!10}
!19 = !{!9, !20, !21, !6, !11, !12, !13, !14, !15}
!20 = !{!"buffer: {index:1, offset:0, size:16}", !7}
!21 = !{!"buffer: {index:7, offset:80, size:16}", !7}
!22 = !{!13}
!23 = !{!9, !10, !6, !12, !14, !24, !15}
!24 = !{!"buffer: {index:7, offset:192, size:4}", !7}
!25 = !{!15}
!26 = !{!27, !9, !10, !6, !12, !13, !28}
!27 = !{!"buffer: {index:0, offset:0, size:4}", !7}
!28 = !{!"buffer: {index:7, offset:176, size:4}", !7}
!29 = !{!12}
!30 = !{!9, !20, !31, !10, !21, !6, !11, !13, !14, !28, !24, !32, !15}
!31 = !{!"buffer: {index:7, offset:0, size:64}", !7}
!32 = !{!"buffer: {index:7, offset:208, size:4}", !7}
!33 = !{!14}
!34 = !{!9, !10, !6, !11, !24, !32}
!35 = !{!11}
!36 = !{!9, !20, !31, !10, !21, !6, !12, !14, !28, !24, !32}
!37 = !{!27}
!38 = !{!28, !15}
!39 = !{!28}
!40 = !{!27, !20, !31, !21, !11, !12, !14, !24, !32, !15}
!41 = !{!31}
!42 = !{!20, !21, !11, !12, !14, !28, !24, !32}
!43 = !{!44, !45}
!44 = !{!"buffer: {index:6, offset:0, size:4}", !7}
!45 = !{!"buffer: {index:7, offset:64, size:1}", !7}
!46 = !{!44}
!47 = !{!45, !28}
!48 = !{!45}
!49 = !{!44, !28}
!50 = !{!11, !12, !14, !24, !32}
!51 = !{!20, !31, !21, !11, !14, !28, !24, !32}
!52 = !{!20, !31, !21, !12, !14, !28, !24, !32}
!53 = !{!20, !31, !21, !11, !12, !28, !24, !32}
!54 = !{!24}
!55 = !{!20, !31, !21, !11, !12, !14, !28, !32}
!56 = !{!32}
!57 = !{!20, !31, !21, !11, !12, !14, !28, !24}
!58 = !{!20}
!59 = !{!11, !12}
