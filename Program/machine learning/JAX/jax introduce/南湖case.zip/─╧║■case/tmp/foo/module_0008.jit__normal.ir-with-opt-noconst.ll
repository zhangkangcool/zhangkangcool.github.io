; ModuleID = '__compute_module'
source_filename = "__compute_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@constant.17 = external dso_local unnamed_addr constant [16 x i8], align 16
@constant.16 = external dso_local unnamed_addr constant [16 x i8], align 16
@parallel_fusion_parallel_dimension_partitions = external dso_local constant [14 x i64]
@parallel_fusion.1_parallel_dimension_partitions = external dso_local constant [12 x i64]
@parallel_fusion.2_parallel_dimension_partitions = external dso_local constant [16 x i64]

; Function Attrs: nofree nosync nounwind uwtable
define internal void @parallel_fusion.2(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readonly %dynamic_loop_bounds, ptr noalias nocapture readnone %prof_counters) #0 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.10 = getelementptr inbounds i8, ptr %1, i64 20064
  %p.9 = getelementptr inbounds i8, ptr %1, i64 64
  %fusion.2.clone = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %2 = load <2 x i64>, ptr %dynamic_loop_bounds, align 8
  %3 = extractelement <2 x i64> %2, i64 0
  %4 = extractelement <2 x i64> %2, i64 1
  %.not2 = icmp ugt i64 %4, %3
  br i1 %.not2, label %concatenate.pivot.5000..preheader, label %fusion.2.clone.loop_exit.dim.0

concatenate.pivot.5000..preheader:                ; preds = %entry
  %5 = sub i64 %4, %3
  %min.iters.check = icmp ult i64 %5, 8
  br i1 %min.iters.check, label %concatenate.pivot.5000..preheader4, label %vector.ph

vector.ph:                                        ; preds = %concatenate.pivot.5000..preheader
  %n.vec = and i64 %5, -8
  %ind.end = add i64 %3, %n.vec
  %.splat = shufflevector <2 x i64> %2, <2 x i64> poison, <8 x i32> zeroinitializer
  %induction = add <8 x i64> %.splat, <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ %induction, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %offset.idx = add i64 %3, %index
  %6 = icmp ult <8 x i64> %vec.ind, <i64 5000, i64 5000, i64 5000, i64 5000, i64 5000, i64 5000, i64 5000, i64 5000>
  %7 = getelementptr inbounds [5000 x i32], ptr %p.9, i64 0, <8 x i64> %vec.ind
  %8 = add nsw <8 x i64> %vec.ind, <i64 -5000, i64 -5000, i64 -5000, i64 -5000, i64 -5000, i64 -5000, i64 -5000, i64 -5000>
  %9 = getelementptr inbounds [5000 x i32], ptr %p.10, i64 0, <8 x i64> %8
  %10 = select <8 x i1> %6, <8 x ptr> %7, <8 x ptr> %9
  %wide.masked.gather = call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> %10, i32 4, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true>, <8 x i32> poison), !alias.scope !4, !noalias !8
  %11 = lshr <8 x i32> %wide.masked.gather, <i32 9, i32 9, i32 9, i32 9, i32 9, i32 9, i32 9, i32 9>
  %12 = or <8 x i32> %11, <i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216>
  %13 = bitcast <8 x i32> %12 to <8 x float>
  %14 = fadd <8 x float> %13, <float -1.000000e+00, float -1.000000e+00, float -1.000000e+00, float -1.000000e+00, float -1.000000e+00, float -1.000000e+00, float -1.000000e+00, float -1.000000e+00>
  %15 = fmul <8 x float> %14, <float 2.000000e+00, float 2.000000e+00, float 2.000000e+00, float 2.000000e+00, float 2.000000e+00, float 2.000000e+00, float 2.000000e+00, float 2.000000e+00>
  %16 = fadd <8 x float> %15, <float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000>
  %17 = fcmp oge <8 x float> %16, <float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000>
  %18 = fcmp uno <8 x float> %16, zeroinitializer
  %19 = or <8 x i1> %17, %18
  %20 = select <8 x i1> %19, <8 x float> %16, <8 x float> <float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000, float 0xBFEFFFFFE0000000>
  %21 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %20)
  %22 = fcmp oeq <8 x float> %21, <float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00>
  %23 = fneg <8 x float> %20
  %24 = fmul <8 x float> %20, %23
  %25 = fadd <8 x float> %24, <float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00>
  %log_f32.i5 = fcmp ule <8 x float> %25, zeroinitializer
  %log_f321.i6 = sext <8 x i1> %log_f32.i5 to <8 x i32>
  %log_f322.i7 = bitcast <8 x i32> %log_f321.i6 to <8 x float>
  %log_f323.i8 = fcmp oeq <8 x float> %25, zeroinitializer
  %log_f324.i9 = sext <8 x i1> %log_f323.i8 to <8 x i32>
  %log_f325.i10 = bitcast <8 x i32> %log_f324.i9 to <8 x float>
  %log_f326.i11 = fcmp oeq <8 x float> %25, <float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000>
  %log_f327.i12 = sext <8 x i1> %log_f326.i11 to <8 x i32>
  %log_f328.i13 = bitcast <8 x i32> %log_f327.i12 to <8 x float>
  %26 = fcmp uge <8 x float> <float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000>, %25
  %27 = select <8 x i1> %26, <8 x float> <float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000, float 0x3810000000000000>, <8 x float> %25
  %28 = bitcast <8 x float> %27 to <8 x i32>
  %29 = lshr <8 x i32> %28, <i32 23, i32 23, i32 23, i32 23, i32 23, i32 23, i32 23, i32 23>
  %log_f329.i14 = bitcast <8 x float> %27 to <8 x i32>
  %log_f3210.i15 = and <8 x i32> %log_f329.i14, <i32 -2139095041, i32 -2139095041, i32 -2139095041, i32 -2139095041, i32 -2139095041, i32 -2139095041, i32 -2139095041, i32 -2139095041>
  %30 = bitcast <8 x i32> %log_f3210.i15 to <8 x float>
  %log_f3212.i16 = or <8 x i32> %log_f3210.i15, <i32 1056964608, i32 1056964608, i32 1056964608, i32 1056964608, i32 1056964608, i32 1056964608, i32 1056964608, i32 1056964608>
  %log_f3213.i17 = bitcast <8 x i32> %log_f3212.i16 to <8 x float>
  %31 = sub <8 x i32> %29, <i32 127, i32 127, i32 127, i32 127, i32 127, i32 127, i32 127, i32 127>
  %32 = sitofp <8 x i32> %31 to <8 x float>
  %log_f3214.i18 = fadd <8 x float> <float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00>, %32
  %log_f3215.i19 = fcmp olt <8 x float> %log_f3213.i17, <float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000, float 0x3FE6A09E60000000>
  %log_f3216.i20 = sext <8 x i1> %log_f3215.i19 to <8 x i32>
  %log_f3217.i21 = bitcast <8 x i32> %log_f3216.i20 to <8 x float>
  %log_f3220.i22 = and <8 x i32> %log_f3212.i16, %log_f3216.i20
  %33 = bitcast <8 x i32> %log_f3220.i22 to <8 x float>
  %34 = fsub <8 x float> %log_f3213.i17, <float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00>
  %log_f3222.i23 = and <8 x i32> %log_f3216.i20, <i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216, i32 1065353216>
  %35 = bitcast <8 x i32> %log_f3222.i23 to <8 x float>
  %36 = fsub <8 x float> %log_f3214.i18, %35
  %log_f3223.i24 = fadd <8 x float> %34, %33
  %log_f3224.i25 = fmul <8 x float> %log_f3223.i24, %log_f3223.i24
  %log_f3225.i26 = fmul <8 x float> %log_f3224.i25, %log_f3223.i24
  %log_f3226.i27 = fmul <8 x float> %log_f3223.i24, <float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000, float 0x3FB2043760000000>
  %log_f3227.i28 = fadd <8 x float> <float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000, float 0xBFBD7A3700000000>, %log_f3226.i27
  %log_f3228.i29 = fmul <8 x float> %log_f3223.i24, <float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000, float 0xBFBFCBA9E0000000>
  %log_f3229.i30 = fadd <8 x float> <float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000, float 0x3FC23D37E0000000>, %log_f3228.i29
  %log_f3230.i31 = fmul <8 x float> %log_f3223.i24, <float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000, float 0x3FC999D580000000>
  %log_f3231.i32 = fadd <8 x float> <float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000, float 0xBFCFFFFF80000000>, %log_f3230.i31
  %log_f3232.i33 = fmul <8 x float> %log_f3227.i28, %log_f3223.i24
  %log_f3233.i34 = fadd <8 x float> <float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000, float 0x3FBDE4A340000000>, %log_f3232.i33
  %log_f3234.i35 = fmul <8 x float> %log_f3229.i30, %log_f3223.i24
  %log_f3235.i36 = fadd <8 x float> <float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000, float 0xBFC555CA00000000>, %log_f3234.i35
  %log_f3236.i37 = fmul <8 x float> %log_f3231.i32, %log_f3223.i24
  %log_f3237.i38 = fadd <8 x float> <float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000, float 0x3FD5555540000000>, %log_f3236.i37
  %log_f3238.i39 = fmul <8 x float> %log_f3233.i34, %log_f3225.i26
  %log_f3239.i40 = fadd <8 x float> %log_f3235.i36, %log_f3238.i39
  %log_f3240.i41 = fmul <8 x float> %log_f3239.i40, %log_f3225.i26
  %log_f3241.i42 = fadd <8 x float> %log_f3237.i38, %log_f3240.i41
  %log_f3242.i43 = fmul <8 x float> %log_f3241.i42, %log_f3225.i26
  %log_f3243.i44 = fmul <8 x float> <float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000, float 0xBF2BD01060000000>, %36
  %log_f3244.i45 = fmul <8 x float> <float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01>, %log_f3224.i25
  %log_f3245.i46 = fadd <8 x float> %log_f3242.i43, %log_f3243.i44
  %37 = fsub <8 x float> %log_f3223.i24, %log_f3244.i45
  %log_f3246.i47 = fmul <8 x float> <float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000, float 0x3FE6300000000000>, %36
  %log_f3247.i48 = fadd <8 x float> %37, %log_f3245.i46
  %log_f3248.i49 = fadd <8 x float> %log_f3247.i48, %log_f3246.i47
  %log_f3250.i50 = and <8 x i32> %log_f327.i12, <i32 2139095040, i32 2139095040, i32 2139095040, i32 2139095040, i32 2139095040, i32 2139095040, i32 2139095040, i32 2139095040>
  %38 = bitcast <8 x i32> %log_f3250.i50 to <8 x float>
  %log_f3252.i51 = and <8 x i32> %log_f324.i9, <i32 -8388608, i32 -8388608, i32 -8388608, i32 -8388608, i32 -8388608, i32 -8388608, i32 -8388608, i32 -8388608>
  %39 = bitcast <8 x i32> %log_f3252.i51 to <8 x float>
  %log_f3255.i52 = or <8 x i32> %log_f3252.i51, %log_f3250.i50
  %log_f3256.i53 = bitcast <8 x i32> %log_f3255.i52 to <8 x float>
  %log_f3258.i54 = bitcast <8 x float> %log_f3248.i49 to <8 x i32>
  %log_f3259.i55 = or <8 x i32> %log_f3258.i54, %log_f321.i6
  %log_f3260.i56 = bitcast <8 x i32> %log_f3259.i55 to <8 x float>
  %log_f3263.i57 = or <8 x i32> %log_f324.i9, %log_f327.i12
  %log_f3264.i58 = bitcast <8 x i32> %log_f3263.i57 to <8 x float>
  %log_f3266.i59 = xor <8 x i32> %log_f3263.i57, <i32 -1, i32 -1, i32 -1, i32 -1, i32 -1, i32 -1, i32 -1, i32 -1>
  %40 = bitcast <8 x i32> %log_f3266.i59 to <8 x float>
  %log_f3269.i60 = and <8 x i32> %log_f3266.i59, %log_f3259.i55
  %41 = bitcast <8 x i32> %log_f3269.i60 to <8 x float>
  %log_f3272.i61 = or <8 x i32> %log_f3255.i52, %log_f3269.i60
  %log_f3273.i62 = bitcast <8 x i32> %log_f3272.i61 to <8 x float>
  %42 = fmul <8 x float> %24, %24
  %43 = fmul <8 x float> %24, zeroinitializer
  %44 = fadd <8 x float> %43, <float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00>
  %45 = fmul <8 x float> %24, %44
  %46 = fadd <8 x float> %45, <float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000, float 0x402E2035A0000000>
  %47 = fmul <8 x float> %24, %46
  %48 = fadd <8 x float> %47, <float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000, float 0x4054C30B60000000>
  %49 = fmul <8 x float> %24, %48
  %50 = fadd <8 x float> %49, <float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000, float 0x406BB865A0000000>
  %51 = fmul <8 x float> %24, %50
  %52 = fadd <8 x float> %51, <float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000, float 0x4073519460000000>
  %53 = fmul <8 x float> %24, %52
  %54 = fadd <8 x float> %53, <float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000, float 0x406B0DB140000000>
  %55 = fmul <8 x float> %24, %54
  %56 = fadd <8 x float> %55, <float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000, float 0x404E0F3040000000>
  %57 = fadd <8 x float> %43, <float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000, float 0x3F07BC0960000000>
  %58 = fmul <8 x float> %24, %57
  %59 = fadd <8 x float> %58, <float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000, float 0x3FDFE818A0000000>
  %60 = fmul <8 x float> %24, %59
  %61 = fadd <8 x float> %60, <float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000, float 0x401A509F40000000>
  %62 = fmul <8 x float> %24, %61
  %63 = fadd <8 x float> %62, <float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000, float 0x403DE97380000000>
  %64 = fmul <8 x float> %24, %63
  %65 = fadd <8 x float> %64, <float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000, float 0x404E798EC0000000>
  %66 = fmul <8 x float> %24, %65
  %67 = fadd <8 x float> %66, <float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000, float 0x404C8E75A0000000>
  %68 = fmul <8 x float> %24, %67
  %69 = fadd <8 x float> %68, <float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000, float 0x40340A2020000000>
  %70 = fdiv <8 x float> %69, %56
  %71 = fmul <8 x float> %24, %42
  %72 = fmul <8 x float> %71, %70
  %73 = fmul <8 x float> %42, <float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01, float 5.000000e-01>
  %74 = fsub <8 x float> %72, %73
  %75 = fadd <8 x float> %24, %74
  %76 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %24)
  %77 = fcmp olt <8 x float> %76, <float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000, float 0x3FDA8279A0000000>
  %78 = select <8 x i1> %77, <8 x float> %75, <8 x float> %log_f3273.i62
  %79 = fneg <8 x float> %78
  %80 = fcmp ogt <8 x float> %78, <float -5.000000e+00, float -5.000000e+00, float -5.000000e+00, float -5.000000e+00, float -5.000000e+00, float -5.000000e+00, float -5.000000e+00, float -5.000000e+00>
  %81 = select <8 x i1> %80, <8 x float> <float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000, float 0x3FF805C5E0000000>, <8 x float> <float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000, float 0x4006A9EFC0000000>
  %82 = select <8 x i1> %80, <8 x float> <float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000, float 0x3FCF91EC60000000>, <8 x float> <float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000, float 0x3FF006DB60000000>
  %83 = select <8 x i1> %80, <8 x float> <float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000, float 0xBF711C9DE0000000>, <8 x float> <float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000, float 0x3F8354AFC0000000>
  %84 = select <8 x i1> %80, <8 x float> <float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000, float 0xBF548A8100000000>, <8 x float> <float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000, float 0xBF7F38BAE0000000>
  %85 = select <8 x i1> %80, <8 x float> <float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000, float 0x3F2CA65B60000000>, <8 x float> <float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000, float 0x3F77824F60000000>
  %86 = select <8 x i1> %80, <8 x float> <float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000, float 0xBED26B5820000000>, <8 x float> <float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000, float 0xBF6E17BCE0000000>
  %87 = select <8 x i1> %80, <8 x float> <float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000, float 0xBECD8E6AE0000000>, <8 x float> <float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000, float 0x3F561B8E40000000>
  %88 = select <8 x i1> %80, <8 x float> <float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000, float 0x3E970966C0000000>, <8 x float> <float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000, float 0x3F1A76AD60000000>
  %89 = select <8 x i1> %80, <8 x float> <float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000, float 0x3E5E2CB100000000>, <8 x float> <float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000, float 0xBF2A3E1360000000>
  %90 = fsub <8 x float> <float -2.500000e+00, float -2.500000e+00, float -2.500000e+00, float -2.500000e+00, float -2.500000e+00, float -2.500000e+00, float -2.500000e+00, float -2.500000e+00>, %78
  %91 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %79)
  %92 = fadd <8 x float> %91, <float -3.000000e+00, float -3.000000e+00, float -3.000000e+00, float -3.000000e+00, float -3.000000e+00, float -3.000000e+00, float -3.000000e+00, float -3.000000e+00>
  %93 = select <8 x i1> %80, <8 x float> %90, <8 x float> %92
  %94 = fmul <8 x float> %89, %93
  %95 = fadd <8 x float> %88, %94
  %96 = fmul <8 x float> %93, %95
  %97 = fadd <8 x float> %87, %96
  %98 = fmul <8 x float> %93, %97
  %99 = fadd <8 x float> %86, %98
  %100 = fmul <8 x float> %93, %99
  %101 = fadd <8 x float> %85, %100
  %102 = fmul <8 x float> %93, %101
  %103 = fadd <8 x float> %84, %102
  %104 = fmul <8 x float> %93, %103
  %105 = fadd <8 x float> %83, %104
  %106 = fmul <8 x float> %93, %105
  %107 = fadd <8 x float> %82, %106
  %108 = fmul <8 x float> %93, %107
  %109 = fadd <8 x float> %81, %108
  %110 = select <8 x i1> %22, <8 x float> <float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000, float 0x7FF0000000000000>, <8 x float> %109
  %111 = fmul <8 x float> %20, %110
  %112 = fmul <8 x float> %111, <float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000, float 0x3FF6A09E60000000>
  %113 = getelementptr inbounds [10000 x float], ptr %fusion.2.clone, i64 0, i64 %offset.idx
  store <8 x float> %112, ptr %113, align 4, !alias.scope !8
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add <8 x i64> %vec.ind, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %114 = icmp eq i64 %index.next, %n.vec
  br i1 %114, label %middle.block, label %vector.body, !llvm.loop !10

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %5, %n.vec
  br i1 %cmp.n, label %fusion.2.clone.loop_exit.dim.0, label %concatenate.pivot.5000..preheader4

concatenate.pivot.5000..preheader4:               ; preds = %middle.block, %concatenate.pivot.5000..preheader
  %fusion.2.clone.invar_address.dim.0.03.ph = phi i64 [ %3, %concatenate.pivot.5000..preheader ], [ %ind.end, %middle.block ]
  br label %concatenate.pivot.5000.

concatenate.pivot.5000.:                          ; preds = %concatenate.pivot.5000., %concatenate.pivot.5000..preheader4
  %fusion.2.clone.invar_address.dim.0.03 = phi i64 [ %invar.inc, %concatenate.pivot.5000. ], [ %fusion.2.clone.invar_address.dim.0.03.ph, %concatenate.pivot.5000..preheader4 ]
  %115 = icmp ult i64 %fusion.2.clone.invar_address.dim.0.03, 5000
  %116 = getelementptr inbounds [5000 x i32], ptr %p.9, i64 0, i64 %fusion.2.clone.invar_address.dim.0.03
  %117 = add nsw i64 %fusion.2.clone.invar_address.dim.0.03, -5000
  %118 = getelementptr inbounds [5000 x i32], ptr %p.10, i64 0, i64 %117
  %.in = select i1 %115, ptr %116, ptr %118
  %119 = load i32, ptr %.in, align 4, !alias.scope !4, !noalias !8
  %120 = lshr i32 %119, 9
  %121 = or i32 %120, 1065353216
  %122 = bitcast i32 %121 to float
  %add.114 = fadd float %122, -1.000000e+00
  %multiply.51 = fmul float %add.114, 2.000000e+00
  %add.113 = fadd float %multiply.51, 0xBFEFFFFFE0000000
  %123 = fcmp oge float %add.113, 0xBFEFFFFFE0000000
  %124 = fcmp uno float %add.113, 0.000000e+00
  %125 = or i1 %123, %124
  %maximum.1 = select i1 %125, float %add.113, float 0xBFEFFFFFE0000000
  %126 = tail call float @llvm.fabs.f32(float %maximum.1)
  %compare.9 = fcmp oeq float %126, 1.000000e+00
  %127 = fneg float %maximum.1
  %multiply.49 = fmul float %maximum.1, %127
  %128 = fadd float %multiply.49, 1.000000e+00
  %129 = insertelement <1 x float> undef, float %128, i64 0
  %log_f32.i = fcmp ule <1 x float> %129, zeroinitializer
  %log_f321.i = sext <1 x i1> %log_f32.i to <1 x i32>
  %log_f322.i = bitcast <1 x i32> %log_f321.i to <1 x float>
  %log_f323.i = fcmp oeq <1 x float> %129, zeroinitializer
  %log_f324.i = sext <1 x i1> %log_f323.i to <1 x i32>
  %log_f325.i = bitcast <1 x i32> %log_f324.i to <1 x float>
  %log_f326.i = fcmp oeq <1 x float> %129, <float 0x7FF0000000000000>
  %log_f327.i = sext <1 x i1> %log_f326.i to <1 x i32>
  %log_f328.i = bitcast <1 x i32> %log_f327.i to <1 x float>
  %130 = fcmp uge <1 x float> <float 0x3810000000000000>, %129
  %131 = select <1 x i1> %130, <1 x float> <float 0x3810000000000000>, <1 x float> %129
  %132 = bitcast <1 x float> %131 to <1 x i32>
  %133 = lshr <1 x i32> %132, <i32 23>
  %log_f329.i = bitcast <1 x float> %131 to <1 x i32>
  %log_f3210.i = and <1 x i32> %log_f329.i, <i32 -2139095041>
  %134 = bitcast <1 x i32> %log_f3210.i to <1 x float>
  %log_f3212.i = or <1 x i32> %log_f3210.i, <i32 1056964608>
  %log_f3213.i = bitcast <1 x i32> %log_f3212.i to <1 x float>
  %135 = sub <1 x i32> %133, <i32 127>
  %136 = sitofp <1 x i32> %135 to <1 x float>
  %log_f3214.i = fadd <1 x float> <float 1.000000e+00>, %136
  %log_f3215.i = fcmp olt <1 x float> %log_f3213.i, <float 0x3FE6A09E60000000>
  %log_f3216.i = sext <1 x i1> %log_f3215.i to <1 x i32>
  %log_f3217.i = bitcast <1 x i32> %log_f3216.i to <1 x float>
  %log_f3220.i = and <1 x i32> %log_f3212.i, %log_f3216.i
  %137 = bitcast <1 x i32> %log_f3220.i to <1 x float>
  %138 = fsub <1 x float> %log_f3213.i, <float 1.000000e+00>
  %log_f3222.i = and <1 x i32> %log_f3216.i, <i32 1065353216>
  %139 = bitcast <1 x i32> %log_f3222.i to <1 x float>
  %140 = fsub <1 x float> %log_f3214.i, %139
  %log_f3223.i = fadd <1 x float> %138, %137
  %log_f3224.i = fmul <1 x float> %log_f3223.i, %log_f3223.i
  %log_f3225.i = fmul <1 x float> %log_f3224.i, %log_f3223.i
  %log_f3226.i = fmul <1 x float> %log_f3223.i, <float 0x3FB2043760000000>
  %log_f3227.i = fadd <1 x float> <float 0xBFBD7A3700000000>, %log_f3226.i
  %log_f3228.i = fmul <1 x float> %log_f3223.i, <float 0xBFBFCBA9E0000000>
  %log_f3229.i = fadd <1 x float> <float 0x3FC23D37E0000000>, %log_f3228.i
  %log_f3230.i = fmul <1 x float> %log_f3223.i, <float 0x3FC999D580000000>
  %log_f3231.i = fadd <1 x float> <float 0xBFCFFFFF80000000>, %log_f3230.i
  %log_f3232.i = fmul <1 x float> %log_f3227.i, %log_f3223.i
  %log_f3233.i = fadd <1 x float> <float 0x3FBDE4A340000000>, %log_f3232.i
  %log_f3234.i = fmul <1 x float> %log_f3229.i, %log_f3223.i
  %log_f3235.i = fadd <1 x float> <float 0xBFC555CA00000000>, %log_f3234.i
  %log_f3236.i = fmul <1 x float> %log_f3231.i, %log_f3223.i
  %log_f3237.i = fadd <1 x float> <float 0x3FD5555540000000>, %log_f3236.i
  %log_f3238.i = fmul <1 x float> %log_f3233.i, %log_f3225.i
  %log_f3239.i = fadd <1 x float> %log_f3235.i, %log_f3238.i
  %log_f3240.i = fmul <1 x float> %log_f3239.i, %log_f3225.i
  %log_f3241.i = fadd <1 x float> %log_f3237.i, %log_f3240.i
  %log_f3242.i = fmul <1 x float> %log_f3241.i, %log_f3225.i
  %log_f3243.i = fmul <1 x float> <float 0xBF2BD01060000000>, %140
  %log_f3244.i = fmul <1 x float> <float 5.000000e-01>, %log_f3224.i
  %log_f3245.i = fadd <1 x float> %log_f3242.i, %log_f3243.i
  %141 = fsub <1 x float> %log_f3223.i, %log_f3244.i
  %log_f3246.i = fmul <1 x float> <float 0x3FE6300000000000>, %140
  %log_f3247.i = fadd <1 x float> %141, %log_f3245.i
  %log_f3248.i = fadd <1 x float> %log_f3247.i, %log_f3246.i
  %log_f3250.i = and <1 x i32> %log_f327.i, <i32 2139095040>
  %142 = bitcast <1 x i32> %log_f3250.i to <1 x float>
  %log_f3252.i = and <1 x i32> %log_f324.i, <i32 -8388608>
  %143 = bitcast <1 x i32> %log_f3252.i to <1 x float>
  %log_f3255.i = or <1 x i32> %log_f3252.i, %log_f3250.i
  %log_f3256.i = bitcast <1 x i32> %log_f3255.i to <1 x float>
  %log_f3258.i = bitcast <1 x float> %log_f3248.i to <1 x i32>
  %log_f3259.i = or <1 x i32> %log_f3258.i, %log_f321.i
  %log_f3260.i = bitcast <1 x i32> %log_f3259.i to <1 x float>
  %log_f3263.i = or <1 x i32> %log_f324.i, %log_f327.i
  %log_f3264.i = bitcast <1 x i32> %log_f3263.i to <1 x float>
  %log_f3266.i = xor <1 x i32> %log_f3263.i, <i32 -1>
  %144 = bitcast <1 x i32> %log_f3266.i to <1 x float>
  %log_f3269.i = and <1 x i32> %log_f3266.i, %log_f3259.i
  %145 = bitcast <1 x i32> %log_f3269.i to <1 x float>
  %log_f3272.i = or <1 x i32> %log_f3255.i, %log_f3269.i
  %log_f3273.i = bitcast <1 x i32> %log_f3272.i to <1 x float>
  %146 = extractelement <1 x float> %log_f3273.i, i64 0
  %147 = fmul float %multiply.49, %multiply.49
  %148 = fmul float %multiply.49, 0.000000e+00
  %149 = insertelement <2 x float> poison, float %148, i64 0
  %150 = shufflevector <2 x float> %149, <2 x float> poison, <2 x i32> zeroinitializer
  %151 = fadd <2 x float> %150, <float 0x3F07BC0960000000, float 1.000000e+00>
  %152 = insertelement <2 x float> poison, float %multiply.49, i64 0
  %153 = shufflevector <2 x float> %152, <2 x float> poison, <2 x i32> zeroinitializer
  %154 = fmul <2 x float> %153, %151
  %155 = fadd <2 x float> %154, <float 0x3FDFE818A0000000, float 0x402E2035A0000000>
  %156 = fmul <2 x float> %153, %155
  %157 = fadd <2 x float> %156, <float 0x401A509F40000000, float 0x4054C30B60000000>
  %158 = fmul <2 x float> %153, %157
  %159 = fadd <2 x float> %158, <float 0x403DE97380000000, float 0x406BB865A0000000>
  %160 = fmul <2 x float> %153, %159
  %161 = fadd <2 x float> %160, <float 0x404E798EC0000000, float 0x4073519460000000>
  %162 = fmul <2 x float> %153, %161
  %163 = fadd <2 x float> %162, <float 0x404C8E75A0000000, float 0x406B0DB140000000>
  %164 = fmul <2 x float> %153, %163
  %165 = fadd <2 x float> %164, <float 0x40340A2020000000, float 0x404E0F3040000000>
  %shift = shufflevector <2 x float> %165, <2 x float> poison, <2 x i32> <i32 1, i32 undef>
  %166 = fdiv <2 x float> %165, %shift
  %167 = extractelement <2 x float> %166, i64 0
  %168 = fmul float %multiply.49, %147
  %169 = fmul float %168, %167
  %170 = fmul float %147, 5.000000e-01
  %171 = fsub float %169, %170
  %172 = fadd float %multiply.49, %171
  %173 = tail call float @llvm.fabs.f32(float %multiply.49)
  %174 = fcmp olt float %173, 0x3FDA8279A0000000
  %175 = select i1 %174, float %172, float %146
  %176 = fneg float %175
  %compare.8 = fcmp ogt float %175, -5.000000e+00
  %177 = select i1 %compare.8, float 0x3FF805C5E0000000, float 0x4006A9EFC0000000
  %178 = select i1 %compare.8, float 0x3FCF91EC60000000, float 0x3FF006DB60000000
  %179 = select i1 %compare.8, float 0xBF711C9DE0000000, float 0x3F8354AFC0000000
  %180 = select i1 %compare.8, float 0xBF548A8100000000, float 0xBF7F38BAE0000000
  %181 = select i1 %compare.8, float 0x3F2CA65B60000000, float 0x3F77824F60000000
  %182 = select i1 %compare.8, float 0xBED26B5820000000, float 0xBF6E17BCE0000000
  %183 = select i1 %compare.8, float 0xBECD8E6AE0000000, float 0x3F561B8E40000000
  %184 = select i1 %compare.8, float 0x3E970966C0000000, float 0x3F1A76AD60000000
  %185 = select i1 %compare.8, float 0x3E5E2CB100000000, float 0xBF2A3E1360000000
  %add.112 = fsub float -2.500000e+00, %175
  %186 = tail call float @llvm.sqrt.f32(float %176)
  %add.111 = fadd float %186, -3.000000e+00
  %187 = select i1 %compare.8, float %add.112, float %add.111
  %multiply.48 = fmul float %185, %187
  %add.110 = fadd float %184, %multiply.48
  %multiply.47 = fmul float %187, %add.110
  %add.109 = fadd float %183, %multiply.47
  %multiply.46 = fmul float %187, %add.109
  %add.108 = fadd float %182, %multiply.46
  %multiply.45 = fmul float %187, %add.108
  %add.107 = fadd float %181, %multiply.45
  %multiply.44 = fmul float %187, %add.107
  %add.106 = fadd float %180, %multiply.44
  %multiply.43 = fmul float %187, %add.106
  %add.105 = fadd float %179, %multiply.43
  %multiply.42 = fmul float %187, %add.105
  %add.104 = fadd float %178, %multiply.42
  %multiply.41 = fmul float %187, %add.104
  %add.103 = fadd float %177, %multiply.41
  %.v = select i1 %compare.9, float 0x7FF0000000000000, float %add.103
  %188 = fmul float %maximum.1, %.v
  %multiply.39 = fmul float %188, 0x3FF6A09E60000000
  %189 = getelementptr inbounds [10000 x float], ptr %fusion.2.clone, i64 0, i64 %fusion.2.clone.invar_address.dim.0.03
  store float %multiply.39, ptr %189, align 4, !alias.scope !8
  %invar.inc = add nuw nsw i64 %fusion.2.clone.invar_address.dim.0.03, 1
  %exitcond.not = icmp eq i64 %invar.inc, %4
  br i1 %exitcond.not, label %fusion.2.clone.loop_exit.dim.0, label %concatenate.pivot.5000., !llvm.loop !12

fusion.2.clone.loop_exit.dim.0:                   ; preds = %concatenate.pivot.5000., %middle.block, %entry
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.sqrt.f32(float) #1

; Function Attrs: nofree norecurse nosync nounwind uwtable
define internal void @parallel_fusion.1(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readonly %dynamic_loop_bounds, ptr noalias nocapture readnone %prof_counters) #2 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.7 = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %p.8 = getelementptr inbounds i8, ptr %1, i64 40064
  %fusion.1.clone = getelementptr inbounds i8, ptr %1, i64 64
  %dynamic_loop_bound_0 = load i64, ptr %dynamic_loop_bounds, align 8
  %2 = getelementptr i64, ptr %dynamic_loop_bounds, i64 1
  %dynamic_loop_bound_1 = load i64, ptr %2, align 8
  %.not8 = icmp ugt i64 %dynamic_loop_bound_1, %dynamic_loop_bound_0
  br i1 %.not8, label %fusion.1.clone.loop_body.dim.0.lr.ph, label %fusion.1.clone.loop_exit.dim.0

fusion.1.clone.loop_body.dim.0.lr.ph:             ; preds = %entry
  %p.6 = getelementptr inbounds i8, ptr %1, i64 60064
  %p.5 = getelementptr inbounds i8, ptr %1, i64 60112
  %3 = load i32, ptr %p.6, align 16, !alias.scope !14, !noalias !16
  %shft.chk = icmp ult i32 %3, 32
  %4 = sub i32 32, %3
  %shft.chk1 = icmp ult i32 %4, 32
  %5 = getelementptr inbounds i8, ptr %1, i64 60068
  %6 = load i32, ptr %5, align 4, !alias.scope !14, !noalias !16
  %shft.chk2 = icmp ult i32 %6, 32
  %7 = sub i32 32, %6
  %shft.chk4 = icmp ult i32 %7, 32
  %8 = getelementptr inbounds i8, ptr %1, i64 60072
  %9 = load i32, ptr %8, align 8, !alias.scope !14, !noalias !16
  %shft.chk5 = icmp ult i32 %9, 32
  %10 = sub i32 32, %9
  %shft.chk7 = icmp ult i32 %10, 32
  %11 = load i32, ptr %p.5, align 16, !alias.scope !17, !noalias !16
  %12 = sub i64 %dynamic_loop_bound_1, %dynamic_loop_bound_0
  %min.iters.check = icmp ult i64 %12, 8
  br i1 %min.iters.check, label %fusion.1.clone.loop_body.dim.0.preheader, label %vector.ph

vector.ph:                                        ; preds = %fusion.1.clone.loop_body.dim.0.lr.ph
  %n.vec = and i64 %12, -8
  %ind.end = add i64 %dynamic_loop_bound_0, %n.vec
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %3, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert11 = insertelement <8 x i32> poison, i32 %4, i64 0
  %broadcast.splat12 = shufflevector <8 x i32> %broadcast.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert13 = insertelement <8 x i32> poison, i32 %6, i64 0
  %broadcast.splat14 = shufflevector <8 x i32> %broadcast.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert15 = insertelement <8 x i32> poison, i32 %7, i64 0
  %broadcast.splat16 = shufflevector <8 x i32> %broadcast.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert17 = insertelement <8 x i32> poison, i32 %9, i64 0
  %broadcast.splat18 = shufflevector <8 x i32> %broadcast.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert19 = insertelement <8 x i32> poison, i32 %10, i64 0
  %broadcast.splat20 = shufflevector <8 x i32> %broadcast.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert21 = insertelement <8 x i32> poison, i32 %11, i64 0
  %broadcast.splat22 = shufflevector <8 x i32> %broadcast.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %offset.idx = add i64 %dynamic_loop_bound_0, %index
  %13 = getelementptr inbounds [5000 x i32], ptr %p.8, i64 0, i64 %offset.idx
  %wide.load = load <8 x i32>, ptr %13, align 4, !alias.scope !19, !noalias !16
  %14 = getelementptr inbounds [5000 x i32], ptr %p.7, i64 0, i64 %offset.idx
  %wide.load10 = load <8 x i32>, ptr %14, align 4, !alias.scope !21, !noalias !16
  %15 = add <8 x i32> %wide.load10, %wide.load
  %16 = shl <8 x i32> %wide.load10, %broadcast.splat
  %17 = select i1 %shft.chk, <8 x i32> %16, <8 x i32> zeroinitializer
  %18 = lshr <8 x i32> %wide.load10, %broadcast.splat12
  %19 = select i1 %shft.chk1, <8 x i32> %18, <8 x i32> zeroinitializer
  %20 = or <8 x i32> %19, %17
  %21 = xor <8 x i32> %20, %15
  %22 = add <8 x i32> %21, %15
  %23 = shl <8 x i32> %21, %broadcast.splat14
  %24 = select i1 %shft.chk2, <8 x i32> %23, <8 x i32> zeroinitializer
  %25 = lshr <8 x i32> %21, %broadcast.splat16
  %26 = select i1 %shft.chk4, <8 x i32> %25, <8 x i32> zeroinitializer
  %27 = or <8 x i32> %24, %26
  %28 = xor <8 x i32> %27, %22
  %29 = add <8 x i32> %28, %22
  %30 = shl <8 x i32> %28, %broadcast.splat18
  %31 = select i1 %shft.chk5, <8 x i32> %30, <8 x i32> zeroinitializer
  %32 = lshr <8 x i32> %28, %broadcast.splat20
  %33 = select i1 %shft.chk7, <8 x i32> %32, <8 x i32> zeroinitializer
  %34 = or <8 x i32> %31, %33
  %35 = xor <8 x i32> %34, %29
  %36 = add <8 x i32> %29, %broadcast.splat22
  %37 = add <8 x i32> %36, %35
  %38 = getelementptr inbounds [5000 x i32], ptr %fusion.1.clone, i64 0, i64 %offset.idx
  store <8 x i32> %37, ptr %38, align 4, !alias.scope !16
  %index.next = add nuw i64 %index, 8
  %39 = icmp eq i64 %index.next, %n.vec
  br i1 %39, label %middle.block, label %vector.body, !llvm.loop !23

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %12, %n.vec
  br i1 %cmp.n, label %fusion.1.clone.loop_exit.dim.0, label %fusion.1.clone.loop_body.dim.0.preheader

fusion.1.clone.loop_body.dim.0.preheader:         ; preds = %middle.block, %fusion.1.clone.loop_body.dim.0.lr.ph
  %fusion.1.clone.invar_address.dim.0.09.ph = phi i64 [ %dynamic_loop_bound_0, %fusion.1.clone.loop_body.dim.0.lr.ph ], [ %ind.end, %middle.block ]
  br label %fusion.1.clone.loop_body.dim.0

fusion.1.clone.loop_body.dim.0:                   ; preds = %fusion.1.clone.loop_body.dim.0, %fusion.1.clone.loop_body.dim.0.preheader
  %fusion.1.clone.invar_address.dim.0.09 = phi i64 [ %invar.inc, %fusion.1.clone.loop_body.dim.0 ], [ %fusion.1.clone.invar_address.dim.0.09.ph, %fusion.1.clone.loop_body.dim.0.preheader ]
  %40 = getelementptr inbounds [5000 x i32], ptr %p.8, i64 0, i64 %fusion.1.clone.invar_address.dim.0.09
  %41 = load i32, ptr %40, align 4, !alias.scope !19, !noalias !16
  %42 = getelementptr inbounds [5000 x i32], ptr %p.7, i64 0, i64 %fusion.1.clone.invar_address.dim.0.09
  %43 = load i32, ptr %42, align 4, !alias.scope !21, !noalias !16
  %44 = add i32 %43, %41
  %45 = shl i32 %43, %3
  %46 = select i1 %shft.chk, i32 %45, i32 0
  %47 = lshr i32 %43, %4
  %48 = select i1 %shft.chk1, i32 %47, i32 0
  %49 = or i32 %48, %46
  %50 = xor i32 %49, %44
  %51 = add i32 %50, %44
  %52 = shl i32 %50, %6
  %53 = select i1 %shft.chk2, i32 %52, i32 0
  %54 = lshr i32 %50, %7
  %55 = select i1 %shft.chk4, i32 %54, i32 0
  %56 = or i32 %53, %55
  %57 = xor i32 %56, %51
  %58 = add i32 %57, %51
  %59 = shl i32 %57, %9
  %60 = select i1 %shft.chk5, i32 %59, i32 0
  %61 = lshr i32 %57, %10
  %62 = select i1 %shft.chk7, i32 %61, i32 0
  %63 = or i32 %60, %62
  %64 = xor i32 %63, %58
  %65 = add i32 %58, %11
  %66 = add i32 %65, %64
  %67 = getelementptr inbounds [5000 x i32], ptr %fusion.1.clone, i64 0, i64 %fusion.1.clone.invar_address.dim.0.09
  store i32 %66, ptr %67, align 4, !alias.scope !16
  %invar.inc = add nuw nsw i64 %fusion.1.clone.invar_address.dim.0.09, 1
  %exitcond.not = icmp eq i64 %invar.inc, %dynamic_loop_bound_1
  br i1 %exitcond.not, label %fusion.1.clone.loop_exit.dim.0, label %fusion.1.clone.loop_body.dim.0, !llvm.loop !24

fusion.1.clone.loop_exit.dim.0:                   ; preds = %fusion.1.clone.loop_body.dim.0, %middle.block, %entry
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind uwtable
define internal void @parallel_fusion(ptr nocapture readnone %retval, ptr noalias nocapture readnone %run_options, ptr noalias nocapture readnone %params, ptr noalias nocapture readonly %buffer_table, ptr noalias nocapture readnone %status, ptr noalias nocapture readonly %dynamic_loop_bounds, ptr noalias nocapture readnone %prof_counters) #2 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %p.2 = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  %p.3 = getelementptr inbounds i8, ptr %1, i64 40064
  %fusion.clone = getelementptr inbounds i8, ptr %1, i64 20064
  %dynamic_loop_bound_0 = load i64, ptr %dynamic_loop_bounds, align 8
  %2 = getelementptr i64, ptr %dynamic_loop_bounds, i64 1
  %dynamic_loop_bound_1 = load i64, ptr %2, align 8
  %.not11 = icmp ugt i64 %dynamic_loop_bound_1, %dynamic_loop_bound_0
  br i1 %.not11, label %fusion.clone.loop_body.dim.0.lr.ph, label %fusion.clone.loop_exit.dim.0

fusion.clone.loop_body.dim.0.lr.ph:               ; preds = %entry
  %p.4 = getelementptr inbounds i8, ptr %1, i64 60176
  %p.1 = getelementptr inbounds i8, ptr %1, i64 60064
  %p = getelementptr inbounds i8, ptr %1, i64 60096
  %3 = load i32, ptr %p.1, align 16, !alias.scope !14, !noalias !25
  %shft.chk = icmp ult i32 %3, 32
  %4 = sub i32 32, %3
  %shft.chk1 = icmp ult i32 %4, 32
  %5 = getelementptr inbounds i8, ptr %1, i64 60068
  %6 = load i32, ptr %5, align 4, !alias.scope !14, !noalias !25
  %shft.chk2 = icmp ult i32 %6, 32
  %7 = sub i32 32, %6
  %shft.chk4 = icmp ult i32 %7, 32
  %8 = getelementptr inbounds i8, ptr %1, i64 60072
  %9 = load i32, ptr %8, align 8, !alias.scope !14, !noalias !25
  %shft.chk5 = icmp ult i32 %9, 32
  %10 = sub i32 32, %9
  %shft.chk7 = icmp ult i32 %10, 32
  %11 = getelementptr inbounds i8, ptr %1, i64 60076
  %12 = load i32, ptr %11, align 4, !alias.scope !14, !noalias !25
  %shft.chk8 = icmp ult i32 %12, 32
  %13 = sub i32 32, %12
  %shft.chk10 = icmp ult i32 %13, 32
  %14 = load i32, ptr %p, align 16, !alias.scope !26, !noalias !25
  %15 = load i32, ptr %p.4, align 16, !alias.scope !28, !noalias !25
  %16 = add i32 %14, 1
  %17 = add i32 %16, %15
  %18 = sub i64 %dynamic_loop_bound_1, %dynamic_loop_bound_0
  %min.iters.check = icmp ult i64 %18, 8
  br i1 %min.iters.check, label %fusion.clone.loop_body.dim.0.preheader, label %vector.ph

vector.ph:                                        ; preds = %fusion.clone.loop_body.dim.0.lr.ph
  %n.vec = and i64 %18, -8
  %ind.end = add i64 %dynamic_loop_bound_0, %n.vec
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %3, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert14 = insertelement <8 x i32> poison, i32 %4, i64 0
  %broadcast.splat15 = shufflevector <8 x i32> %broadcast.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert16 = insertelement <8 x i32> poison, i32 %6, i64 0
  %broadcast.splat17 = shufflevector <8 x i32> %broadcast.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert18 = insertelement <8 x i32> poison, i32 %7, i64 0
  %broadcast.splat19 = shufflevector <8 x i32> %broadcast.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert20 = insertelement <8 x i32> poison, i32 %9, i64 0
  %broadcast.splat21 = shufflevector <8 x i32> %broadcast.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert22 = insertelement <8 x i32> poison, i32 %10, i64 0
  %broadcast.splat23 = shufflevector <8 x i32> %broadcast.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert24 = insertelement <8 x i32> poison, i32 %12, i64 0
  %broadcast.splat25 = shufflevector <8 x i32> %broadcast.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert26 = insertelement <8 x i32> poison, i32 %13, i64 0
  %broadcast.splat27 = shufflevector <8 x i32> %broadcast.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert28 = insertelement <8 x i32> poison, i32 %17, i64 0
  %broadcast.splat29 = shufflevector <8 x i32> %broadcast.splatinsert28, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %offset.idx = add i64 %dynamic_loop_bound_0, %index
  %19 = getelementptr inbounds [5000 x i32], ptr %p.3, i64 0, i64 %offset.idx
  %wide.load = load <8 x i32>, ptr %19, align 4, !alias.scope !19, !noalias !25
  %20 = getelementptr inbounds [5000 x i32], ptr %p.2, i64 0, i64 %offset.idx
  %wide.load13 = load <8 x i32>, ptr %20, align 4, !alias.scope !21, !noalias !25
  %21 = add <8 x i32> %wide.load13, %wide.load
  %22 = shl <8 x i32> %wide.load13, %broadcast.splat
  %23 = select i1 %shft.chk, <8 x i32> %22, <8 x i32> zeroinitializer
  %24 = lshr <8 x i32> %wide.load13, %broadcast.splat15
  %25 = select i1 %shft.chk1, <8 x i32> %24, <8 x i32> zeroinitializer
  %26 = or <8 x i32> %25, %23
  %27 = xor <8 x i32> %26, %21
  %28 = add <8 x i32> %27, %21
  %29 = shl <8 x i32> %27, %broadcast.splat17
  %30 = select i1 %shft.chk2, <8 x i32> %29, <8 x i32> zeroinitializer
  %31 = lshr <8 x i32> %27, %broadcast.splat19
  %32 = select i1 %shft.chk4, <8 x i32> %31, <8 x i32> zeroinitializer
  %33 = or <8 x i32> %30, %32
  %34 = xor <8 x i32> %33, %28
  %35 = add <8 x i32> %34, %28
  %36 = shl <8 x i32> %34, %broadcast.splat21
  %37 = select i1 %shft.chk5, <8 x i32> %36, <8 x i32> zeroinitializer
  %38 = lshr <8 x i32> %34, %broadcast.splat23
  %39 = select i1 %shft.chk7, <8 x i32> %38, <8 x i32> zeroinitializer
  %40 = or <8 x i32> %37, %39
  %41 = xor <8 x i32> %40, %35
  %42 = add <8 x i32> %41, %35
  %43 = shl <8 x i32> %41, %broadcast.splat25
  %44 = select i1 %shft.chk8, <8 x i32> %43, <8 x i32> zeroinitializer
  %45 = lshr <8 x i32> %41, %broadcast.splat27
  %46 = select i1 %shft.chk10, <8 x i32> %45, <8 x i32> zeroinitializer
  %47 = or <8 x i32> %44, %46
  %48 = xor <8 x i32> %47, %42
  %49 = add <8 x i32> %broadcast.splat29, %48
  %50 = getelementptr inbounds [5000 x i32], ptr %fusion.clone, i64 0, i64 %offset.idx
  store <8 x i32> %49, ptr %50, align 4, !alias.scope !25
  %index.next = add nuw i64 %index, 8
  %51 = icmp eq i64 %index.next, %n.vec
  br i1 %51, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %18, %n.vec
  br i1 %cmp.n, label %fusion.clone.loop_exit.dim.0, label %fusion.clone.loop_body.dim.0.preheader

fusion.clone.loop_body.dim.0.preheader:           ; preds = %middle.block, %fusion.clone.loop_body.dim.0.lr.ph
  %fusion.clone.invar_address.dim.0.012.ph = phi i64 [ %dynamic_loop_bound_0, %fusion.clone.loop_body.dim.0.lr.ph ], [ %ind.end, %middle.block ]
  br label %fusion.clone.loop_body.dim.0

fusion.clone.loop_body.dim.0:                     ; preds = %fusion.clone.loop_body.dim.0, %fusion.clone.loop_body.dim.0.preheader
  %fusion.clone.invar_address.dim.0.012 = phi i64 [ %invar.inc, %fusion.clone.loop_body.dim.0 ], [ %fusion.clone.invar_address.dim.0.012.ph, %fusion.clone.loop_body.dim.0.preheader ]
  %52 = getelementptr inbounds [5000 x i32], ptr %p.3, i64 0, i64 %fusion.clone.invar_address.dim.0.012
  %53 = load i32, ptr %52, align 4, !alias.scope !19, !noalias !25
  %54 = getelementptr inbounds [5000 x i32], ptr %p.2, i64 0, i64 %fusion.clone.invar_address.dim.0.012
  %55 = load i32, ptr %54, align 4, !alias.scope !21, !noalias !25
  %56 = add i32 %55, %53
  %57 = shl i32 %55, %3
  %58 = select i1 %shft.chk, i32 %57, i32 0
  %59 = lshr i32 %55, %4
  %60 = select i1 %shft.chk1, i32 %59, i32 0
  %61 = or i32 %60, %58
  %62 = xor i32 %61, %56
  %63 = add i32 %62, %56
  %64 = shl i32 %62, %6
  %65 = select i1 %shft.chk2, i32 %64, i32 0
  %66 = lshr i32 %62, %7
  %67 = select i1 %shft.chk4, i32 %66, i32 0
  %68 = or i32 %65, %67
  %69 = xor i32 %68, %63
  %70 = add i32 %69, %63
  %71 = shl i32 %69, %9
  %72 = select i1 %shft.chk5, i32 %71, i32 0
  %73 = lshr i32 %69, %10
  %74 = select i1 %shft.chk7, i32 %73, i32 0
  %75 = or i32 %72, %74
  %76 = xor i32 %75, %70
  %77 = add i32 %76, %70
  %78 = shl i32 %76, %12
  %79 = select i1 %shft.chk8, i32 %78, i32 0
  %80 = lshr i32 %76, %13
  %81 = select i1 %shft.chk10, i32 %80, i32 0
  %82 = or i32 %79, %81
  %83 = xor i32 %82, %77
  %84 = add i32 %17, %83
  %85 = getelementptr inbounds [5000 x i32], ptr %fusion.clone, i64 0, i64 %fusion.clone.invar_address.dim.0.012
  store i32 %84, ptr %85, align 4, !alias.scope !25
  %invar.inc = add nuw nsw i64 %fusion.clone.invar_address.dim.0.012, 1
  %exitcond.not = icmp eq i64 %invar.inc, %dynamic_loop_bound_1
  br i1 %exitcond.not, label %fusion.clone.loop_exit.dim.0, label %fusion.clone.loop_body.dim.0, !llvm.loop !31

fusion.clone.loop_exit.dim.0:                     ; preds = %fusion.clone.loop_body.dim.0, %middle.block, %entry
  ret void
}

; Function Attrs: inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: nounwind
declare void @__xla_cpu_runtime_ParallelForkJoin(ptr, ptr, ptr, ptr, ptr, ptr, i32, ptr, i32, ptr) local_unnamed_addr #4

; Function Attrs: nounwind uwtable
define void @main.219(ptr nocapture readnone %retval, ptr noalias %run_options, ptr noalias nocapture readnone %params, ptr noalias %buffer_table, ptr noalias %status, ptr noalias %prof_counters) local_unnamed_addr #5 {
entry:
  %0 = getelementptr inbounds ptr, ptr %buffer_table, i64 4
  %Arg_0.1 = load ptr, ptr %0, align 8, !invariant.load !0, !dereferenceable !32, !align !32
  %1 = getelementptr inbounds ptr, ptr %buffer_table, i64 7
  %2 = load ptr, ptr %1, align 8, !invariant.load !0, !dereferenceable !1, !align !2
  %fusion.4 = getelementptr inbounds i8, ptr %2, i64 20064
  %3 = getelementptr inbounds [2 x i32], ptr %Arg_0.1, i64 0, i64 1
  %4 = load i32, ptr %3, align 4, !invariant.load !0, !noalias !33
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %4, i64 0
  %broadcast.splatinsert8 = insertelement <8 x i32> poison, i32 %4, i64 0
  %broadcast.splatinsert10 = insertelement <8 x i32> poison, i32 %4, i64 0
  %broadcast.splatinsert12 = insertelement <8 x i32> poison, i32 %4, i64 0
  %5 = add <8 x i32> %broadcast.splatinsert, <i32 5000, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %6 = shufflevector <8 x i32> %5, <8 x i32> poison, <8 x i32> zeroinitializer
  %7 = add <8 x i32> %broadcast.splatinsert8, <i32 5008, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %8 = shufflevector <8 x i32> %7, <8 x i32> poison, <8 x i32> zeroinitializer
  %9 = add <8 x i32> %broadcast.splatinsert10, <i32 5016, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %10 = shufflevector <8 x i32> %9, <8 x i32> poison, <8 x i32> zeroinitializer
  %11 = add <8 x i32> %broadcast.splatinsert12, <i32 5024, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %12 = shufflevector <8 x i32> %11, <8 x i32> poison, <8 x i32> zeroinitializer
  %13 = add <8 x i32> %broadcast.splatinsert, <i32 5000, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %14 = shufflevector <8 x i32> %13, <8 x i32> poison, <8 x i32> zeroinitializer
  %15 = add <8 x i32> %broadcast.splatinsert8, <i32 5008, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %16 = shufflevector <8 x i32> %15, <8 x i32> poison, <8 x i32> zeroinitializer
  %17 = add <8 x i32> %broadcast.splatinsert10, <i32 5016, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %18 = shufflevector <8 x i32> %17, <8 x i32> poison, <8 x i32> zeroinitializer
  %19 = add <8 x i32> %broadcast.splatinsert12, <i32 5024, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %20 = shufflevector <8 x i32> %19, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %entry
  %index = phi i64 [ 0, %entry ], [ %index.next.1, %vector.body ]
  %vec.ind = phi <8 x i32> [ <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %entry ], [ %vec.ind.next.1, %vector.body ]
  %21 = add <8 x i32> %6, %vec.ind
  %22 = add <8 x i32> %8, %vec.ind
  %23 = add <8 x i32> %10, %vec.ind
  %24 = add <8 x i32> %12, %vec.ind
  %25 = getelementptr inbounds [5000 x i32], ptr %fusion.4, i64 0, i64 %index
  store <8 x i32> %21, ptr %25, align 16, !alias.scope !25, !noalias !36
  %26 = getelementptr inbounds i32, ptr %25, i64 8
  store <8 x i32> %22, ptr %26, align 16, !alias.scope !25, !noalias !36
  %27 = getelementptr inbounds i32, ptr %25, i64 16
  store <8 x i32> %23, ptr %27, align 16, !alias.scope !25, !noalias !36
  %28 = getelementptr inbounds i32, ptr %25, i64 24
  store <8 x i32> %24, ptr %28, align 16, !alias.scope !25, !noalias !36
  %index.next = or i64 %index, 32
  %vec.ind.next = add <8 x i32> %vec.ind, <i32 32, i32 32, i32 32, i32 32, i32 32, i32 32, i32 32, i32 32>
  %29 = add <8 x i32> %14, %vec.ind.next
  %30 = add <8 x i32> %16, %vec.ind.next
  %31 = add <8 x i32> %18, %vec.ind.next
  %32 = add <8 x i32> %20, %vec.ind.next
  %33 = getelementptr inbounds [5000 x i32], ptr %fusion.4, i64 0, i64 %index.next
  store <8 x i32> %29, ptr %33, align 16, !alias.scope !25, !noalias !36
  %34 = getelementptr inbounds i32, ptr %33, i64 8
  store <8 x i32> %30, ptr %34, align 16, !alias.scope !25, !noalias !36
  %35 = getelementptr inbounds i32, ptr %33, i64 16
  store <8 x i32> %31, ptr %35, align 16, !alias.scope !25, !noalias !36
  %36 = getelementptr inbounds i32, ptr %33, i64 24
  store <8 x i32> %32, ptr %36, align 16, !alias.scope !25, !noalias !36
  %index.next.1 = add nuw nsw i64 %index, 64
  %vec.ind.next.1 = add <8 x i32> %vec.ind, <i32 64, i32 64, i32 64, i32 64, i32 64, i32 64, i32 64, i32 64>
  %37 = icmp eq i64 %index.next.1, 4992
  br i1 %37, label %fusion.4.loop_body.dim.0, label %vector.body, !llvm.loop !41

fusion.4.loop_body.dim.0:                         ; preds = %vector.body
  %38 = add i32 %4, 9992
  %39 = getelementptr inbounds i8, ptr %2, i64 40032
  store i32 %38, ptr %39, align 16, !alias.scope !25, !noalias !36
  %40 = add i32 %4, 9993
  %41 = getelementptr inbounds i8, ptr %2, i64 40036
  store i32 %40, ptr %41, align 4, !alias.scope !25, !noalias !36
  %42 = add i32 %4, 9994
  %43 = getelementptr inbounds i8, ptr %2, i64 40040
  store i32 %42, ptr %43, align 8, !alias.scope !25, !noalias !36
  %44 = add i32 %4, 9995
  %45 = getelementptr inbounds i8, ptr %2, i64 40044
  store i32 %44, ptr %45, align 4, !alias.scope !25, !noalias !36
  %46 = add i32 %4, 9996
  %47 = getelementptr inbounds i8, ptr %2, i64 40048
  store i32 %46, ptr %47, align 16, !alias.scope !25, !noalias !36
  %48 = add i32 %4, 9997
  %49 = getelementptr inbounds i8, ptr %2, i64 40052
  store i32 %48, ptr %49, align 4, !alias.scope !25, !noalias !36
  %50 = add i32 %4, 9998
  %51 = getelementptr inbounds i8, ptr %2, i64 40056
  store i32 %50, ptr %51, align 8, !alias.scope !25, !noalias !36
  %52 = add i32 %4, 9999
  %53 = getelementptr inbounds i8, ptr %2, i64 40060
  store i32 %52, ptr %53, align 4, !alias.scope !25, !noalias !36
  %fusion.6 = getelementptr inbounds i8, ptr %2, i64 64
  %54 = load i32, ptr %Arg_0.1, align 8, !invariant.load !0, !noalias !33
  %broadcast.splatinsert27 = insertelement <8 x i32> poison, i32 %54, i64 0
  %broadcast.splat28 = shufflevector <8 x i32> %broadcast.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert29 = insertelement <8 x i32> poison, i32 %54, i64 0
  %broadcast.splatinsert31 = insertelement <8 x i32> poison, i32 %54, i64 0
  %broadcast.splatinsert33 = insertelement <8 x i32> poison, i32 %54, i64 0
  %55 = add <8 x i32> %broadcast.splatinsert29, <i32 8, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <8 x i32> %55, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = add <8 x i32> %broadcast.splatinsert31, <i32 16, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %58 = shufflevector <8 x i32> %57, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = add <8 x i32> %broadcast.splatinsert33, <i32 24, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %60 = shufflevector <8 x i32> %59, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %broadcast.splatinsert29, <i32 8, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <8 x i32> %61, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %broadcast.splatinsert31, <i32 16, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <8 x i32> %63, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %broadcast.splatinsert33, <i32 24, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %66 = shufflevector <8 x i32> %65, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %fusion.4.loop_body.dim.0
  %index20 = phi i64 [ 0, %fusion.4.loop_body.dim.0 ], [ %index.next35.1, %vector.body19 ]
  %vec.ind21 = phi <8 x i32> [ <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %fusion.4.loop_body.dim.0 ], [ %vec.ind.next26.1, %vector.body19 ]
  %67 = add <8 x i32> %broadcast.splat28, %vec.ind21
  %68 = add <8 x i32> %56, %vec.ind21
  %69 = add <8 x i32> %58, %vec.ind21
  %70 = add <8 x i32> %60, %vec.ind21
  %71 = getelementptr inbounds [5000 x i32], ptr %fusion.6, i64 0, i64 %index20
  store <8 x i32> %67, ptr %71, align 16, !alias.scope !16, !noalias !42
  %72 = getelementptr inbounds i32, ptr %71, i64 8
  store <8 x i32> %68, ptr %72, align 16, !alias.scope !16, !noalias !42
  %73 = getelementptr inbounds i32, ptr %71, i64 16
  store <8 x i32> %69, ptr %73, align 16, !alias.scope !16, !noalias !42
  %74 = getelementptr inbounds i32, ptr %71, i64 24
  store <8 x i32> %70, ptr %74, align 16, !alias.scope !16, !noalias !42
  %index.next35 = or i64 %index20, 32
  %vec.ind.next26 = add <8 x i32> %vec.ind21, <i32 32, i32 32, i32 32, i32 32, i32 32, i32 32, i32 32, i32 32>
  %75 = add <8 x i32> %broadcast.splat28, %vec.ind.next26
  %76 = add <8 x i32> %62, %vec.ind.next26
  %77 = add <8 x i32> %64, %vec.ind.next26
  %78 = add <8 x i32> %66, %vec.ind.next26
  %79 = getelementptr inbounds [5000 x i32], ptr %fusion.6, i64 0, i64 %index.next35
  store <8 x i32> %75, ptr %79, align 16, !alias.scope !16, !noalias !42
  %80 = getelementptr inbounds i32, ptr %79, i64 8
  store <8 x i32> %76, ptr %80, align 16, !alias.scope !16, !noalias !42
  %81 = getelementptr inbounds i32, ptr %79, i64 16
  store <8 x i32> %77, ptr %81, align 16, !alias.scope !16, !noalias !42
  %82 = getelementptr inbounds i32, ptr %79, i64 24
  store <8 x i32> %78, ptr %82, align 16, !alias.scope !16, !noalias !42
  %index.next35.1 = add nuw nsw i64 %index20, 64
  %vec.ind.next26.1 = add <8 x i32> %vec.ind21, <i32 64, i32 64, i32 64, i32 64, i32 64, i32 64, i32 64, i32 64>
  %83 = icmp eq i64 %index.next35.1, 4992
  br i1 %83, label %fusion.6.loop_body.dim.0, label %vector.body19, !llvm.loop !43

fusion.6.loop_body.dim.0:                         ; preds = %vector.body19
  %84 = add i32 %54, 4992
  %85 = getelementptr inbounds i8, ptr %2, i64 20032
  store i32 %84, ptr %85, align 16, !alias.scope !16, !noalias !42
  %86 = add i32 %54, 4993
  %87 = getelementptr inbounds i8, ptr %2, i64 20036
  store i32 %86, ptr %87, align 4, !alias.scope !16, !noalias !42
  %88 = add i32 %54, 4994
  %89 = getelementptr inbounds i8, ptr %2, i64 20040
  store i32 %88, ptr %89, align 8, !alias.scope !16, !noalias !42
  %90 = add i32 %54, 4995
  %91 = getelementptr inbounds i8, ptr %2, i64 20044
  store i32 %90, ptr %91, align 4, !alias.scope !16, !noalias !42
  %92 = add i32 %54, 4996
  %93 = getelementptr inbounds i8, ptr %2, i64 20048
  store i32 %92, ptr %93, align 16, !alias.scope !16, !noalias !42
  %94 = add i32 %54, 4997
  %95 = getelementptr inbounds i8, ptr %2, i64 20052
  store i32 %94, ptr %95, align 4, !alias.scope !16, !noalias !42
  %96 = add i32 %54, 4998
  %97 = getelementptr inbounds i8, ptr %2, i64 20056
  store i32 %96, ptr %97, align 8, !alias.scope !16, !noalias !42
  %98 = add i32 %54, 4999
  %99 = getelementptr inbounds i8, ptr %2, i64 20060
  store i32 %98, ptr %99, align 4, !alias.scope !16, !noalias !42
  %copy.25 = getelementptr inbounds i8, ptr %2, i64 60080
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.25, ptr noundef nonnull align 16 dereferenceable(16) @constant.16, i64 16, i1 false)
  %copy.26 = load ptr, ptr %buffer_table, align 8, !invariant.load !0, !dereferenceable !3, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.26, ptr noundef nonnull align 16 dereferenceable(16) @constant.17, i64 16, i1 false)
  %copy.24 = getelementptr inbounds i8, ptr %2, i64 60128
  store i32 0, ptr %copy.24, align 16
  %fusion.3 = getelementptr inbounds i8, ptr %2, i64 60112
  %100 = xor i32 %54, %4
  %101 = xor i32 %100, 466688986
  store i32 %101, ptr %fusion.3, align 16, !alias.scope !17, !noalias !44
  %fusion.5 = getelementptr inbounds i8, ptr %2, i64 60144
  store i32 %4, ptr %fusion.5, align 16, !alias.scope !45, !noalias !46
  %fusion.7 = getelementptr inbounds i8, ptr %2, i64 60160
  store i32 %54, ptr %fusion.7, align 16, !alias.scope !47, !noalias !48
  store ptr %copy.24, ptr %2, align 16, !alias.scope !49, !noalias !50
  %102 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 1
  store ptr %fusion.6, ptr %102, align 8, !alias.scope !49, !noalias !50
  %103 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 2
  store ptr %fusion.4, ptr %103, align 16, !alias.scope !49, !noalias !50
  %104 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 3
  store ptr %fusion.5, ptr %104, align 8, !alias.scope !49, !noalias !50
  %105 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 4
  store ptr %fusion.3, ptr %105, align 16, !alias.scope !49, !noalias !50
  %106 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 5
  store ptr %fusion.7, ptr %106, align 8, !alias.scope !49, !noalias !50
  %107 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 6
  store ptr %copy.26, ptr %107, align 16, !alias.scope !49, !noalias !50
  %108 = getelementptr inbounds [8 x ptr], ptr %2, i64 0, i64 7
  %compare.5.i = getelementptr inbounds i8, ptr %2, i64 60096
  store ptr %copy.25, ptr %108, align 8, !alias.scope !49, !noalias !50
  store i8 1, ptr %compare.5.i, align 16, !alias.scope !51, !noalias !53
  %copy.14.i = getelementptr inbounds i8, ptr %2, i64 60064
  %copy.9.i = getelementptr inbounds i8, ptr %2, i64 40064
  %copy.8.i = getelementptr inbounds i8, ptr %2, i64 60176
  br label %while.1.body

while.1.body:                                     ; preds = %while.1.body, %fusion.6.loop_body.dim.0
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.14.i, ptr noundef nonnull align 16 dereferenceable(16) %copy.26, i64 16, i1 false), !noalias !57
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(20000) %copy.26, ptr noundef nonnull align 16 dereferenceable(20000) %fusion.4, i64 20000, i1 false), !noalias !57
  %109 = load ptr, ptr %102, align 8, !noalias !57, !dereferenceable !63, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(20000) %copy.9.i, ptr noundef nonnull align 16 dereferenceable(20000) %109, i64 20000, i1 false), !noalias !57
  %110 = load ptr, ptr %105, align 16, !noalias !57, !dereferenceable !64, !align !64
  %111 = load i32, ptr %110, align 4, !noalias !57
  store i32 %111, ptr %compare.5.i, align 16, !noalias !57
  %112 = load ptr, ptr %2, align 16, !noalias !57, !dereferenceable !64, !align !64
  %113 = load i32, ptr %112, align 4, !noalias !57
  store i32 %113, ptr %copy.8.i, align 16, !noalias !57
  tail call void @__xla_cpu_runtime_ParallelForkJoin(ptr nonnull %fusion.4, ptr %run_options, ptr null, ptr nonnull %buffer_table, ptr %status, ptr %prof_counters, i32 7, ptr nonnull @parallel_fusion_parallel_dimension_partitions, i32 1, ptr nonnull @parallel_fusion)
  %114 = load ptr, ptr %104, align 8, !dereferenceable !64, !align !64
  %115 = load i32, ptr %114, align 4
  store i32 %115, ptr %fusion.3, align 16
  tail call void @__xla_cpu_runtime_ParallelForkJoin(ptr nonnull %fusion.6, ptr %run_options, ptr null, ptr nonnull %buffer_table, ptr %status, ptr %prof_counters, i32 6, ptr nonnull @parallel_fusion.1_parallel_dimension_partitions, i32 1, ptr nonnull @parallel_fusion.1)
  %116 = load ptr, ptr %108, align 8, !dereferenceable !2, !align !2
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.9.i, ptr noundef nonnull align 16 dereferenceable(16) %116, i64 16, i1 false)
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.25, ptr noundef nonnull align 16 dereferenceable(16) %copy.14.i, i64 16, i1 false)
  %117 = load i32, ptr %copy.8.i, align 16, !alias.scope !28, !noalias !65
  %118 = add i32 %117, 1
  store i32 %118, ptr %copy.24, align 16, !alias.scope !67, !noalias !68
  %119 = load i32, ptr %compare.5.i, align 16
  store i32 %119, ptr %fusion.5, align 16
  %120 = load ptr, ptr %106, align 8, !dereferenceable !64, !align !64
  %121 = load i32, ptr %120, align 4
  store i32 %121, ptr %compare.5.i, align 16
  %122 = load i32, ptr %fusion.3, align 16
  store i32 %122, ptr %fusion.7, align 16
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %copy.26, ptr noundef nonnull align 16 dereferenceable(16) %copy.9.i, i64 16, i1 false)
  %123 = load i32, ptr %compare.5.i, align 16
  store i32 %123, ptr %fusion.3, align 16
  store ptr %copy.24, ptr %2, align 16, !alias.scope !49, !noalias !50
  store ptr %fusion.6, ptr %102, align 8, !alias.scope !49, !noalias !50
  store ptr %fusion.4, ptr %103, align 16, !alias.scope !49, !noalias !50
  store ptr %fusion.5, ptr %104, align 8, !alias.scope !49, !noalias !50
  store ptr %fusion.3, ptr %105, align 16, !alias.scope !49, !noalias !50
  store ptr %fusion.7, ptr %106, align 8, !alias.scope !49, !noalias !50
  store ptr %copy.26, ptr %107, align 16, !alias.scope !49, !noalias !50
  store ptr %copy.25, ptr %108, align 8, !alias.scope !49, !noalias !50
  %124 = load i32, ptr %copy.24, align 16, !alias.scope !67, !noalias !69
  %125 = icmp slt i32 %124, 5
  %126 = zext i1 %125 to i8
  store i8 %126, ptr %compare.5.i, align 16, !alias.scope !51, !noalias !53
  br i1 %125, label %while.1.body, label %while.1.exit

while.1.exit:                                     ; preds = %while.1.body
  tail call void @__xla_cpu_runtime_ParallelForkJoin(ptr nonnull %copy.26, ptr %run_options, ptr null, ptr nonnull %buffer_table, ptr %status, ptr %prof_counters, i32 8, ptr nonnull @parallel_fusion.2_parallel_dimension_partitions, i32 1, ptr nonnull @parallel_fusion.2)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readonly willreturn
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i32>) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x float> @llvm.fabs.v8f32(<8 x float>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #7

attributes #0 = { nofree nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nofree norecurse nosync nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #3 = { inaccessiblemem_or_argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #4 = { nounwind }
attributes #5 = { nounwind uwtable "denormal-fp-math"="preserve-sign" "no-frame-pointer-elim"="false" }
attributes #6 = { nocallback nofree nosync nounwind readonly willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!0 = !{}
!1 = !{i64 60180}
!2 = !{i64 16}
!3 = !{i64 40000}
!4 = !{!5, !7}
!5 = !{!"buffer: {index:7, offset:64, size:20000}", !6}
!6 = !{!"XLA global AA domain"}
!7 = !{!"buffer: {index:7, offset:20064, size:20000}", !6}
!8 = !{!9}
!9 = !{!"buffer: {index:0, offset:0, size:40000}", !6}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.isvectorized", i32 1}
!12 = distinct !{!12, !13, !11}
!13 = !{!"llvm.loop.unroll.runtime.disable"}
!14 = !{!15}
!15 = !{!"buffer: {index:7, offset:60064, size:16}", !6}
!16 = !{!5}
!17 = !{!18}
!18 = !{!"buffer: {index:7, offset:60112, size:4}", !6}
!19 = !{!20}
!20 = !{!"buffer: {index:7, offset:40064, size:20000}", !6}
!21 = !{!22}
!22 = !{!"buffer: {index:0, offset:0, size:20000}", !6}
!23 = distinct !{!23, !11}
!24 = distinct !{!24, !13, !11}
!25 = !{!7}
!26 = !{!27}
!27 = !{!"buffer: {index:7, offset:60096, size:4}", !6}
!28 = !{!29}
!29 = !{!"buffer: {index:7, offset:60176, size:4}", !6}
!30 = distinct !{!30, !11}
!31 = distinct !{!31, !13, !11}
!32 = !{i64 8}
!33 = !{!5, !7, !18, !34, !35}
!34 = !{!"buffer: {index:7, offset:60144, size:4}", !6}
!35 = !{!"buffer: {index:7, offset:60160, size:4}", !6}
!36 = !{!37, !38, !5, !39, !18, !40, !34, !35}
!37 = !{!"buffer: {index:0, offset:0, size:16}", !6}
!38 = !{!"buffer: {index:7, offset:0, size:64}", !6}
!39 = !{!"buffer: {index:7, offset:60080, size:16}", !6}
!40 = !{!"buffer: {index:7, offset:60128, size:4}", !6}
!41 = distinct !{!41, !11}
!42 = !{!37, !38, !7, !39, !18, !40, !34, !35}
!43 = distinct !{!43, !11}
!44 = !{!37, !38, !5, !7, !39, !40, !34, !35}
!45 = !{!34}
!46 = !{!37, !38, !5, !7, !39, !18, !40, !35}
!47 = !{!35}
!48 = !{!37, !38, !5, !7, !39, !18, !40, !34}
!49 = !{!38}
!50 = !{!37, !5, !7, !39, !18, !40, !34, !35}
!51 = !{!52}
!52 = !{!"buffer: {index:7, offset:60096, size:1}", !6}
!53 = !{!54, !40, !55}
!54 = !{!"buffer: {index:6, offset:0, size:4}", !6}
!55 = distinct !{!55, !56, !"region_1.96.clone.clone: %buffer_table"}
!56 = distinct !{!56, !"region_1.96.clone.clone"}
!57 = !{!58, !60, !61, !62}
!58 = distinct !{!58, !59, !"region_0.32.clone.clone.clone: %run_options"}
!59 = distinct !{!59, !"region_0.32.clone.clone.clone"}
!60 = distinct !{!60, !59, !"region_0.32.clone.clone.clone: %buffer_table"}
!61 = distinct !{!61, !59, !"region_0.32.clone.clone.clone: %status"}
!62 = distinct !{!62, !59, !"region_0.32.clone.clone.clone: %prof_counters"}
!63 = !{i64 20000}
!64 = !{i64 4}
!65 = !{!22, !66, !7, !20, !15, !27, !40}
!66 = !{!"buffer: {index:1, offset:0, size:4}", !6}
!67 = !{!40}
!68 = !{!37, !66, !38, !5, !7, !39, !18, !34, !35, !29}
!69 = !{!54, !52, !55}
